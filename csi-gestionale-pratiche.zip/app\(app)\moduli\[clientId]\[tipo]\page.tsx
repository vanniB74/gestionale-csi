"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { useData } from "@/lib/store";
import { PageHeader, EmptyState, Crumbs } from "@/components/ui";
import { Icon } from "@/components/Icon";
import { SheetPreview } from "@/components/SheetPreview";
import { ModuleSheet } from "@/components/ModuleSheet";
import { ContainerPicker } from "@/components/ContainerPicker";
import { useToast } from "@/components/Toast";
import { fileToAttachment } from "@/lib/upload";
import { formatDate, fullName, today } from "@/lib/format";
import type { Attachment, MandateType } from "@/lib/types";

export default function ModuloPage() {
  const params = useParams<{ clientId: string; tipo: string }>();
  const { db, currentUser, createMandate, attachPrivacyScan } = useData();
  const toast = useToast();

  const kind = params?.tipo === "privacy" ? "privacy" : params?.tipo === "mandato" ? "mandato" : null;
  const client = db.clients.find((item) => item.id === params?.clientId);
  const identityDoc = client ? db.documents.find((item) => item.clientId === client.id) : null;
  const mandates = client ? db.mandates.filter((item) => item.clientId === client.id) : [];
  const latest = mandates[0];

  const [areaId, setAreaId] = useState(latest?.areaId ?? "cnt-03");
  const [mandateType, setMandateType] = useState<MandateType>("omnibus");
  const [selected, setSelected] = useState<string[]>([]);
  const [scan, setScan] = useState<Attachment | null>(null);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const search = new URLSearchParams(window.location.search);
    const area = search.get("area");
    const tipo = search.get("tipo");
    const servizi = search.get("servizi");
    if (area && db.containers.some((container) => container.id === area)) setAreaId(area);
    if (tipo === "omnibus" || tipo === "servizio") setMandateType(tipo);
    if (servizi) setSelected(servizi.split(",").filter(Boolean));
  }, [db.containers]);

  const area = db.containers.find((container) => container.id === areaId) ?? db.containers[0];
  const areaServices = useMemo(
    () =>
      db.services.filter(
        (service) => service.containerId === areaId && db.activeServiceIds.includes(service.id),
      ),
    [db, areaId],
  );

  if (!client || !kind) {
    return (
      <div className="page">
        <EmptyState
          icon="file"
          title="Modulo non disponibile"
          text="Il cliente o il tipo di modulo richiesto non esistono."
          action={
            <Link href="/clienti" className="btn btn--sm">
              Torna ai clienti
            </Link>
          }
        />
      </div>
    );
  }

  const servicesForSheet =
    mandateType === "omnibus" ? [] : areaServices.filter((service) => selected.includes(service.id));

  const upload = async (file: File | undefined) => {
    if (!file) return;
    setError(null);
    try {
      setScan(await fileToAttachment(file, kind === "privacy" ? "privacy_firmata" : "mandato_firmato"));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Caricamento non riuscito.");
    }
  };

  const register = () => {
    if (!scan) {
      setError("Allega la scansione del modulo firmato.");
      return;
    }
    if (kind === "privacy") {
      attachPrivacyScan(client.id, scan);
      setSaved(true);
      toast.push("Privacy firmata allegata alla scheda cliente.");
      return;
    }
    if (mandateType === "servizio" && selected.length === 0) {
      setError("Seleziona almeno un servizio coperto dal mandato.");
      return;
    }
    const mandate = createMandate({
      clientId: client.id,
      type: mandateType,
      areaId,
      serviceIds: selected,
      signedScan: scan,
      createdBy: currentUser ? `${currentUser.firstName} ${currentUser.lastName}` : "Operatore",
    });
    setSaved(true);
    toast.push(`Mandato registrato · valido fino al ${formatDate(mandate.expiresAt)}.`);
  };

  return (
    <div className="page page--wide">
      <PageHeader
        eyebrow={kind === "mandato" ? "Modulistica · Mandato" : "Modulistica · Privacy"}
        crumbs={
          <Crumbs
            items={[
              { label: "Clienti", href: "/clienti" },
              { label: fullName(client), href: `/clienti/${client.id}?tab=moduli` },
              { label: kind === "mandato" ? "Mandato" : "Privacy" },
            ]}
          />
        }
        title={kind === "mandato" ? "Mandato di assistenza" : "Consenso privacy"}
        description={
          kind === "mandato"
            ? "Il modulo si compila dai dati dell'anagrafica. Scegli l'area di interesse, stampa, firma e allega la scansione."
            : "Il consenso è identico per tutti i clienti e non riporta il numero di pratica. Stampa, firma e allega la scansione."
        }
        actions={
          <>
            <button type="button" className="btn" onClick={() => window.print()}>
              <Icon name="printer" /> Stampa
            </button>
            <Link href={`/clienti/${client.id}?tab=moduli`} className="btn btn--ghost">
              Scheda cliente
            </Link>
          </>
        }
      />

      <div className="module-layout">
        <div>
          <SheetPreview>
            <ModuleSheet
              key={kind}
              kind={kind}
              client={client}
              document={identityDoc}
              area={area}
              services={servicesForSheet}
              mandateType={mandateType}
              operator={currentUser ? fullName(currentUser) : "Operatore"}
            />
          </SheetPreview>
        </div>

        <aside className="side-panel no-print">
          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Cliente</div>
                <div className="card-sub">Dati usati per compilare il modulo</div>
              </div>
              <Icon name="user" style={{ color: "var(--slate)" }} />
            </div>
            <div className="card-body" style={{ paddingTop: 4 }}>
              <div className="select-card" style={{ cursor: "default" }}>
                <span className="avatar">
                  {client.firstName.charAt(0)}
                  {client.lastName.charAt(0)}
                </span>
                <span className="select-card-body">
                  <span className="select-card-name">{fullName(client)}</span>
                  <span className="select-card-meta mono">{client.fiscalCode}</span>
                </span>
              </div>
              <div className="mini-list mt-8">
                <div className="mini-item">
                  <span className="hint">Nascita</span>
                  <span className="mono" style={{ fontSize: 10.5 }}>{formatDate(client.birthDate)}</span>
                </div>
                <div className="mini-item">
                  <span className="hint">Residenza</span>
                  <span style={{ fontSize: 11.5 }}>{client.city} ({client.province})</span>
                </div>
              </div>
            </div>
          </section>

          {kind === "mandato" ? (
            <section className="card">
              <div className="card-head">
                <div>
                  <div className="card-title">Impostazioni del mandato</div>
                  <div className="card-sub">Area di interesse e copertura</div>
                </div>
                <Icon name="shield" style={{ color: "var(--slate)" }} />
              </div>
              <div className="card-body stack-sm">
                <div className="field">
                  <span className="field-label">Area di interesse</span>
                  <ContainerPicker containers={db.containers.filter((container) => container.loaded !== false)} value={areaId} onChange={(value) => { setAreaId(value); setSelected([]); }} />
                </div>
                <div className="field">
                  <span className="field-label">Copertura</span>
                  <select className="select" value={mandateType} onChange={(event) => setMandateType(event.target.value as MandateType)}>
                    <option value="omnibus">Macro-gruppo omnibus · 12 mesi</option>
                    <option value="servizio">Servizi specifici</option>
                  </select>
                </div>

                {mandateType === "servizio" ? (
                  <div style={{ display: "grid", gap: 2, maxHeight: 190, overflowY: "auto", border: "1px solid var(--line-soft)", padding: "2px 10px" }}>
                    {areaServices.map((service) => (
                      <label className="check" key={service.id} style={{ borderBottom: "1px solid var(--line-soft)" }}>
                        <input
                          type="checkbox"
                          checked={selected.includes(service.id)}
                          onChange={() =>
                            setSelected((prev) =>
                              prev.includes(service.id) ? prev.filter((id) => id !== service.id) : [...prev, service.id],
                            )
                          }
                        />
                        <span style={{ fontSize: 11.5 }}>{service.name}</span>
                      </label>
                    ))}
                  </div>
                ) : null}

                <span className="hint">
                  Il modulo riporta l&apos;area, non il numero di pratica: è la copertura che vale all&apos;apertura
                  del fascicolo.
                </span>
              </div>
            </section>
          ) : null}

          {kind === "mandato" && mandates.length ? (
            <section className="card">
              <div className="card-head">
                <div className="card-title">Copertura attuale</div>
                <span className="hint">{mandates.length}</span>
              </div>
              <div className="card-body" style={{ paddingTop: 6 }}>
                <div className="mini-list">
                  {mandates.slice(0, 3).map((mandate) => (
                    <div className="mini-item" key={mandate.id}>
                      <div>
                        <div className="cell-strong">
                          {mandate.type === "omnibus" ? "Omnibus" : "Per servizio"}
                        </div>
                        <div className="mono" style={{ fontSize: 10 }}>
                          {formatDate(mandate.signedAt)} → {formatDate(mandate.expiresAt)}
                        </div>
                      </div>
                      <span className={`pill ${mandate.expiresAt >= today() ? "pill--gold" : "pill--danger"}`}>
                        {mandate.expiresAt >= today() ? "Valido" : "Scaduto"}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          ) : null}

          <section className="card card--accent">
            <div className="card-head">
              <div>
                <div className="card-title">Modulo firmato</div>
                <div className="card-sub">Stampa · firma · scansiona · allega</div>
              </div>
              <Icon name="upload" style={{ color: "var(--slate)" }} />
            </div>
            <div className="card-body stack-sm">
              <label className="dropzone">
                <input type="file" accept="image/*,application/pdf" onChange={(event) => upload(event.target.files?.[0])} />
                <Icon name="upload" />
                <strong>{scan ? "Sostituisci scansione" : "Allega la scansione firmata"}</strong>
                <span>JPG, PNG o PDF · max 8 MB</span>
              </label>

              {scan ? (
                scan.mime.startsWith("image/") ? (
                  <img src={scan.dataUrl} alt="Modulo firmato" className="scan-thumb" />
                ) : (
                  <div className="note">{scan.name} · PDF allegato</div>
                )
              ) : null}

              <button type="button" className="btn btn--block" onClick={register} disabled={saved}>
                <Icon name={saved ? "check" : "file"} />
                {kind === "mandato" ? "Registra mandato firmato" : "Allega privacy firmata"}
              </button>

              {saved ? (
                <span className="success-text">
                  {kind === "mandato" ? "Mandato registrato e collegato al cliente." : "Privacy firmata allegata."}
                </span>
              ) : null}
              {error ? <div className="error-text">{error}</div> : null}
              <span className="hint">
                Il file resta nel browser. Per la stampa ufficiale usa il pulsante in alto: il layout è A4.
              </span>
            </div>
          </section>

          {kind === "privacy" && client.privacyScan ? (
            <section className="card">
              <div className="card-head">
                <div className="card-title">Privacy già acquisita</div>
                <span className="pill pill--conclusa">Firmato</span>
              </div>
              <div className="card-body">
                <a href={client.privacyScan.dataUrl} target="_blank" rel="noopener noreferrer">
                  <img src={client.privacyScan.dataUrl} alt="Privacy firmata" className="scan-thumb" />
                </a>
              </div>
            </section>
          ) : null}

          {kind === "mandato" && latest?.signedScan ? (
            <section className="card">
              <div className="card-head">
                <div className="card-title">Ultimo modulo firmato</div>
                <span className="pill pill--gold">Acquisito</span>
              </div>
              <div className="card-body">
                <a href={latest.signedScan.dataUrl} target="_blank" rel="noopener noreferrer">
                  <img src={latest.signedScan.dataUrl} alt="Mandato firmato" className="scan-thumb" />
                </a>
                <div className="hint mt-8">
                  {latest.signedScan.name} · {formatDate(latest.signedAt)}
                </div>
              </div>
            </section>
          ) : null}
        </aside>
      </div>
    </div>
  );
}
