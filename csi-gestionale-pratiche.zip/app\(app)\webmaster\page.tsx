"use client";

import Link from "next/link";
import { useState } from "react";
import { useData } from "@/lib/store";
import { PageHeader, Definition, EmptyState } from "@/components/ui";
import { Icon } from "@/components/Icon";
import { Modal } from "@/components/Modal";
import { useToast } from "@/components/Toast";
import { BackupPanel } from "@/components/BackupPanel";
import { formatDate, fullName } from "@/lib/format";
import type { Role, Staff } from "@/lib/types";

const ROLE_LABEL: Record<Role, string> = {
  webmaster: "Webmaster",
  operatore: "Operatore desk",
  consulente: "Consulente",
};

export default function WebmasterPage() {
  const {
    db,
    currentUser,
    createStaff,
    updateStaff,
    unbindDevice,
    updateWebmaster,
    clearOperationalData,
    resetDemo,
    storageError,
  } = useData();
  const toast = useToast();

  const [creating, setCreating] = useState(false);
  const [credentialsFor, setCredentialsFor] = useState<Staff | null>(null);
  const [editingProfile, setEditingProfile] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [staffForm, setStaffForm] = useState({
    firstName: "",
    lastName: "",
    role: "operatore" as Role,
    email: "",
    phone: "",
    username: "",
    password: "csi2026",
    active: true,
  });

  const [credentials, setCredentials] = useState({ username: "", password: "" });

  const [profile, setProfile] = useState({ ...db.webmaster });

  if (currentUser?.role !== "webmaster") {
    return (
      <div className="page">
        <PageHeader eyebrow="Area riservata" title="Area webmaster" description="Questa sezione è accessibile solo con le credenziali del webmaster." />
        <div className="card">
          <EmptyState
            icon="lock"
            title="Accesso riservato"
            text="Le anagrafiche di consulenti e operatori, le credenziali, i servizi attivi e lo scollegamento dei telefoni sono gestiti esclusivamente dal webmaster."
            action={
              <Link href="/dashboard" className="btn btn--sm">
                Torna alla dashboard
              </Link>
            }
          />
        </div>
      </div>
    );
  }

  const activeServices = db.activeServiceIds.length;

  const submitStaff = (event: React.FormEvent) => {
    event.preventDefault();
    if (!staffForm.firstName.trim() || !staffForm.lastName.trim()) {
      setError("Nome e cognome sono obbligatori.");
      return;
    }
    if (!staffForm.username.trim() || staffForm.password.length < 6) {
      setError("Username obbligatorio e password di almeno 6 caratteri.");
      return;
    }
    if (db.staff.some((member) => member.username.toLowerCase() === staffForm.username.trim().toLowerCase())) {
      setError("Username già in uso.");
      return;
    }
    createStaff({
      ...staffForm,
      username: staffForm.username.trim().toLowerCase(),
      email: staffForm.email.trim(),
      phone: staffForm.phone.trim(),
    });
    setCreating(false);
    setError(null);
    setStaffForm({
      firstName: "",
      lastName: "",
      role: "operatore",
      email: "",
      phone: "",
      username: "",
      password: "csi2026",
      active: true,
    });
    toast.push("Operatore creato con le credenziali indicate.");
  };

  const saveCredentials = () => {
    if (!credentialsFor) return;
    if (!credentials.username.trim() || credentials.password.length < 6) {
      setError("Username obbligatorio e password di almeno 6 caratteri.");
      return;
    }
    const duplicate = db.staff.some(
      (member) =>
        member.id !== credentialsFor.id &&
        member.username.toLowerCase() === credentials.username.trim().toLowerCase(),
    );
    if (duplicate) {
      setError("Username già in uso.");
      return;
    }
    updateStaff(credentialsFor.id, {
      username: credentials.username.trim().toLowerCase(),
      password: credentials.password,
    });
    setCredentialsFor(null);
    setError(null);
    toast.push("Credenziali aggiornate.");
  };

  return (
    <div className="page page--wide">
      <PageHeader
        eyebrow="Area riservata · Webmaster"
        title="Governo dell'ufficio"
        description="Servizi attivi, anagrafiche dello staff, credenziali e abbinamento dei telefoni al QR code."
        actions={
          <>
            <a href="#backup" className="btn btn--ghost">
              <Icon name="download" /> Backup
            </a>
            <button type="button" className="btn" onClick={() => setCreating(true)}>
              <Icon name="plus" /> Nuovo operatore
            </button>
          </>
        }
      />

      {storageError ? (
        <div className="error-text mb-16">
          Spazio locale esaurito: le ultime modifiche potrebbero non essere salvate. Rimuovi qualche allegato o
          ripristina i dati demo.
        </div>
      ) : null}

      <div className="grid-4 mb-16">
        <div className="kpi">
          <div className="kpi-label">Staff attivo</div>
          <div className="kpi-value">{String(db.staff.filter((member) => member.active).length).padStart(2, "0")}</div>
          <div className="kpi-hint">Operatori, consulenti, webmaster</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Servizi attivi</div>
          <div className="kpi-value">{String(activeServices).padStart(2, "0")}</div>
          <div className="kpi-hint">Su {db.services.length} codici a catalogo</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Telefoni abbinati</div>
          <div className="kpi-value">{String(db.staff.filter((member) => member.deviceId).length).padStart(2, "0")}</div>
          <div className="kpi-hint">Accesso QR attivo</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Mandati registrati</div>
          <div className="kpi-value">{String(db.mandates.length).padStart(2, "0")}</div>
          <div className="kpi-hint">Validità 12 mesi</div>
        </div>
      </div>

      <section className="card mb-16">
        <div className="card-head">
          <div>
            <div className="card-title">Diagnostica e qualità</div>
            <div className="card-sub">Dipendenze, test esterni, workflow, registro errori e fix prompt</div>
          </div>
          <Link href="/diagnostica" className="btn btn--ghost btn--sm">
            <Icon name="activity" /> Apri diagnostica
          </Link>
        </div>
        <div className="card-body">
          <div className="grid-3">
            <div className="summary-box">
              <span className="eyebrow eyebrow--plain">Dipendenze</span>
              <p className="hint" style={{ marginTop: 8 }}>
                Grafo degli import, cicli, moduli orfani, rotte e pacchetti. Report statico generato da
                <span className="mono"> npm run analyze</span>.
              </p>
            </div>
            <div className="summary-box">
              <span className="eyebrow eyebrow--plain">Test</span>
              <p className="hint" style={{ marginTop: 8 }}>
                Fixture e casi in tabelle esterne. La sandbox vive in memoria e i record di test vengono rimossi
                dopo il run.
              </p>
            </div>
            <div className="summary-box">
              <span className="eyebrow eyebrow--plain">Guardiani</span>
              <p className="hint" style={{ marginTop: 8 }}>
                Error boundary, errori globali e API protette: ogni anomalia finisce nel registro con contesto e
                stack.
              </p>
            </div>
          </div>
        </div>
      </section>

      <div className="stack">
        <div className="stack">
          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Webmaster</div>
                <div className="card-sub">Dati impostati al primo accesso</div>
              </div>
              <button type="button" className="btn btn--ghost btn--sm" onClick={() => setEditingProfile(true)}>
                <Icon name="edit" /> Modifica
              </button>
            </div>
            <div className="card-body" style={{ paddingTop: 4 }}>
              <Definition
                items={[
                  { label: "Nome", value: `${db.webmaster.firstName} ${db.webmaster.lastName}` },
                  { label: "Codice fiscale", value: db.webmaster.fiscalCode, mono: true },
                  { label: "E-mail", value: db.webmaster.email },
                  { label: "Telefono", value: db.webmaster.phone },
                  { label: "Sede", value: db.webmaster.office },
                  {
                    label: "Configurato il",
                    value: db.webmaster.configuredAt ? formatDate(db.webmaster.configuredAt) : "Primo accesso da completare",
                  },
                ]}
              />
            </div>
          </section>

          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Consulenti e operatori</div>
                <div className="card-sub">Credenziali e abbinamento del telefono</div>
              </div>
              <span className="hint">{db.staff.length}</span>
            </div>
            <div className="table-wrap">
              <table className="table">
                <thead>
                  <tr>
                    <th>Nominativo</th>
                    <th>Ruolo</th>
                    <th>Username</th>
                    <th>Dispositivo</th>
                    <th>Stato</th>
                    <th className="cell-right">Azioni</th>
                  </tr>
                </thead>
                <tbody>
                  {db.staff.map((member) => (
                    <tr key={member.id}>
                      <td>
                        <div className="cell-strong">{fullName(member)}</div>
                        <div className="cell-sub">{member.email}</div>
                      </td>
                      <td>{ROLE_LABEL[member.role]}</td>
                      <td className="cell-num">{member.username}</td>
                      <td>
                        {member.deviceId ? (
                          <span className="pill pill--gold pill--plain">{member.deviceLabel}</span>
                        ) : (
                          <span className="hint">Non abbinato</span>
                        )}
                      </td>
                      <td>
                        <span className={`pill ${member.active ? "pill--conclusa" : "pill--danger"}`}>
                          {member.active ? "Attivo" : "Disattivato"}
                        </span>
                      </td>
                      <td className="cell-right">
                        <div className="row" style={{ justifyContent: "flex-end", gap: 4 }}>
                          <button
                            type="button"
                            className="btn btn--ghost btn--sm"
                            onClick={() => {
                              setCredentialsFor(member);
                              setCredentials({ username: member.username, password: member.password });
                              setError(null);
                            }}
                          >
                            Credenziali
                          </button>
                          {member.deviceId ? (
                            <button
                              type="button"
                              className="btn btn--ghost btn--sm"
                              onClick={() => {
                                unbindDevice(member.id);
                                toast.push(`Telefono scollegato per ${fullName(member)}.`);
                              }}
                            >
                              Scollega
                            </button>
                          ) : null}
                          <button
                            type="button"
                            className="icon-btn"
                            aria-label={member.active ? "Disattiva" : "Attiva"}
                            title={member.active ? "Disattiva" : "Attiva"}
                            onClick={() => {
                              updateStaff(member.id, { active: !member.active });
                              toast.push(member.active ? "Utente disattivato." : "Utente attivato.");
                            }}
                          >
                            <Icon name={member.active ? "lock" : "check"} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="card-foot">
              <span className="hint">Solo il webmaster crea credenziali e scollega i telefoni.</span>
              <button type="button" className="link" onClick={() => setCreating(true)}>
                Aggiungi
              </button>
            </div>
          </section>

          <BackupPanel />

          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Sicurezza dell&apos;accesso QR</div>
                <div className="card-sub">Abbinamento al primo accesso con credenziali</div>
              </div>
              <Icon name="shield" style={{ color: "var(--slate)" }} />
            </div>
            <div className="card-body">
              <div className="checklist">
                <div className="checklist-item">
                  <span className="check-dot done"><Icon name="check" /></span>
                  <span>Il QR sulla schermata di login cambia ogni 20 secondi.</span>
                </div>
                <div className="checklist-item">
                  <span className="check-dot done"><Icon name="check" /></span>
                  <span>Al primo accesso con credenziali, il dispositivo viene abbinato al profilo.</span>
                </div>
                <div className="checklist-item">
                  <span className="check-dot done"><Icon name="check" /></span>
                  <span>Il QR funziona solo con il telefono abbinato: gli altri dispositivi restano fuori.</span>
                </div>
                <div className="checklist-item">
                  <span className="check-dot done"><Icon name="check" /></span>
                  <span>In caso di cambio o smarrimento, scollega qui il vecchio abbinamento.</span>
                </div>
              </div>
              <div className="note mt-16">
                <strong>Nota sulla build.</strong> In questo prototipo l&apos;abbinamento e la scansione sono
                simulati nel browser: non esiste un server di sessione né un canale con il telefono.
              </div>
            </div>
          </section>
        </div>

        <div className="grid-3">
          <section className="card card--accent">
            <div className="card-head">
              <div>
                <div className="card-title">Catalogo servizi</div>
                <div className="card-sub">Attivazione per contenitore</div>
              </div>
              <Icon name="layers" style={{ color: "var(--slate)" }} />
            </div>
            <div className="card-body">
              <div className="mini-list">
                {db.containers.map((container) => {
                  const services = db.services.filter((service) => service.containerId === container.id);
                  const active = services.filter((service) => db.activeServiceIds.includes(service.id)).length;
                  return (
                    <div className="mini-item" key={container.id}>
                      <div>
                        <div className="cell-strong">
                          <span className="mono" style={{ fontSize: 10, color: "var(--gold-deep)" }}>
                            {container.code}
                          </span>{" "}
                          {container.area}
                        </div>
                        <div className="hint">{container.name}</div>
                      </div>
                      <span className={`pill ${container.loaded === false ? "pill--in_attesa" : active ? "pill--gold" : "pill--in_attesa"}`}>
                        {container.loaded === false ? "da importare" : `${active}/${services.length}`}
                      </span>
                    </div>
                  );
                })}
              </div>
              <Link href="/servizi" className="btn btn--sm btn--ghost mt-16">
                <Icon name="layers" /> Apri catalogo
              </Link>
            </div>
          </section>

          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Archivio locale</div>
                <div className="card-sub">Dati del prototipo</div>
              </div>
              <Icon name="file" style={{ color: "var(--slate)" }} />
            </div>
            <div className="card-body stack-sm">
              <div className="stat-line">
                <span>Clienti</span>
                <strong>{db.clients.length}</strong>
              </div>
              <div className="stat-line">
                <span>Pratiche</span>
                <strong>{db.practices.length}</strong>
              </div>
              <div className="stat-line">
                <span>Mandati</span>
                <strong>{db.mandates.length}</strong>
              </div>
              <div className="stat-line">
                <span>Ultimo numero</span>
                <strong>CSI-2026-{db.sequence - 1}</strong>
              </div>
              <button
                type="button"
                className="btn btn--danger btn--sm mt-8"
                onClick={() => {
                  if (
                    window.confirm(
                      "Svuotare l'archivio operativo? Clienti, documenti, mandati, pratiche e appuntamenti verranno rimossi. Staff, catalogo e webmaster restano. Scarica prima un backup.",
                    )
                  ) {
                    const removed = clearOperationalData();
                    toast.push(`Archivio operativo svuotato: ${removed} record rimossi.`);
                  }
                }}
              >
                <Icon name="trash" /> Svuota archivio operativo
              </button>
              <button
                type="button"
                className="btn btn--danger btn--sm mt-8"
                onClick={() => {
                  if (window.confirm("Ripristinare i dati dimostrativi? Le modifiche locali andranno perse.")) {
                    resetDemo();
                    toast.push("Archivio demo ripristinato.");
                  }
                }}
              >
                <Icon name="trash" /> Ripristina dati demo
              </button>
              <span className="hint">
                Tutto è salvato nel browser (localStorage). Nessun dato viene inviato a un server.
              </span>
            </div>
          </section>

          <section className="card card--navy">
            <div className="card-body">
              <span className="eyebrow eyebrow--invert">Regola</span>
              <p style={{ marginTop: 12, fontSize: 15, fontFamily: "var(--font-display)", lineHeight: 1.35 }}>
                «Solo i servizi attivati compaiono nei campi visibili agli altri utenti.»
              </p>
              <p className="hint mt-8" style={{ color: "rgba(247,244,237,.55)" }}>
                Il catalogo è estendibile man mano che l&apos;attività si amplia.
              </p>
            </div>
          </section>
        </div>
      </div>

      {creating ? (
        <Modal
          eyebrow="Staff"
          title="Nuovo operatore o consulente"
          onClose={() => {
            setCreating(false);
            setError(null);
          }}
          footer={
            <>
              <button type="button" className="btn btn--ghost" onClick={() => setCreating(false)}>
                Annulla
              </button>
              <button type="submit" form="staff-form" className="btn">
                Crea e assegna credenziali
              </button>
            </>
          }
        >
          <form id="staff-form" onSubmit={submitStaff}>
            <div className="form-grid form-grid--3">
              <div className="field">
                <label className="field-label" htmlFor="staff-last">Cognome</label>
                <input
                  id="staff-last"
                  className="input"
                  value={staffForm.lastName}
                  onChange={(event) => setStaffForm({ ...staffForm, lastName: event.target.value })}
                  required
                />
              </div>
              <div className="field">
                <label className="field-label" htmlFor="staff-first">Nome</label>
                <input
                  id="staff-first"
                  className="input"
                  value={staffForm.firstName}
                  onChange={(event) => setStaffForm({ ...staffForm, firstName: event.target.value })}
                  required
                />
              </div>
              <div className="field">
                <label className="field-label" htmlFor="staff-role">Ruolo</label>
                <select
                  id="staff-role"
                  className="select"
                  value={staffForm.role}
                  onChange={(event) => setStaffForm({ ...staffForm, role: event.target.value as Role })}
                >
                  <option value="operatore">Operatore desk</option>
                  <option value="consulente">Consulente</option>
                  <option value="webmaster">Webmaster</option>
                </select>
              </div>
              <div className="field">
                <label className="field-label" htmlFor="staff-email">E-mail</label>
                <input
                  id="staff-email"
                  type="email"
                  className="input"
                  value={staffForm.email}
                  onChange={(event) => setStaffForm({ ...staffForm, email: event.target.value })}
                />
              </div>
              <div className="field">
                <label className="field-label" htmlFor="staff-phone">Telefono</label>
                <input
                  id="staff-phone"
                  className="input"
                  value={staffForm.phone}
                  onChange={(event) => setStaffForm({ ...staffForm, phone: event.target.value })}
                />
              </div>
              <div className="field">
                <label className="field-label" htmlFor="staff-username">Username</label>
                <input
                  id="staff-username"
                  className="input"
                  value={staffForm.username}
                  onChange={(event) => setStaffForm({ ...staffForm, username: event.target.value })}
                  placeholder="nome.cognome"
                  required
                />
              </div>
              <div className="field">
                <label className="field-label" htmlFor="staff-password">Password</label>
                <input
                  id="staff-password"
                  className="input"
                  value={staffForm.password}
                  onChange={(event) => setStaffForm({ ...staffForm, password: event.target.value })}
                  minLength={6}
                  required
                />
              </div>
            </div>
            <p className="hint mt-16">
              Le credenziali vengono create qui e comunicate al diretto interessato. Il primo accesso abbina il
              dispositivo al profilo.
            </p>
            {error ? <div className="error-text mt-16">{error}</div> : null}
          </form>
        </Modal>
      ) : null}

      {credentialsFor ? (
        <Modal
          eyebrow="Credenziali"
          title={`Accesso di ${fullName(credentialsFor)}`}
          width="narrow"
          onClose={() => {
            setCredentialsFor(null);
            setError(null);
          }}
          footer={
            <>
              <button type="button" className="btn btn--ghost" onClick={() => setCredentialsFor(null)}>
                Annulla
              </button>
              <button type="button" className="btn" onClick={saveCredentials}>
                Salva credenziali
              </button>
            </>
          }
        >
          <div className="stack">
            <div className="field">
              <label className="field-label" htmlFor="cred-user">Username</label>
              <input
                id="cred-user"
                className="input"
                value={credentials.username}
                onChange={(event) => setCredentials({ ...credentials, username: event.target.value })}
              />
            </div>
            <div className="field">
              <label className="field-label" htmlFor="cred-pass">Password</label>
              <input
                id="cred-pass"
                className="input"
                value={credentials.password}
                onChange={(event) => setCredentials({ ...credentials, password: event.target.value })}
                minLength={6}
              />
            </div>
            <p className="hint">La password è visibile al webmaster per la comunicazione all&apos;operatore.</p>
            {credentialsFor.deviceId ? (
              <div className="note">
                <strong>Telefono abbinato.</strong> Per cambiare dispositivo, usa «Scollega» nella tabella dello
                staff e fai rifare il primo accesso con credenziali.
              </div>
            ) : null}
            {error ? <div className="error-text">{error}</div> : null}
          </div>
        </Modal>
      ) : null}

      {editingProfile ? (
        <Modal
          eyebrow="Webmaster"
          title="Dati del webmaster"
          onClose={() => setEditingProfile(false)}
          footer={
            <>
              <button type="button" className="btn btn--ghost" onClick={() => setEditingProfile(false)}>
                Annulla
              </button>
              <button
                type="button"
                className="btn"
                onClick={() => {
                  updateWebmaster(profile);
                  setEditingProfile(false);
                  toast.push("Dati del webmaster aggiornati.");
                }}
              >
                Salva
              </button>
            </>
          }
        >
          <div className="form-grid">
            <div className="field">
              <label className="field-label" htmlFor="wm-first">Nome</label>
              <input id="wm-first" className="input" value={profile.firstName} onChange={(event) => setProfile({ ...profile, firstName: event.target.value })} />
            </div>
            <div className="field">
              <label className="field-label" htmlFor="wm-last">Cognome</label>
              <input id="wm-last" className="input" value={profile.lastName} onChange={(event) => setProfile({ ...profile, lastName: event.target.value })} />
            </div>
            <div className="field">
              <label className="field-label" htmlFor="wm-cf">Codice fiscale</label>
              <input id="wm-cf" className="input input--mono" value={profile.fiscalCode} onChange={(event) => setProfile({ ...profile, fiscalCode: event.target.value.toUpperCase() })} />
            </div>
            <div className="field">
              <label className="field-label" htmlFor="wm-phone">Telefono</label>
              <input id="wm-phone" className="input" value={profile.phone} onChange={(event) => setProfile({ ...profile, phone: event.target.value })} />
            </div>
            <div className="field span-2">
              <label className="field-label" htmlFor="wm-email">E-mail</label>
              <input id="wm-email" type="email" className="input" value={profile.email} onChange={(event) => setProfile({ ...profile, email: event.target.value })} />
            </div>
            <div className="field span-2">
              <label className="field-label" htmlFor="wm-office">Sede</label>
              <input id="wm-office" className="input" value={profile.office} onChange={(event) => setProfile({ ...profile, office: event.target.value })} />
            </div>
          </div>
        </Modal>
      ) : null}
    </div>
  );
}
