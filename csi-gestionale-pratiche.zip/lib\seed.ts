import demo from "@/data/demo-office.json";
import type { Database } from "./types";

/**
 * L'archivio dimostrativo non vive nel codice: è una tabella esterna in
 * `data/demo-office.json`, sostituibile senza toccare i componenti.
 *
 * I test NON usano questo file: leggono `public/test-data/office.json` e
 * `public/test-data/cases.json`, costruiscono una sandbox in memoria e
 * eliminano i record `test-*`.
 */
const DEMO = demo as unknown as Database;

export function seedDatabase(): Database {
  return structuredClone(DEMO);
}
