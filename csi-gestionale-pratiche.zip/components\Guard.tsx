"use client";

import { Component, type ErrorInfo, type ReactNode } from "react";
import { Icon } from "./Icon";
import { downloadTextFile, errorsToMarkdown, listGuardErrors, logGuardError } from "@/lib/guards";

interface Props {
  section: string;
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  message: string;
}

export class Guard extends Component<Props, State> {
  state: State = { hasError: false, message: "" };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    logGuardError({
      section: this.props.section,
      error,
      severity: "critical",
      context: { componentStack: info.componentStack?.slice(0, 4000) },
    });
  }

  render() {
    if (!this.state.hasError) return this.props.children;
    if (this.props.fallback) return this.props.fallback;

    return (
      <div className="page">
        <div className="guard-fallback">
          <span className="guard-icon">
            <Icon name="alert" size={24} />
          </span>
          <span className="eyebrow">Guardiano attivo</span>
          <h1>Questa sezione si è fermata in sicurezza</h1>
          <p>
            L&apos;errore è stato registrato nel report di diagnostica. Puoi ricaricare la sezione senza perdere
            l&apos;archivio locale.
          </p>
          <div className="guard-detail mono">{this.state.message}</div>
          <div className="row mt-16" style={{ justifyContent: "center", flexWrap: "wrap" }}>
            <button
              type="button"
              className="btn"
              onClick={() => {
                this.setState({ hasError: false, message: "" });
                if (typeof window !== "undefined") window.location.reload();
              }}
            >
              Ricarica sezione
            </button>
            <button
              type="button"
              className="btn btn--ghost"
              onClick={() => downloadTextFile(errorsToMarkdown(listGuardErrors()), "csi-errori.md", "text/markdown")}
            >
              <Icon name="download" /> Scarica registro
            </button>
          </div>
        </div>
      </div>
    );
  }
}
