import { randomUUID } from "node:crypto";

export interface PairRequest {
  token: string;
  createdAt: number;
  expiresAt: number;
  claimedBy: { staffId: string; staffName: string } | null;
}

const TTL_MS = 120_000;

const globalStore = globalThis as unknown as { __csiPairing?: Map<string, PairRequest> };
const store = globalStore.__csiPairing ?? new Map<string, PairRequest>();
globalStore.__csiPairing = store;

function cleanup() {
  const now = Date.now();
  for (const [token, request] of store) {
    if (request.expiresAt < now) store.delete(token);
  }
}

export function createPairRequest(): PairRequest {
  cleanup();
  const now = Date.now();
  const request: PairRequest = {
    token: randomUUID().replace(/-/g, "").slice(0, 10).toUpperCase(),
    createdAt: now,
    expiresAt: now + TTL_MS,
    claimedBy: null,
  };
  store.set(request.token, request);
  return request;
}

export function getPairRequest(token: string): PairRequest | null {
  const request = store.get(token);
  if (!request) return null;
  if (request.expiresAt < Date.now()) {
    store.delete(token);
    return null;
  }
  return request;
}

export function claimPairRequest(token: string, staffId: string, staffName: string): PairRequest | null {
  const request = getPairRequest(token);
  if (!request) return null;
  request.claimedBy = { staffId, staffName };
  return request;
}
