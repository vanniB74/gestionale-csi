export type Role = "webmaster" | "operatore" | "consulente";

export type PracticeStatus = "aperta" | "in_lavorazione" | "in_attesa" | "conclusa";

export type CoverageState = "omnibus" | "servizio" | "scoperto" | "scaduto";

export interface Staff {
  id: string;
  firstName: string;
  lastName: string;
  role: Role;
  email: string;
  phone: string;
  username: string;
  password: string;
  active: boolean;
  deviceId: string | null;
  deviceLabel: string | null;
  createdAt: string;
}

export interface ServiceContainer {
  id: string;
  code: string;
  name: string;
  area: string;
  subareas: string[];
  declaredCount?: number;
  loaded?: boolean;
}

export interface Service {
  id: string;
  code: string;
  originalCode: string;
  name: string;
  containerId: string;
  local?: boolean;
}

export interface Attachment {
  id: string;
  name: string;
  mime: string;
  size: number;
  dataUrl: string;
  uploadedAt: string;
  category: "ci_fronte" | "ci_retro" | "codice_fiscale" | "mandato_firmato" | "privacy_firmata" | "allegato";
}

export interface Client {
  id: string;
  firstName: string;
  lastName: string;
  sex: "M" | "F";
  birthDate: string;
  birthPlace: string;
  citizenship: string;
  fiscalCode: string;
  address: string;
  cap: string;
  city: string;
  province: string;
  phone: string;
  email: string;
  createdAt: string;
  notes: string;
  privacyScan?: Attachment | null;
}

export interface IdentityDocument {
  id: string;
  clientId: string;
  number: string;
  expiry: string;
  issuer: string;
  type: string;
  transcribedBy: string;
  transcribedAt: string;
  front: Attachment | null;
  back: Attachment | null;
  fiscalCode: Attachment | null;
}

export type MandateType = "omnibus" | "servizio";

export interface Mandate {
  id: string;
  clientId: string;
  type: MandateType;
  areaId: string;
  serviceIds: string[];
  signedAt: string;
  expiresAt: string;
  revokedAt: string | null;
  createdBy: string;
  signedScan: Attachment | null;
}

export interface TimelineEntry {
  id: string;
  at: string;
  label: string;
  detail: string;
  author: string;
}

export interface Practice {
  id: string;
  number: string;
  clientId: string;
  serviceId: string;
  areaId: string;
  description: string;
  status: PracticeStatus;
  openedAt: string;
  operatorId: string;
  nextActionAt: string | null;
  nextActionLabel: string;
  nextActionKind: "appuntamento" | "chiamata" | "adempimento" | null;
  timeline: TimelineEntry[];
  attachments: Attachment[];
  closedAt: string | null;
}

export interface Appointment {
  id: string;
  clientId: string | null;
  clientName: string;
  date: string;
  time: string;
  reason: string;
  operatorId: string;
  status: "programmato" | "confermato" | "annullato";
}

export interface WebmasterProfile {
  firstName: string;
  lastName: string;
  fiscalCode: string;
  email: string;
  phone: string;
  office: string;
  configuredAt: string | null;
}

export interface Database {
  version: number;
  webmaster: WebmasterProfile;
  staff: Staff[];
  containers: ServiceContainer[];
  services: Service[];
  activeServiceIds: string[];
  clients: Client[];
  documents: IdentityDocument[];
  mandates: Mandate[];
  practices: Practice[];
  appointments: Appointment[];
  sequence: number;
}

export interface Session {
  staffId: string;
  via: "credenziali" | "qr";
  at: string;
  deviceId: string;
}

export interface Coverage {
  state: CoverageState;
  mandate: Mandate | null;
  expiresAt: string | null;
  label: string;
  detail: string;
}
