import type { ServiceContainer } from "@/lib/types";

export function ContainerPicker({
  containers,
  value,
  onChange,
  id,
}: {
  containers: ServiceContainer[];
  value: string;
  onChange: (value: string) => void;
  id?: string;
}) {
  return (
    <select id={id} className="select" value={value} onChange={(event) => onChange(event.target.value)}>
      {containers.map((container) => (
        <option key={container.id} value={container.id}>
          {container.code} — {container.name}
        </option>
      ))}
    </select>
  );
}
