"use client";

import { useEffect, useMemo, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useData, getCoverage } from "@/lib/store";
import { daysUntil, fullName } from "@/lib/format";
import { Icon, type IconName } from "./Icon";
import { Logo } from "./Logo";
import { SocialLinks } from "./SocialLinks";
import { EcosystemBar } from "./EcosystemBar";
import { Guard } from "./Guard";

interface NavItem {
  href: string;
  label: string;
  icon: IconName;
  badge?: number;
  webmasterOnly?: boolean;
}

export function AppShell({ children }: { children: ReactNode }) {
  const { hydrated, session, currentUser, db, logout, storageError } = useData();
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (hydrated && !session) router.replace("/login");
  }, [hydrated, session, router]);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  const counts = useMemo(() => {
    const openPractices = db.practices.filter((p) => p.status !== "conclusa");
    const attention = openPractices.filter((p) => {
      const coverage = getCoverage(db, p.clientId, p.serviceId);
      return coverage.state === "scoperto" || coverage.state === "scaduto";
    }).length;
    const expiring = db.mandates.filter((m) => {
      if (m.revokedAt) return false;
      const days = daysUntil(m.expiresAt);
      return days >= 0 && days <= 30;
    }).length;
    return { open: openPractices.length, attention: attention + expiring };
  }, [db]);

  const nav: NavItem[] = [
    { href: "/dashboard", label: "Dashboard", icon: "grid" },
    { href: "/pratiche", label: "Pratiche", icon: "folder", badge: counts.open },
    { href: "/clienti", label: "Clienti", icon: "users" },
    { href: "/servizi", label: "Catalogo servizi", icon: "layers" },
    { href: "/diagnostica", label: "Diagnostica", icon: "activity", webmasterOnly: true },
    { href: "/webmaster", label: "Area webmaster", icon: "shield", webmasterOnly: true },
  ];

  const visible = nav.filter((item) => !item.webmasterOnly || currentUser?.role === "webmaster");

  if (!hydrated) {
    return <div className="loading-screen">Caricamento archivio…</div>;
  }

  if (!session || !currentUser) {
    return <div className="loading-screen">Verifica credenziali…</div>;
  }

  const roleLabel =
    currentUser.role === "webmaster" ? "Webmaster" : currentUser.role === "consulente" ? "Consulente" : "Operatore desk";

  return (
    <div className="app">
      <aside className={`sidebar no-print${open ? " open" : ""}`} aria-label="Navigazione principale">
        <div className="brand">
          <Link href="/dashboard" aria-label="C.S.I. — Dashboard">
            <Logo variant="light" width={164} priority />
          </Link>
          <div className="brand-sub">Gestionale pratiche ufficio</div>
        </div>

        <nav className="nav">
          <div className="nav-group">
            <div className="nav-label">Lavoro</div>
            {visible.slice(0, 3).map((item) => (
              <NavLink key={item.href} item={item} pathname={pathname} />
            ))}
          </div>
          <div className="nav-group">
            <div className="nav-label">Configurazione</div>
            {visible.slice(3).map((item) => (
              <NavLink key={item.href} item={item} pathname={pathname} />
            ))}
          </div>
          {counts.attention > 0 ? (
            <div className="nav-group">
              <div className="nav-label">Attenzione</div>
              <Link href="/dashboard#avvisi" className="nav-link">
                <Icon name="bell" />
                <span>Avvisi operativi</span>
                <span className="nav-count">{counts.attention}</span>
              </Link>
            </div>
          ) : null}
        </nav>

        <div className="sidebar-foot">
          <SocialLinks label="Seguici" />
          <div className="user-chip" style={{ marginTop: 16 }}>
            <span className="avatar">
              {currentUser.firstName.charAt(0)}
              {currentUser.lastName.charAt(0)}
            </span>
            <div style={{ minWidth: 0 }}>
              <div className="user-name">{fullName(currentUser)}</div>
              <div className="user-role">{roleLabel}</div>
            </div>
            <button
              type="button"
              className="icon-btn"
              aria-label="Esci dal gestionale"
              title="Esci"
              onClick={() => {
                logout();
                router.replace("/login");
              }}
            >
              <Icon name="logout" />
            </button>
          </div>
          <div className="env-note">v1.0 · dati locali · ambiente dimostrativo</div>
        </div>
      </aside>

      {open ? <div className="scrim no-print" onClick={() => setOpen(false)} aria-hidden="true" /> : null}

      <div className="main">
        <EcosystemBar />
        {storageError ? (
          <div className="storage-warning no-print">
            <Icon name="alert" size={14} />
            <span>
              Spazio locale esaurito: le ultime modifiche potrebbero non essere salvate. Scarica un backup dal
              pannello Webmaster, rimuovi qualche allegato o ripristina i dati demo.
            </span>
          </div>
        ) : null}
        <div className="mobile-bar no-print">
          <button
            type="button"
            className="icon-btn mobile-menu"
            aria-label="Apri il menu"
            onClick={() => setOpen(true)}
          >
            <Icon name="menu" />
          </button>
          <Link href="/dashboard" aria-label="C.S.I. — Dashboard" style={{ marginRight: "auto" }}>
            <Logo variant="light" width={112} />
          </Link>
          <SocialLinks label={null} />
          <Link href="/pratiche/nuova" className="icon-btn" aria-label="Nuova pratica" title="Nuova pratica">
            <Icon name="plus" />
          </Link>
        </div>
        <Guard section="app-content">{children}</Guard>
      </div>
    </div>
  );
}

function NavLink({ item, pathname }: { item: NavItem; pathname: string }) {
  const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
  return (
    <Link href={item.href} className={`nav-link${active ? " active" : ""}`} aria-current={active ? "page" : undefined}>
      <Icon name={item.icon} />
      <span>{item.label}</span>
      {typeof item.badge === "number" && item.badge > 0 ? <span className="nav-count">{item.badge}</span> : null}
    </Link>
  );
}
