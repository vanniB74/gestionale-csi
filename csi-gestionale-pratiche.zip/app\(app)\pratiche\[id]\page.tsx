"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useState } from "react";
import { getCoverage, useData } from "@/lib/store";
import { ageOf, formatDate, formatDateTime, fullName, today } from "@/lib/format";
import { PageHeader, StatusPill, CoverageBanner, EmptyState, Definition, STATUS_LABEL, Crumbs } from "@/components/ui";
import { Icon } from "@/components/Icon";
import { NewMandateModal } from "@/components/NewMandateModal";
import { useToast } from "@/components/Toast";
import { fileToAttachment, shortSize } from "@/lib/upload";
import type { PracticeStatus } from "@/lib/types";

export default function PraticaDetailPage() {
  const params = useParams<{ id: string }>();
  const { db, updatePractice, addTimeline, attachToPractice } = useData();
  const toast = useToast();

  const practice = db.practices.find((item) => item.id === params?.id);
  const client = practice ? db.clients.find((item) => item.id === practice.clientId) : null;
  const service = practice ? db.services.find((item) => item.id === practice.serviceId) : null;
  const operator = practice ? db.staff.find((item) => item.id === practice.operatorId) : null;
  const area = practice ? db.containers.find((item) => item.id === practice.areaId) : null;
  const coverage = practice ? getCoverage(db, practice.clientId, practice.serviceId) : null;

  const [mandateOpen, setMandateOpen] = useState(false);
  const [nextAt, setNextAt] = useState(practice?.nextActionAt ?? "");
  const [nextLabel, setNextLabel] = useState(practice?.nextActionLabel ?? "");
  const [nextKind, setNextKind] = useState<PracticeStatus | "appuntamento" | "chiamata" | "adempimento">(
    practice?.nextActionKind ?? "appuntamento",
  );
  const [error, setError] = useState<string | null>(null);

  if (!practice || !client) {
    return (
      <div className="page">
        <EmptyState
          icon="folder"
          title="Pratica non trovata"
          text="Il fascicolo richiesto non esiste o è stato rimosso dall'archivio locale."
          action={
            <Link href="/pratiche" className="btn btn--sm">
              Torna alle pratiche
            </Link>
          }
        />
      </div>
    );
  }

  const blocked = !coverage || coverage.state === "scoperto" || coverage.state === "scaduto";
  const mandates = db.mandates.filter((mandate) => mandate.clientId === client.id);

  const changeStatus = (status: PracticeStatus) => {
    if (blocked && status !== "conclusa") {
      setError("Copertura del mandato non valida: regolarizza prima di avanzare la pratica.");
      return;
    }
    updatePractice(practice.id, {
      status,
      closedAt: status === "conclusa" ? today() : null,
      nextActionAt: status === "conclusa" ? null : practice.nextActionAt,
      nextActionLabel: status === "conclusa" ? "" : practice.nextActionLabel,
    });
    addTimeline(practice.id, "Stato aggiornato", `Passaggio a «${STATUS_LABEL[status]}».`);
    setError(null);
    toast.push(`Pratica aggiornata: ${STATUS_LABEL[status].toLowerCase()}.`);
  };

  const saveNextAction = () => {
    updatePractice(practice.id, {
      nextActionAt: nextAt || null,
      nextActionLabel: nextLabel.trim(),
      nextActionKind: nextAt ? (nextKind as "appuntamento" | "chiamata" | "adempimento") : null,
    });
    addTimeline(
      practice.id,
      "Prossima azione aggiornata",
      nextAt ? `${nextLabel || "Azione"} · ${formatDate(nextAt)}` : "Nessuna azione programmata.",
    );
    toast.push("Prossima azione aggiornata.");
  };

  const upload = async (file: File | undefined) => {
    if (!file) return;
    try {
      const attachment = await fileToAttachment(file, "allegato");
      attachToPractice(practice.id, attachment);
      addTimeline(practice.id, "Allegato caricato", attachment.name);
      toast.push("Allegato aggiunto al fascicolo.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Caricamento non riuscito.");
    }
  };

  const timeline = [...practice.timeline].sort((a, b) => b.at.localeCompare(a.at));

  return (
    <div className="page">
      <PageHeader
        eyebrow={`Pratica · ${practice.number}`}
        crumbs={
          <Crumbs items={[{ label: "Pratiche", href: "/pratiche" }, { label: practice.number }]} />
        }
        title={fullName(client)}
        description={
          <>
            {service?.name} · aperta il {formatDate(practice.openedAt)} · operatore{" "}
            {operator ? fullName(operator) : "—"}
          </>
        }
        actions={
          <>
            {blocked ? (
              <button type="button" className="btn" onClick={() => setMandateOpen(true)}>
                <Icon name="plus" /> Nuovo mandato
              </button>
            ) : null}
            <Link href={`/clienti/${client.id}`} className="btn btn--ghost">
              <Icon name="user" /> Scheda cliente
            </Link>
          </>
        }
      />

      {coverage ? (
        <CoverageBanner
          coverage={coverage}
          action={
            blocked ? (
              <button type="button" className="btn btn--sm btn--ghost" onClick={() => setMandateOpen(true)}>
                Regolarizza
              </button>
            ) : undefined
          }
        />
      ) : null}

      <div className="split mt-16">
        <div className="stack">
          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Fascicolo</div>
                <div className="card-sub">Dati della pratica e avanzamento</div>
              </div>
              <StatusPill status={practice.status} />
            </div>
            <div className="card-body">
              <p style={{ fontSize: 13, lineHeight: 1.65 }}>{practice.description || "Nessuna descrizione."}</p>
              <div className="hr" />
              <div className="row" style={{ flexWrap: "wrap", gap: 8 }}>
                <span className="eyebrow eyebrow--plain">Avanza</span>
                {(["in_lavorazione", "in_attesa", "conclusa"] as PracticeStatus[]).map((status) => (
                  <button
                    key={status}
                    type="button"
                    className={`chip${practice.status === status ? " active" : ""}`}
                    onClick={() => changeStatus(status)}
                    disabled={blocked && status !== "conclusa"}
                  >
                    {STATUS_LABEL[status]}
                  </button>
                ))}
                {practice.status !== "aperta" ? (
                  <button type="button" className="chip" onClick={() => changeStatus("aperta")} disabled={blocked}>
                    Riapri
                  </button>
                ) : null}
              </div>
              {blocked ? (
                <p className="hint mt-8" style={{ color: "var(--danger)" }}>
                  Avanzamento bloccato: serve un mandato valido per questo servizio.
                </p>
              ) : null}
            </div>
          </section>

          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Progressione</div>
                <div className="card-sub">Storico delle tappe · {practice.timeline.length} movimenti</div>
              </div>
              <Icon name="clock" style={{ color: "var(--slate)" }} />
            </div>
            <div className="card-body">
              <div className="timeline">
                {timeline.map((entry) => (
                  <div className="timeline-item" key={entry.id}>
                    <div className="timeline-date">{formatDateTime(entry.at)}</div>
                    <div className="timeline-label">{entry.label}</div>
                    <div className="timeline-detail">{entry.detail}</div>
                    <div className="timeline-author">{entry.author}</div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Allegati del fascicolo</div>
                <div className="card-sub">File reali, visibili e stampabili</div>
              </div>
              <label className="btn btn--ghost btn--sm" style={{ position: "relative", overflow: "hidden" }}>
                <Icon name="upload" /> Carica
                <input
                  type="file"
                  accept="image/*,application/pdf"
                  onChange={(event) => upload(event.target.files?.[0])}
                  style={{ position: "absolute", inset: 0, opacity: 0, cursor: "pointer" }}
                />
              </label>
            </div>
            <div className="card-body" style={{ paddingTop: 6 }}>
              {practice.attachments.length ? (
                <div className="mini-list">
                  {practice.attachments.map((attachment) => (
                    <div className="mini-item" key={attachment.id}>
                      <div>
                        <div className="cell-strong">{attachment.name}</div>
                        <div className="mono" style={{ fontSize: 10 }}>
                          {shortSize(attachment.size)} · {formatDateTime(attachment.uploadedAt)}
                        </div>
                      </div>
                      <div className="row" style={{ gap: 4 }}>
                        <a
                          className="icon-btn"
                          href={attachment.dataUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          aria-label={`Apri ${attachment.name}`}
                        >
                          <Icon name="eye" />
                        </a>
                        <a
                          className="icon-btn"
                          href={attachment.dataUrl}
                          download={attachment.name}
                          aria-label={`Scarica ${attachment.name}`}
                        >
                          <Icon name="download" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="hint" style={{ padding: "10px 0" }}>
                  Nessun allegato ancora caricato. Puoi aggiungere documenti, ricevute e scansioni.
                </p>
              )}
            </div>
          </section>
        </div>

        <div className="stack">
          <section className="card">
            <div className="card-head">
              <div className="card-title">Riferimenti</div>
              <Icon name="info" style={{ color: "var(--slate)" }} />
            </div>
            <div className="card-body" style={{ paddingTop: 4 }}>
              <Definition
                columns={1}
                items={[
                  { label: "Numero pratica", value: <span className="mono">{practice.number}</span> },
                  { label: "Cliente", value: `${fullName(client)} · ${ageOf(client.birthDate)} anni` },
                  { label: "Codice fiscale", value: <span className="mono">{client.fiscalCode}</span>, mono: true },
                  { label: "Servizio", value: `${service?.name ?? "—"} (${service?.code ?? "—"})` },
                  { label: "Area", value: area ? `${area.code} — ${area.name}` : "—" },
                  { label: "Operatore", value: operator ? fullName(operator) : "—" },
                  { label: "Apertura", value: formatDate(practice.openedAt) },
                  { label: "Chiusura", value: practice.closedAt ? formatDate(practice.closedAt) : "—" },
                ]}
              />
              <div className="row mt-16" style={{ flexWrap: "wrap" }}>
                {client.phone ? (
                  <a href={`tel:${client.phone}`} className="btn btn--ghost btn--sm">
                    <Icon name="phone" /> {client.phone}
                  </a>
                ) : null}
                <Link href={`/clienti/${client.id}?tab=moduli`} className="btn btn--ghost btn--sm">
                  <Icon name="file" /> Moduli
                </Link>
              </div>
            </div>
          </section>

          <section className="card card--accent">
            <div className="card-head">
              <div>
                <div className="card-title">Prossima azione</div>
                <div className="card-sub">Appuntamento, chiamata o adempimento</div>
              </div>
              <Icon name="calendar" style={{ color: "var(--slate)" }} />
            </div>
            <div className="card-body stack-sm">
              <div className="form-grid">
                <div className="field">
                  <label className="field-label" htmlFor="next-at">Data</label>
                  <input
                    id="next-at"
                    type="date"
                    className="input"
                    value={nextAt ?? ""}
                    onChange={(event) => setNextAt(event.target.value)}
                  />
                </div>
                <div className="field">
                  <label className="field-label" htmlFor="next-kind-edit">Tipo</label>
                  <select
                    id="next-kind-edit"
                    className="select"
                    value={nextKind}
                    onChange={(event) => setNextKind(event.target.value as typeof nextKind)}
                  >
                    <option value="appuntamento">Appuntamento</option>
                    <option value="chiamata">Chiamata</option>
                    <option value="adempimento">Adempimento</option>
                  </select>
                </div>
                <div className="field span-2">
                  <label className="field-label" htmlFor="next-label-edit">Nota</label>
                  <input
                    id="next-label-edit"
                    className="input"
                    value={nextLabel}
                    onChange={(event) => setNextLabel(event.target.value)}
                    placeholder="Cosa va fatto e con chi"
                  />
                </div>
              </div>
              <button type="button" className="btn btn--sm" onClick={saveNextAction}>
                Salva prossima azione
              </button>
            </div>
          </section>

          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Mandati del cliente</div>
                <div className="card-sub">{mandates.length} documenti</div>
              </div>
              <Icon name="shield" style={{ color: "var(--slate)" }} />
            </div>
            <div className="card-body" style={{ paddingTop: 6 }}>
              {mandates.length ? (
                <div className="mini-list">
                  {mandates.map((mandate) => (
                    <div className="mini-item" key={mandate.id}>
                      <div>
                        <div className="cell-strong">
                          {mandate.type === "omnibus" ? "Omnibus" : "Per servizio"}
                        </div>
                        <div className="mono" style={{ fontSize: 10 }}>
                          {formatDate(mandate.signedAt)} → {formatDate(mandate.expiresAt)}
                        </div>
                      </div>
                      <span className={`pill ${mandate.expiresAt >= today() && !mandate.revokedAt ? "pill--gold" : "pill--danger"}`}>
                        {mandate.revokedAt ? "Revocato" : mandate.expiresAt >= today() ? "Valido" : "Scaduto"}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="hint" style={{ padding: "10px 0" }}>Nessun mandato registrato.</p>
              )}
              <Link href={`/moduli/${client.id}/mandato`} className="btn btn--ghost btn--sm mt-8">
                <Icon name="printer" /> Apri modulo
              </Link>
            </div>
          </section>
        </div>
      </div>

      {error ? <div className="error-text mt-16">{error}</div> : null}

      {mandateOpen ? (
        <NewMandateModal
          clientId={client.id}
          defaultServiceId={practice.serviceId}
          onClose={() => setMandateOpen(false)}
        />
      ) : null}
    </div>
  );
}
