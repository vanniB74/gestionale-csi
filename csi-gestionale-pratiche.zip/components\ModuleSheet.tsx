import type { Client, IdentityDocument, MandateType, Service, ServiceContainer } from "@/lib/types";
import { OFFICE } from "@/lib/catalog";
import { formatDate } from "@/lib/format";

function Cell({
  label,
  value,
  span = 1,
}: {
  label: string;
  value?: string | null;
  span?: 1 | 2 | 3 | 4;
}) {
  return (
    <div className={`sheet-cell${span > 1 ? ` span-${span}` : ""}`}>
      <div className="sheet-cell-label">{label}</div>
      <div className="sheet-cell-value">{value || "\u00a0"}</div>
    </div>
  );
}

function OfficeHead() {
  return (
    <div className="sheet-brand">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/brand/csi-logo.png" alt="C.S.I. — Centro Servizi Integrati" className="sheet-logo" />
      <div className="sheet-office">
        <strong>{OFFICE.name}</strong>
        <br />
        {OFFICE.legal} · {OFFICE.vat}
        <br />
        {OFFICE.address}
        <br />
        {OFFICE.city}
        <br />
        Tel. {OFFICE.phone} · {OFFICE.email}
      </div>
    </div>
  );
}

function SheetFoot({ note }: { note: string }) {
  return (
    <div className="sheet-footer">
      <span>© 2026 C.S.I. Centro Servizi Integrati — Tutti i diritti riservati.</span>
      <span>Conformità GDPR · Accessibilità WCAG 2.1 · {OFFICE.phone}</span>
      <span>{note}</span>
    </div>
  );
}

export function ModuleSheet({
  kind,
  client,
  document,
  area,
  services,
  mandateType = "omnibus",
  operator,
}: {
  kind: "mandato" | "privacy";
  client: Client;
  document?: IdentityDocument | null;
  area: ServiceContainer;
  services: Service[];
  mandateType?: MandateType;
  operator: string;
}) {
  const fullName = `${client.firstName} ${client.lastName}`;
  const address = [client.address, client.cap, client.city, client.province ? `(${client.province})` : ""]
    .filter(Boolean)
    .join(" · ");
  const serviceNames = services.map((s) => s.name).join(" · ");
  const stamp = `Documento generato il ${formatDate(new Date().toISOString())}`;

  const anagrafica = (
    <div className="sheet-grid">
      <Cell label="Cognome" value={client.lastName} span={1} />
      <Cell label="Nome" value={client.firstName} span={1} />
      <Cell label="Sesso" value={client.sex === "M" ? "M ☒   F ☐" : "M ☐   F ☒"} span={1} />
      <Cell label="Data di nascita" value={formatDate(client.birthDate)} span={1} />
      <Cell label="Luogo di nascita (comune e prov.)" value={client.birthPlace} span={2} />
      <Cell label="Cittadinanza" value={client.citizenship} span={1} />
      <Cell label="Codice fiscale" value={client.fiscalCode} span={1} />
      <Cell label="Indirizzo di residenza (via / piazza e n. civico)" value={address} span={2} />
      <Cell label="Telefono / cellulare" value={client.phone} span={1} />
      <Cell label="Indirizzo e-mail / PEC" value={client.email} span={1} />
      {kind === "mandato" ? (
        <Cell label="Documento d'identità" value={document ? `${document.type} n. ${document.number} · scad. ${formatDate(document.expiry)}` : "—"} span={4} />
      ) : null}
    </div>
  );

  if (kind === "privacy") {
    return (
      <>
        <div className="sheet">
          <OfficeHead />
          <div className="sheet-kicker">
            <span>Protezione dati personali</span>
            <span>Informativa e consenso · GDPR 2016/679</span>
          </div>
          <h1>Consenso al Trattamento dei Dati Personali e Informativa Privacy</h1>
          <div className="sheet-sub">
            Informativa e dichiarazione di consenso ai sensi del Regolamento (UE) 2016/679 (GDPR) e del
            D.Lgs. 30 giugno 2003, n. 196
          </div>

          <div className="sheet-section">
            <div className="sheet-section-title">1 · Dati anagrafici dell&apos;interessato/a</div>
            {anagrafica}
          </div>

          <div className="sheet-section">
            <div className="sheet-section-title">2 · Consenso al trattamento dei dati personali</div>
            <p>
              Avendo preso visione dell&apos;Informativa riportata nella Sezione 4 e riferita all&apos;identità del
              Titolare del trattamento, delle modalità e finalità del trattamento, nonché dei diritti
              dell&apos;interessato, ai sensi e per gli effetti dell&apos;art. 7 e ss. del Regolamento (UE) 2016/679,
              secondo le modalità e nei limiti di cui all&apos;informativa:
            </p>
            <div className="sheet-consents">
              <div className="sheet-consent">
                <p>
                  al trattamento dei dati personali e particolari ai fini dell&apos;espletamento dell&apos;incarico e
                  del mandato conferito a C.S.I. — Centro Servizi Integrati Di Cassano Giuseppe (incluso il
                  macro-gruppo omnibus).
                </p>
                <span className="sheet-boxes">SÌ ☐ &nbsp; NO ☐</span>
              </div>
              <div className="sheet-consent">
                <p>
                  al trattamento dei dati personali e particolari ai fini di eventuali future comunicazioni
                  riguardo prestazioni e servizi offerti da C.S.I. — Centro Servizi Integrati.
                </p>
                <span className="sheet-boxes">SÌ ☐ &nbsp; NO ☐</span>
              </div>
              <div className="sheet-consent">
                <p>
                  al trattamento dei dati personali e particolari per le finalità perseguite da C.S.I. — Centro
                  Servizi Integrati, autorizzando la comunicazione di tali dati alla stessa ed agli Enti o
                  organismi convenzionati o aderenti per finalità istituzionali.
                </p>
                <span className="sheet-boxes">SÌ ☐ &nbsp; NO ☐</span>
              </div>
            </div>
            <div className="sheet-signatures">
              <div className="sheet-sign">Data<span>____ / ____ / __________</span></div>
              <div className="sheet-sign">
                Firma dell&apos;Interessato/a (*)
                <span>(*) Per gli interessati impossibilitati alla sottoscrizione o analfabeti: firma di due testimoni o indicazione della causa dell&apos;impedimento.</span>
              </div>
            </div>
          </div>

          <div className="sheet-section">
            <div className="sheet-section-title">3 · Attestazione operativa e validazione sede</div>
            <div className="sheet-grid" style={{ gridTemplateColumns: "repeat(3, minmax(0, 1fr))" }}>
              <Cell label="Collaboratore / incaricato" value="Cognome e nome" />
              <Cell label="Operatore / validazione sede" value={operator} />
              <Cell label="Timbro ufficiale di sede" value="C.S.I. sede Bari" />
              <Cell label="Data e firma collaboratore" value="" />
              <Cell label="Bari, lì" value="____ / ____ / __________" />
              <Cell label="Firma operatore" value="" />
            </div>
          </div>

          <SheetFoot note={stamp} />
        </div>

        <div className="sheet">
          <OfficeHead />
          <div className="sheet-kicker">
            <span>Protezione dati personali</span>
            <span>Informativa · pag. 2</span>
          </div>
          <h1 style={{ fontSize: 18 }}>Informativa e dichiarazione di consenso (D.Lgs. 196/2003 e GDPR 2016/679)</h1>

          <div className="sheet-section">
            <div className="sheet-section-title">4 · Informativa</div>
            <p>
              Avendo ricevuto, a norma dell&apos;art. 13 del D.Lgs. 30 giugno 2003, n. 196 e del Regolamento (UE)
              2016/679 (GDPR), l&apos;informativa sul trattamento dei propri dati personali, in particolare si
              informa che:
            </p>
            <p>
              <strong>Tipologia dei dati e finalità.</strong> C.S.I. — Centro Servizi Integrati tratterà i dati
              personali forniti, eventualmente anche di natura particolare/sensibile (es. dati sanitari o
              previdenziali), necessari all&apos;espletamento dell&apos;incarico e del mandato conferito. Ambito di
              comunicazione: i dati potranno essere comunicati ad Enti o Organismi pubblici o privati, nazionali
              o esteri, competenti per l&apos;adempimento dell&apos;incarico; i dati personali (esclusi quelli
              sensibili) potranno inoltre essere comunicati a soggetti o organismi convenzionati o aderenti per
              finalità istituzionali.
            </p>
            <p>
              <strong>Modalità, necessità e diritti.</strong> Il trattamento avviene in forma cartacea e/o
              automatizzata con misure idonee di sicurezza. Il conferimento dei dati è essenziale per
              l&apos;esecuzione del mandato (l&apos;eventuale mancato consenso di cui al Punto 1 impedisce lo
              svolgimento dell&apos;attività richiesta). L&apos;interessato può esercitare i diritti di cui agli
              artt. 15–22 del GDPR e all&apos;art. 7 del D.Lgs. 196/2003. Titolare del trattamento: C.S.I. — Centro
              Servizi Integrati Di Cassano Giuseppe, con sede in Piazza Vittorio Emanuele 41, Ceglie del Campo,
              70129 Bari (BA), nella persona del Dirigente Sig. Giuseppe Cassano (Tel. 080 817 8431 · E-mail:
              info.csi.bari@gmail.com).
            </p>
            <div className="sheet-signatures">
              <div className="sheet-sign">Data<span>____ / ____ / __________</span></div>
              <div className="sheet-sign">Firma dell&apos;Interessato/a<span>{fullName}</span></div>
            </div>
          </div>

          <div className="sheet-section">
            <div className="sheet-section-title">Altri consensi · facoltativi</div>
            <p>
              <strong>Punto 1 — Consenso al trattamento dati sensibili ed accesso banche dati.</strong> Esprime il
              consenso al trattamento dei dati personali e particolari/sensibili per le finalità del mandato e
              autorizza l&apos;accesso alle banche dati degli enti eroganti per l&apos;acquisizione dei dati
              necessari all&apos;incarico. <span className="sheet-boxes">SÌ ☐ &nbsp; NO ☐</span>
            </p>
            <p>
              <strong>Punto 2 (facoltativo) — Attività informative, promozionali ed enti convenzionati.</strong>{" "}
              Consente a C.S.I. — Centro Servizi Integrati l&apos;utilizzo dei dati (esclusi quelli sensibili) per
              ulteriori attività statutarie, informative e promozionali sui propri servizi e la comunicazione a
              soggetti o organismi convenzionati/aderenti per finalità istituzionali.{" "}
              <span className="sheet-boxes">SÌ ☐ &nbsp; NO ☐</span>
            </p>
            <p className="muted" style={{ fontSize: 7.5 }}>
              N.B.: il mandato e la relativa validazione si perfezionano con data, timbro e firma dell&apos;operatore
              della Sezione.
            </p>
          </div>

          <SheetFoot note={stamp} />
        </div>
      </>
    );
  }

  return (
    <>
      <div className="sheet">
        <OfficeHead />
        <div className="sheet-kicker">
          <span>Modulistica di conferimento incarico</span>
          <span>Area di interesse · {area.code}</span>
        </div>
        <h1>Mandato di Assistenza e di Rappresentanza</h1>
        <div className="sheet-sub">
          Conferimento incarico amministrativo, fiscale, previdenziale e macro-gruppo omnibus
        </div>

        <div className="sheet-section">
          <div className="sheet-section-title">1 · Dati anagrafici dell&apos;assistito/a (mandante)</div>
          {anagrafica}
        </div>

        <div className="sheet-section">
          <div className="sheet-section-title">2 · Oggetto del mandato e area di interesse</div>
          <p>
            Il/La sottoscritto/a, identificato/a tramite i dati anagrafici sopra riportati, con il presente atto
            conferisce formale mandato ad assisterlo/a e rappresentarlo/a a C.S.I. — Centro Servizi Integrati Di
            Cassano Giuseppe (Sezione Piazza Vittorio Emanuele 41, Ceglie del Campo, 70129 Bari), presso il quale
            elegge domicilio ai sensi dell&apos;art. 47 c.c. per ogni comunicazione inerente all&apos;incarico, nei
            confronti di:
          </p>
          <div className="sheet-grid">
            <Cell label="Area di interesse" value={`${area.code} — ${area.name}`} span={3} />
            <Cell label="Paese (se estero)" value="" span={1} />
            <Cell
              label="Specificazione pratica principale / prestazione richiesta"
              value={mandateType === "omnibus" ? "Tutti i servizi dell'agenzia (macro-gruppo omnibus)" : serviceNames}
              span={4}
            />
            <Cell label="Ente / istituto erogatore destinatario" value="Enti eroganti competenti per l'area di interesse" span={3} />
            <Cell label="Decorrenza" value="Dalla data di sottoscrizione" span={1} />
          </div>

          <div className="clause">
            <p>
              <strong>Macro-gruppo omnibus.</strong>{" "}
              {mandateType === "omnibus"
                ? "☒ SÌ — il presente mandato ricomprende la generalità dei mandati e delle pratiche di assistenza amministrativa, fiscale, previdenziale, assistenziale, ricalcolo pensionistico, estratto contributivo e consulenza integrata conferibili dall'Assistito/a presso C.S.I., autorizzando l'accesso telematico alle banche dati e ai portali degli enti eroganti competenti."
                : "☐ NO — il mandato è limitato ai servizi dell'area di interesse sopra indicati. Per ulteriori servizi sarà necessaria apposita sottoscrizione."}
            </p>
            <p>
              <strong>Durata e revoca.</strong> Il presente mandato{mandateType === "omnibus" ? " omnibus" : ""} ha
              durata di 12 (dodici) mesi dalla data di sottoscrizione ed è revocabile in ogni momento da parte
              dell&apos;Assistito/a mediante comunicazione scritta.
            </p>
          </div>

          <div className="sheet-signatures">
            <div className="sheet-sign">
              Luogo e data
              <span>Bari, ____ / ____ / __________</span>
            </div>
            <div className="sheet-sign">
              Firma leggibile dell&apos;Assistito/a
              <span>Per conferimento del mandato</span>
            </div>
          </div>
        </div>

        <div className="sheet-section">
          <div className="sheet-section-title">3 · Attestazione operativa e validazione sede</div>
          <div className="sheet-grid" style={{ gridTemplateColumns: "repeat(3, minmax(0, 1fr))" }}>
            <Cell label="Collaboratore / incaricato" value="Cognome e nome" />
            <Cell label="Operatore / validazione sede" value={operator} />
            <Cell label="Timbro ufficiale di sede" value="C.S.I. — sede Bari" />
            <Cell label="Data e firma collaboratore" value="" />
            <Cell label="Bari, lì" value="____ / ____ / __________" />
            <Cell label="Firma operatore" value="" />
          </div>
        </div>

        <SheetFoot note={`Area ${area.code} · ${stamp}`} />
      </div>

      <div className="sheet">
        <OfficeHead />
        <div className="sheet-kicker">
          <span>Informativa sul trattamento dei dati personali</span>
          <span>Allegato al mandato · area {area.code}</span>
        </div>
        <h1 style={{ fontSize: 18 }}>
          Informativa sul trattamento dei dati personali (conformità GDPR · WCAG 2.1)
        </h1>

        <div className="sheet-section">
          <div className="sheet-section-title">4 · Informativa</div>
          <p>
            Ai sensi del Regolamento (UE) 2016/679 (GDPR) e del D.Lgs. 196/2003, C.S.I. — Centro Servizi
            Integrati Di Cassano Giuseppe (Sede Piazza Vittorio Emanuele 41, Ceglie del Campo, 70129 Bari — Tel.
            080 817 8431 — E-mail: info.csi.bari@gmail.com), in qualità di Titolare del trattamento nella persona
            del Dirigente Sig. Giuseppe Cassano, informa che i dati personali e particolari/sanitari forniti
            saranno trattati esclusivamente per l&apos;espletamento del mandato e comunicati agli Enti pubblici o
            privati eroganti competenti.
          </p>
          <p>
            Il trattamento avviene in forma cartacea e/o automatizzata con misure idonee di sicurezza; i dati
            potranno essere comunicati a Enti o Organismi pubblici o privati, nazionali o esteri, competenti per
            l&apos;adempimento dell&apos;incarico. L&apos;interessato può esercitare i diritti di cui agli artt.
            15–22 del GDPR e all&apos;art. 7 del D.Lgs. 196/2003.
          </p>
        </div>

        <div className="sheet-section">
          <div className="sheet-section-title">Consensi</div>
          <div className="sheet-consents">
            <div className="sheet-consent">
              <p>
                <strong>Punto 1 — Consenso obbligatorio all&apos;esecuzione del mandato.</strong> L&apos;Assistito/a
                esprime il consenso al trattamento dei dati personali e sensibili per il conseguimento delle
                finalità del mandato e autorizza l&apos;accesso alle banche dati degli enti eroganti.
              </p>
              <span className="sheet-boxes">SÌ ☐ &nbsp; NO ☐</span>
            </div>
            <div className="sheet-consent">
              <p>
                <strong>Punto 2 — Consenso facoltativo per comunicazioni informative.</strong> Consente
                l&apos;utilizzo dei dati di contatto (esclusi dati sensibili) per comunicazioni informative e
                aggiornamenti sui servizi offerti da C.S.I.
              </p>
              <span className="sheet-boxes">SÌ ☐ &nbsp; NO ☐</span>
            </div>
          </div>
          <div className="sheet-signatures">
            <div className="sheet-sign">Data<span>____ / ____ / __________</span></div>
            <div className="sheet-sign">Firma dell&apos;Assistito/a<span>{fullName}</span></div>
          </div>
        </div>

        <SheetFoot note={`Mandato · area ${area.code} · ${stamp}`} />
      </div>
    </>
  );
}
