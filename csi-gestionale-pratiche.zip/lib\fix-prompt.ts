import type { DependencyReport, Finding, WorkflowAnalysis } from "./analysis";
import type { TestLabRun } from "./test-lab";
import type { GuardError } from "./guards";

export function buildFixPrompt(input: {
  findings: Finding[];
  workflow: WorkflowAnalysis;
  dependencies: DependencyReport | null;
  tests: TestLabRun | null;
  errors: GuardError[];
}): string {
  const { findings, workflow, dependencies, tests, errors } = input;
  const selected = findings.length ? findings : [];
  const lines: string[] = [];

  lines.push("# Incarico per code agent — C.S.I. Gestionale pratiche");
  lines.push("");
  lines.push("## Ruolo");
  lines.push(
    "Sei un ingegnere software senior su una codebase Next.js 16 / React 19 / TypeScript strict. Lavori su un gestionale interno per un ufficio italiano di servizi al cittadino. Il tuo compito è correggere i problemi elencati senza cambiare il linguaggio visivo del brand C.S.I. (navy #001C3A, avorio #F7F4ED, oro #C7A45F, Inter Tight / Inter / JetBrains Mono).",
  );
  lines.push("");
  lines.push("## Contesto tecnico");
  lines.push("- App Router in `app/`, componenti in `components/`, dominio e store in `lib/`.");
  lines.push("- Dati operativi in localStorage; i test NON devono scrivere nell'archivio reale.");
  lines.push("- Fixture e casi di test sono tabelle esterne in `public/test-data/`; dopo il run i record `test-*` devono essere assenti.");
  lines.push("- Guardiani runtime in `lib/guards.ts`, error boundary in `components/Guard.tsx`, registro errori in `Diagnostica`.");
  lines.push("- UI in italiano, stampa A4 dei moduli, nessuna regressione sul design system.");
  lines.push("");
  lines.push("## Evidenze raccolte");
  lines.push(
    `- Workflow: ${workflow.metrics.openPractices} pratiche aperte, ${workflow.metrics.blockedPractices} bloccate, ${workflow.metrics.overdueActions} azioni arretrate.`,
  );
  if (dependencies) {
    lines.push(
      `- Dipendenze: ${dependencies.summary.files} file, ${dependencies.summary.edges} archi, ${dependencies.summary.cycles} cicli, ${dependencies.summary.orphans} orfani.`,
    );
  }
  if (tests) {
    lines.push(
      `- Test lab: ${tests.passed}/${tests.results.length} pass, ${tests.failed} fail, ${tests.persistedTestRecords} record di test residui.`,
    );
  }
  lines.push(`- Registro errori: ${errors.length} voci (${errors.filter((e) => e.severity === "critical").length} critiche).`);
  lines.push("");

  if (!selected.length) {
    lines.push("## Nessun finding selezionato");
    lines.push(
      "Non ci sono finding selezionati. Esegui comunque un audit mirato su: controllo copertura mandato, pulizia record di test, gestione errori runtime e regressioni di stampa A4. Riporta solo problemi con evidenza.",
    );
  } else {
    lines.push("## Problemi da correggere");
    selected.forEach((finding, index) => {
      lines.push("");
      lines.push(`### ${index + 1}. [${finding.severity.toUpperCase()}] ${finding.id} — ${finding.title}`);
      lines.push("");
      lines.push(finding.detail);
      if (finding.evidence.length) {
        lines.push("");
        lines.push("Evidenze:");
        finding.evidence.forEach((item) => lines.push(`- ${item}`));
      }
      if (finding.files.length) {
        lines.push("");
        lines.push(`File coinvolti: ${finding.files.map((file) => `\`${file}\``).join(", ")}`);
      }
      lines.push("");
      lines.push(`Direzione richiesta: ${finding.fix}`);
    });
  }

  lines.push("");
  lines.push("## Vincoli");
  lines.push("- Non inserire dati demo o fixture dentro il codice: usa le tabelle esterne in `public/test-data/`.");
  lines.push("- Non eliminare i guardiani né bypassare il registro errori.");
  lines.push("- Non cambiare i token del brand, la tipografia o i layout A4 senza necessità dimostrata.");
  lines.push("- Non introdurre dipendenze senza motivazione e senza aggiornare l'analisi.");
  lines.push("- Mantieni la compatibilità con i backup JSON (versione archivio).");
  lines.push("");
  lines.push("## Criteri di accettazione");
  lines.push("1. La causa alla radice è corretta, non solo il sintomo UI.");
  lines.push("2. `npm run analyze` e `npm run build` passano senza errori TypeScript.");
  lines.push("3. Diagnostica → Test: tutti i casi del fixture esterno passano e `Record di test residui = 0`.");
  lines.push("4. Il registro errori non cresce durante un percorso completo (login → cliente → documenti → mandato → pratica).");
  lines.push("5. Stampa mandato e privacy: 2 pagine A4, footer in fondo, nessun testo tagliato.");
  lines.push("6. Nessuna nuova violazione di accessibilità evidente (focus, label, contrasto).");
  lines.push("");
  lines.push("## Test da eseguire");
  lines.push("- `npm run analyze` (report dipendenze)");
  lines.push("- `npm run build`");
  lines.push("- Diagnostica → Test → Esegui test (fixture esterna)");
  lines.push("- Percorso manuale con un cliente scoperto: il pulsante «Nuovo mandato» deve sbloccare la pratica senza uscire dalla pagina.");
  lines.push("");
  lines.push("## Formato della risposta");
  lines.push("1. Sintesi delle cause individuate (max 5 righe).");
  lines.push("2. Diff o elenco puntuale delle modifiche per file.");
  lines.push("3. Esito dei test e del report dipendenze.");
  lines.push("4. Rischi residui o follow-up.");
  return lines.join("\n");
}

export function buildDiagnosticsReport(input: {
  workflow: WorkflowAnalysis;
  dependencies: DependencyReport | null;
  tests: TestLabRun | null;
  errors: GuardError[];
  findings: Finding[];
}): string {
  const { workflow, dependencies, tests, errors, findings } = input;
  const lines: string[] = [];
  lines.push("# Report diagnostica — C.S.I. Gestionale pratiche");
  lines.push("");
  lines.push(`Generato: ${new Date().toLocaleString("it-IT")}`);
  lines.push("");
  lines.push("## Sintesi");
  lines.push("");
  lines.push("| Indicatore | Valore |");
  lines.push("|---|---|");
  lines.push(`| Pratiche aperte | ${workflow.metrics.openPractices} |`);
  lines.push(`| Pratiche bloccate | ${workflow.metrics.blockedPractices} |`);
  lines.push(`| Azioni arretrate | ${workflow.metrics.overdueActions} |`);
  lines.push(`| Mandati in scadenza 30gg | ${workflow.metrics.expiringMandates} |`);
  lines.push(`| Record orfani | ${workflow.metrics.orphanRecords} |`);
  lines.push(`| File analizzati | ${dependencies?.summary.files ?? "report assente"} |`);
  lines.push(`| Cicli di dipendenza | ${dependencies?.summary.cycles ?? "—"} |`);
  lines.push(`| Test passati | ${tests ? `${tests.passed}/${tests.results.length}` : "non eseguiti"} |`);
  lines.push(`| Record di test residui | ${tests?.persistedTestRecords ?? 0} |`);
  lines.push(`| Errori registrati | ${errors.length} |`);
  lines.push("");
  lines.push("## Workflow");
  lines.push("");
  workflow.stages.forEach((stage) => lines.push(`- ${stage.label}: ${stage.count} (${stage.detail})`));
  lines.push("");
  lines.push("## Finding");
  lines.push("");
  if (!findings.length) {
    lines.push("Nessun finding rilevato.");
  } else {
    findings.forEach((finding) => {
      lines.push(`### [${finding.severity.toUpperCase()}] ${finding.id} — ${finding.title}`);
      lines.push("");
      lines.push(finding.detail);
      if (finding.evidence.length) {
        lines.push("");
        finding.evidence.forEach((item) => lines.push(`- ${item}`));
      }
      if (finding.files.length) {
        lines.push("");
        lines.push(`File: ${finding.files.map((file) => `\`${file}\``).join(", ")}`);
      }
      lines.push("");
    });
  }
  lines.push("## Test");
  lines.push("");
  if (!tests) {
    lines.push("Laboratorio non eseguito.");
  } else {
    lines.push(`Fixture: \`${tests.fixturePath}\` · casi: \`${tests.casesPath}\``);
    lines.push("");
    lines.push("| ID | Area | Esito | Atteso | Ottenuto | ms |");
    lines.push("|---|---|---|---|---|---|");
    tests.results.forEach((result) => {
      lines.push(
        `| ${result.id} | ${result.area} | ${result.pass ? "PASS" : "FAIL"} | ${result.expected} | ${result.actual} | ${result.durationMs} |`,
      );
    });
  }
  lines.push("");
  lines.push("## Dipendenze");
  lines.push("");
  if (!dependencies) {
    lines.push("Report non disponibile: eseguire `npm run analyze`.");
  } else {
    lines.push(`Generato: ${new Date(dependencies.generatedAt).toLocaleString("it-IT")}`);
    lines.push("");
    lines.push("| Pacchetto | Import |");
    lines.push("|---|---|");
    dependencies.packages.slice(0, 12).forEach((pkg) => lines.push(`| ${pkg.name} | ${pkg.count} |`));
    if (dependencies.cycles.length) {
      lines.push("");
      lines.push("Cicli:");
      dependencies.cycles.forEach((cycle) => lines.push(`- ${cycle.join(" → ")}`));
    }
  }
  lines.push("");
  lines.push("## Errori");
  lines.push("");
  if (!errors.length) {
    lines.push("Nessun errore nel registro.");
  } else {
    errors.slice(0, 15).forEach((error) => {
      lines.push(`- [${error.severity}] ${error.section} · ${new Date(error.at).toLocaleString("it-IT")} — ${error.message}`);
    });
  }
  return lines.join("\n");
}
