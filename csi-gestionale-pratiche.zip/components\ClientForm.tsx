"use client";

import { useState } from "react";
import type { Client } from "@/lib/types";

export interface ClientFormValues {
  firstName: string;
  lastName: string;
  sex: "M" | "F";
  birthDate: string;
  birthPlace: string;
  citizenship: string;
  fiscalCode: string;
  address: string;
  cap: string;
  city: string;
  province: string;
  phone: string;
  email: string;
  notes: string;
}

const empty: ClientFormValues = {
  firstName: "",
  lastName: "",
  sex: "F",
  birthDate: "",
  birthPlace: "",
  citizenship: "Italiana",
  fiscalCode: "",
  address: "",
  cap: "",
  city: "Bari",
  province: "BA",
  phone: "",
  email: "",
  notes: "",
};

export function ClientForm({
  initial,
  onSubmit,
  submitLabel = "Salva anagrafica",
  onCancel,
  compact = false,
}: {
  initial?: Partial<Client>;
  onSubmit: (values: ClientFormValues) => void;
  submitLabel?: string;
  onCancel?: () => void;
  compact?: boolean;
}) {
  const [values, setValues] = useState<ClientFormValues>({
    ...empty,
    ...initial,
    notes: initial?.notes ?? "",
  });
  const [error, setError] = useState<string | null>(null);

  const set = <K extends keyof ClientFormValues>(key: K, value: ClientFormValues[K]) =>
    setValues((prev) => ({ ...prev, [key]: value }));

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!values.firstName.trim() || !values.lastName.trim()) {
      setError("Nome e cognome sono obbligatori.");
      return;
    }
    if (!values.fiscalCode.trim() || values.fiscalCode.trim().length < 11) {
      setError("Inserisci un codice fiscale valido (11 caratteri minimi).");
      return;
    }
    if (!values.birthDate) {
      setError("La data di nascita è obbligatoria.");
      return;
    }
    if (values.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) {
      setError("L'indirizzo e-mail non è valido.");
      return;
    }
    setError(null);
    onSubmit({
      ...values,
      fiscalCode: values.fiscalCode.toUpperCase().replace(/\s/g, ""),
      province: values.province.toUpperCase().slice(0, 2),
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className={`form-grid${compact ? "" : " form-grid--3"}`}>
        <div className="field">
          <label className="field-label" htmlFor="cognome">Cognome<span className="req">*</span></label>
          <input
            id="cognome"
            className="input"
            value={values.lastName}
            onChange={(e) => set("lastName", e.target.value)}
            autoComplete="family-name"
            required
          />
        </div>
        <div className="field">
          <label className="field-label" htmlFor="nome">Nome<span className="req">*</span></label>
          <input
            id="nome"
            className="input"
            value={values.firstName}
            onChange={(e) => set("firstName", e.target.value)}
            autoComplete="given-name"
            required
          />
        </div>
        <div className="field">
          <label className="field-label" htmlFor="sesso">Sesso</label>
          <select id="sesso" className="select" value={values.sex} onChange={(e) => set("sex", e.target.value as "M" | "F")}>
            <option value="F">F</option>
            <option value="M">M</option>
          </select>
        </div>
        <div className="field">
          <label className="field-label" htmlFor="nascita">Data di nascita<span className="req">*</span></label>
          <input
            id="nascita"
            type="date"
            className="input"
            value={values.birthDate}
            onChange={(e) => set("birthDate", e.target.value)}
            required
          />
        </div>
        <div className="field">
          <label className="field-label" htmlFor="luogo">Luogo di nascita (comune e prov.)</label>
          <input
            id="luogo"
            className="input"
            value={values.birthPlace}
            onChange={(e) => set("birthPlace", e.target.value)}
            placeholder="Bari (BA)"
          />
        </div>
        <div className="field">
          <label className="field-label" htmlFor="cittadinanza">Cittadinanza</label>
          <input
            id="cittadinanza"
            className="input"
            value={values.citizenship}
            onChange={(e) => set("citizenship", e.target.value)}
          />
        </div>
        <div className="field">
          <label className="field-label" htmlFor="cf">Codice fiscale<span className="req">*</span></label>
          <input
            id="cf"
            className="input input--mono"
            value={values.fiscalCode}
            onChange={(e) => set("fiscalCode", e.target.value.toUpperCase())}
            maxLength={16}
            placeholder="RSSMRA80A01A662X"
            required
          />
        </div>
        <div className="field">
          <label className="field-label" htmlFor="indirizzo">Indirizzo di residenza</label>
          <input
            id="indirizzo"
            className="input"
            value={values.address}
            onChange={(e) => set("address", e.target.value)}
            placeholder="Via / piazza e n. civico"
          />
        </div>
        <div className="field">
          <label className="field-label" htmlFor="cap">CAP</label>
          <input
            id="cap"
            className="input input--mono"
            value={values.cap}
            onChange={(e) => set("cap", e.target.value.replace(/\D/g, "").slice(0, 5))}
            placeholder="70129"
          />
        </div>
        <div className="field">
          <label className="field-label" htmlFor="comune">Comune</label>
          <input id="comune" className="input" value={values.city} onChange={(e) => set("city", e.target.value)} />
        </div>
        <div className="field">
          <label className="field-label" htmlFor="provincia">Provincia</label>
          <input
            id="provincia"
            className="input input--mono"
            value={values.province}
            onChange={(e) => set("province", e.target.value.toUpperCase().slice(0, 2))}
          />
        </div>
        <div className="field">
          <label className="field-label" htmlFor="telefono">Telefono / cellulare</label>
          <input
            id="telefono"
            className="input"
            value={values.phone}
            onChange={(e) => set("phone", e.target.value)}
            autoComplete="tel"
          />
        </div>
        <div className="field">
          <label className="field-label" htmlFor="email">E-mail / PEC</label>
          <input
            id="email"
            type="email"
            className="input"
            value={values.email}
            onChange={(e) => set("email", e.target.value)}
            autoComplete="email"
          />
        </div>
        {!compact ? (
          <div className="field span-3">
            <label className="field-label" htmlFor="note">Note operative</label>
            <textarea
              id="note"
              className="textarea"
              value={values.notes}
              onChange={(e) => set("notes", e.target.value)}
              placeholder="Lingua di assistenza, esigenze particolari, recapiti alternativi…"
              rows={2}
            />
          </div>
        ) : null}
      </div>

      {error ? <div className="error-text mt-16">{error}</div> : null}

      <div className="form-actions">
        <button type="submit" className="btn">{submitLabel}</button>
        {onCancel ? (
          <button type="button" className="btn btn--ghost" onClick={onCancel}>
            Annulla
          </button>
        ) : null}
        <span className="hint" style={{ marginLeft: "auto" }}>
          I campi contrassegnati con <span style={{ color: "var(--gold-deep)" }}>*</span> sono obbligatori.
        </span>
      </div>
    </form>
  );
}
