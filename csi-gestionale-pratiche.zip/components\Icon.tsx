import type { SVGProps } from "react";

export type IconName =
  | "grid"
  | "folder"
  | "users"
  | "layers"
  | "shield"
  | "calendar"
  | "search"
  | "plus"
  | "chevron-right"
  | "chevron-left"
  | "check"
  | "x"
  | "printer"
  | "upload"
  | "bell"
  | "qr"
  | "logout"
  | "phone"
  | "file"
  | "arrow-right"
  | "clock"
  | "alert"
  | "lock"
  | "user"
  | "mail"
  | "external"
  | "menu"
  | "download"
  | "eye"
  | "trash"
  | "link"
  | "building"
  | "globe"
  | "coins"
  | "calculator"
  | "activity"
  | "spark"
  | "check-circle"
  | "info"
  | "edit"
  | "pen";

const paths: Record<IconName, React.ReactNode> = {
  grid: (
    <>
      <rect x="3.5" y="3.5" width="7" height="7" />
      <rect x="13.5" y="3.5" width="7" height="7" />
      <rect x="3.5" y="13.5" width="7" height="7" />
      <rect x="13.5" y="13.5" width="7" height="7" />
    </>
  ),
  folder: (
    <path d="M3.5 6.5h5l1.8 2h10.2v11.5h-17zM3.5 6.5v-2h5.4l1.6 2" />
  ),
  users: (
    <>
      <circle cx="9" cy="8" r="3.2" />
      <path d="M3.5 20c0-3 2.5-5 5.5-5s5.5 2 5.5 5" />
      <path d="M16 5.4a3.2 3.2 0 0 1 0 5.2M17.4 15.2c2 .5 3.4 2.2 3.4 4.3" />
    </>
  ),
  layers: (
    <>
      <path d="m12 3.5 8.5 4.7L12 12.9 3.5 8.2z" />
      <path d="m3.5 12.4 8.5 4.7 8.5-4.7M3.5 16.6l8.5 4.7 8.5-4.7" />
    </>
  ),
  shield: (
    <>
      <path d="M12 3.2 19 6v6c0 4.4-2.9 7.6-7 8.8-4.1-1.2-7-4.4-7-8.8V6z" />
      <path d="m9 12 2.2 2.2L15.4 10" />
    </>
  ),
  calendar: (
    <>
      <rect x="3.5" y="5" width="17" height="15.5" />
      <path d="M3.5 9.5h17M8 3.5v3M16 3.5v3" />
    </>
  ),
  search: (
    <>
      <circle cx="10.5" cy="10.5" r="6" />
      <path d="m15 15 5 5" />
    </>
  ),
  plus: <path d="M12 5v14M5 12h14" />,
  "chevron-right": <path d="m9 5 7 7-7 7" />,
  "chevron-left": <path d="m15 5-7 7 7 7" />,
  check: <path d="m4.5 12.5 5 5 10-10" />,
  x: <path d="m6 6 12 12M18 6 6 18" />,
  printer: (
    <>
      <path d="M7 9V3.5h10V9" />
      <rect x="3.5" y="9" width="17" height="8.5" />
      <path d="M7 14.5h10v6H7z" />
    </>
  ),
  upload: (
    <>
      <path d="M12 16.5V4.5M7.5 9 12 4.5 16.5 9" />
      <path d="M4 15.5v4h16v-4" />
    </>
  ),
  bell: (
    <>
      <path d="M18 9.5a6 6 0 1 0-12 0c0 5-2 6.5-2 6.5h16s-2-1.5-2-6.5" />
      <path d="M10 20a2.2 2.2 0 0 0 4 0" />
    </>
  ),
  qr: (
    <>
      <rect x="3.5" y="3.5" width="6" height="6" />
      <rect x="14.5" y="3.5" width="6" height="6" />
      <rect x="3.5" y="14.5" width="6" height="6" />
      <path d="M14.5 14.5h2.5v2.5h-2.5zM20.5 14.5v6h-3M14.5 20.5h2.5" />
    </>
  ),
  logout: (
    <>
      <path d="M10 4H4v16h6" />
      <path d="M14 8l4 4-4 4M9 12h9" />
    </>
  ),
  phone: (
    <path d="M7.2 3.5h3l1.4 4.2-2 1.6a12 12 0 0 0 5.1 5.1l1.6-2 4.2 1.4v3c0 1.2-1 2.2-2.2 2.2A15.8 15.8 0 0 1 5 5.7c0-1.2 1-2.2 2.2-2.2z" />
  ),
  file: (
    <>
      <path d="M6 3.5h8l4 4v13H6z" />
      <path d="M14 3.5v4.2h4.2M9 12h6M9 15.5h6" />
    </>
  ),
  "arrow-right": <path d="M4 12h16M14 6l6 6-6 6" />,
  clock: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7.5V12l3.2 2" />
    </>
  ),
  alert: (
    <>
      <path d="M12 3.8 21 20H3z" />
      <path d="M12 9v5M12 17h.01" />
    </>
  ),
  lock: (
    <>
      <rect x="5" y="10" width="14" height="10.5" />
      <path d="M8.5 10V7.5a3.5 3.5 0 0 1 7 0V10" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8.2" r="3.6" />
      <path d="M5 20c0-3.4 3-5.8 7-5.8s7 2.4 7 5.8" />
    </>
  ),
  mail: (
    <>
      <rect x="3.5" y="5.5" width="17" height="13" />
      <path d="m3.8 6.4 8.2 6.2 8.2-6.2" />
    </>
  ),
  external: (
    <>
      <path d="M14 4h6v6M20 4l-9 9" />
      <path d="M18 14v5.5H4.5V6H10" />
    </>
  ),
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  download: (
    <>
      <path d="M12 4v12M7.5 11.5 12 16l4.5-4.5" />
      <path d="M4 19.5h16" />
    </>
  ),
  eye: (
    <>
      <path d="M2.5 12s3.5-6.5 9.5-6.5S21.5 12 21.5 12s-3.5 6.5-9.5 6.5S2.5 12 2.5 12z" />
      <circle cx="12" cy="12" r="2.7" />
    </>
  ),
  trash: (
    <>
      <path d="M4 7h16M9 7V4.5h6V7M6 7l1 13h10l1-13" />
    </>
  ),
  link: (
    <>
      <path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1.5 1.5" />
      <path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1.5-1.5" />
    </>
  ),
  building: (
    <>
      <path d="M5 20.5V4h9v16.5M14 9h5v11.5M3 20.5h18" />
      <path d="M8 7.5h3M8 11h3M8 14.5h3M17 12.5h.01M17 16h.01" />
    </>
  ),
  globe: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M3.5 12h17M12 3.5c2.4 2.4 3.6 5.3 3.6 8.5s-1.2 6.1-3.6 8.5c-2.4-2.4-3.6-5.3-3.6-8.5s1.2-6.1 3.6-8.5z" />
    </>
  ),
  coins: (
    <>
      <ellipse cx="12" cy="6.5" rx="7" ry="3" />
      <path d="M5 6.5v5c0 1.7 3.1 3 7 3s7-1.3 7-3v-5" />
      <path d="M5 11.5v5c0 1.7 3.1 3 7 3s7-1.3 7-3v-5" />
    </>
  ),
  calculator: (
    <>
      <rect x="5" y="3" width="14" height="18" />
      <path d="M8 6.5h8M8.5 11h.01M12 11h.01M15.5 11h.01M8.5 14.5h.01M12 14.5h.01M15.5 14.5h.01M8.5 18h.01M12 18h.01M15.5 18h.01" />
    </>
  ),
  activity: (
    <>
      <path d="M3 12h4l2.5-6 4 12 2.5-6H21" />
    </>
  ),
  spark: <path d="M12 3.5 13.8 10 20.5 12l-6.7 2L12 20.5 10.2 14 3.5 12l6.7-2z" />,
  "check-circle": (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="m8.5 12 2.4 2.4 4.8-4.8" />
    </>
  ),
  info: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 11v5.5M12 7.8h.01" />
    </>
  ),
  edit: (
    <>
      <path d="M4 20h4.2L20 8.2 15.8 4 4 15.8z" />
      <path d="m13.8 6 4.2 4.2" />
    </>
  ),
  pen: (
    <>
      <path d="M4 20h4l11-11-4-4L4 16z" />
      <path d="m14 6 4 4" />
    </>
  ),
};

export function Icon({
  name,
  size = 18,
  ...props
}: { name: IconName; size?: number } & SVGProps<SVGSVGElement>) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="square"
      strokeLinejoin="miter"
      aria-hidden="true"
      {...props}
    >
      {paths[name]}
    </svg>
  );
}
