import { NextResponse } from "next/server";
import os from "node:os";
import { apiGuard } from "@/lib/api-guard";

export const dynamic = "force-dynamic";

export const GET = apiGuard("api/network", async (request) => {
  const headers = request.headers;
  const url = new URL(request.url);
  const host = headers.get("x-forwarded-host") ?? headers.get("host") ?? url.host;
  const proto = headers.get("x-forwarded-proto") ?? url.protocol.replace(":", "");
  const [hostname, port] = host.split(":");
  const isLocal = hostname === "localhost" || hostname === "127.0.0.1" || hostname === "::1";

  let lan: string | null = null;
  if (isLocal) {
    for (const entries of Object.values(os.networkInterfaces())) {
      for (const entry of entries ?? []) {
        if (entry.family === "IPv4" && !entry.internal) {
          lan = entry.address;
          break;
        }
      }
      if (lan) break;
    }
  }

  const effectiveHost = isLocal && lan ? `${lan}:${port || (proto === "https" ? "443" : "80")}` : host;
  return NextResponse.json({
    base: `${proto}://${effectiveHost}`,
    isLocal,
    lan,
    host,
  });
});
