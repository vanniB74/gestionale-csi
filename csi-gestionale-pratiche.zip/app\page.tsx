import Link from "next/link";
import { Logo } from "@/components/Logo";
import { SocialLinks } from "@/components/SocialLinks";
import { Icon } from "@/components/Icon";
import { OFFICE } from "@/lib/catalog";

const steps = [
  {
    n: "01",
    title: "Appuntamento",
    text: "Si registra data e ora dell'accoglienza. L'agenda dell'ufficio resta allineata.",
  },
  {
    n: "02",
    title: "Anagrafica",
    text: "Dati personali, codice fiscale e recapiti del cliente, con nota operativa.",
  },
  {
    n: "03",
    title: "Documenti",
    text: "Fronte e retro della carta d'identità e codice fiscale, in contenitori separati.",
  },
  {
    n: "04",
    title: "Moduli",
    text: "Mandato e privacy si compilano dai dati raccolti, pronti per stampa e firma.",
  },
  {
    n: "05",
    title: "Pratica",
    text: "Numero interno, servizio e descrizione. Il controllo del mandato avviene prima.",
  },
];

export default function WelcomePage() {
  return (
    <div className="welcome">
      <div className="wl-wrap">
        <nav className="wl-nav">
          <Logo variant="light" width={196} priority />
          <div className="wl-nav-right">
            <a className="wl-nav-link" href="#percorso">
              Il percorso
            </a>
            <SocialLinks label={null} />
            <Link
              href="/login"
              className="btn btn--ghost btn--sm"
              style={{ color: "var(--ivory)", borderColor: "rgba(247,244,237,0.28)" }}
            >
              Area riservata
            </Link>
          </div>
        </nav>

        <section className="wl-hero">
          <div className="wl-copy">
            <div className="wl-eyebrow">Gestionale interno · Bari</div>
            <h1 className="wl-title">
              Un solo sportello.
              <br />
              <em>Una sola voce.</em>
            </h1>
            <p className="wl-lede">
              Anagrafiche, documenti, mandati e avanzamento delle pratiche: il lavoro dell&apos;ufficio in un
              unico spazio, dal primo appuntamento alla firma.
            </p>

            <div className="wl-actions">
              <Link href="/login" className="btn btn--light">
                Accedi al gestionale <Icon name="arrow-right" />
              </Link>
              <a href="#percorso" className="wl-link">
                Il percorso di una pratica <Icon name="chevron-right" />
              </a>
            </div>

            <div className="mt-24">
              <SocialLinks size="md" label="Seguici" />
            </div>
          </div>

          <figure className="wl-media">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/brand/csi-welcome.gif"
              alt="Animazione dello sportello digitale C.S.I.: un portatile con il marchio C.S.I. illuminato"
              width={560}
              height={371}
            />
            <figcaption>
              <span>Sportello C.S.I. · anteprima</span>
              <span className="mono">MMXXVI</span>
            </figcaption>
          </figure>
        </section>

        <div className="wl-stats">
          <div className="wl-stat">
            <div className="wl-stat-value">06</div>
            <div className="wl-stat-label">Aree di servizio</div>
          </div>
          <div className="wl-stat">
            <div className="wl-stat-value">12 mesi</div>
            <div className="wl-stat-label">Validità del mandato</div>
          </div>
          <div className="wl-stat">
            <div className="wl-stat-value">01</div>
            <div className="wl-stat-label">Sportello unico</div>
          </div>
        </div>
      </div>

      <section className="wl-flow" id="percorso">
        <div className="wl-wrap">
          <div className="wl-flow-head">
            <div>
              <span className="eyebrow">Il percorso</span>
              <h2>Dall&apos;accoglienza alla pratica,<br />senza salti di pagina.</h2>
            </div>
            <p>
              L&apos;ordine logico del lavoro è già nel gestionale: ogni passaggio alimenta il successivo e
              resta tracciato nella scheda del cliente.
            </p>
          </div>

          <div className="wl-steps">
            {steps.map((step) => (
              <div className="wl-step" key={step.n}>
                <div className="wl-step-num">{step.n}</div>
                <h3>{step.title}</h3>
                <p>{step.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="wl-foot">
        <div className="wl-wrap">
          <div className="wl-foot-grid">
            <div className="wl-foot-brand">
              <Logo variant="light" width={150} />
            </div>

            <div className="wl-foot-meta">
              <div>
                <strong>Sede</strong>
                {OFFICE.address}
                <br />
                {OFFICE.city}
              </div>
              <div>
                <strong>Contatti</strong>
                Tel. {OFFICE.phone}
                <br />
                {OFFICE.email}
              </div>
              <div>
                <strong>Online</strong>
                {OFFICE.site}
                <br />
                <Link href="/login" style={{ borderBottom: "1px solid rgba(199,164,95,.5)" }}>
                  Accesso riservato
                </Link>
              </div>
              <div>
                <strong>Segui C.S.I.</strong>
                <SocialLinks label={null} />
              </div>
            </div>
          </div>

          <div className="wl-copyline">
            <span>© 2026 C.S.I. — Centro Servizi Integrati · {OFFICE.vat}</span>
            <span>Brand book 2025 · Navy / Avorio / Oro</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
