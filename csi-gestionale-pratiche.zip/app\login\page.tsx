"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import QRCode from "qrcode";
import { useData } from "@/lib/store";
import { Logo } from "@/components/Logo";
import { Icon } from "@/components/Icon";
import { SocialLinks } from "@/components/SocialLinks";
import { fullName } from "@/lib/format";

interface PairToken {
  token: string;
  expiresAt: number;
}

interface NetworkInfo {
  base: string;
  isLocal: boolean;
  lan: string | null;
}

export default function LoginPage() {
  const {
    hydrated,
    session,
    currentUser,
    login,
    loginWithQR,
    loginFromPairing,
    db,
    deviceId,
  } = useData();
  const router = useRouter();

  const [tab, setTab] = useState<"credenziali" | "qr">("credenziali");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const [pairToken, setPairToken] = useState<string | null>(null);
  const [pairChecked, setPairChecked] = useState(false);
  const [pairDone, setPairDone] = useState(false);
  const [pairBusy, setPairBusy] = useState(false);

  const [qrBase, setQrBase] = useState("");
  const [network, setNetwork] = useState<NetworkInfo | null>(null);
  const [tokens, setTokens] = useState<PairToken[]>([]);
  const [qr, setQr] = useState("");
  const [remain, setRemain] = useState(20);
  const [pairMode, setPairMode] = useState<"server" | "fallback">("server");

  const boundStaff = db.staff.filter((member) => member.deviceId && member.deviceId === deviceId);
  const latest = tokens[tokens.length - 1];

  useEffect(() => {
    const token = new URLSearchParams(window.location.search).get("pair");
    setPairToken(token);
    setPairChecked(true);
  }, []);

  useEffect(() => {
    if (hydrated && session && pairChecked && !pairToken) {
      router.replace("/dashboard");
    }
  }, [hydrated, session, pairChecked, pairToken, router]);

  useEffect(() => {
    if (tab !== "qr") return;
    let alive = true;
    let rotation: number | undefined;
    let tick: number | undefined;

    const boot = async () => {
      let base = window.location.origin;
      try {
        const response = await fetch("/api/network");
        if (response.ok) {
          const info = (await response.json()) as NetworkInfo;
          base = info.base;
          if (alive) setNetwork(info);
        }
      } catch {
        // rete locale non rilevata: resta l'origine corrente
      }
      if (!alive) return;
      setQrBase(base);

      const createToken = async () => {
        let next: PairToken;
        try {
          const response = await fetch("/api/pair/create", { method: "POST" });
          if (!response.ok) throw new Error("pairing non disponibile");
          const data = (await response.json()) as { token: string; expiresAt: number };
          next = { token: data.token, expiresAt: data.expiresAt };
          if (alive) setPairMode("server");
        } catch {
          next = {
            token: Math.random().toString(36).slice(2, 8).toUpperCase(),
            expiresAt: Date.now() + 120_000,
          };
          if (alive) setPairMode("fallback");
        }
        if (!alive) return;
        setTokens((prev) => [...prev.slice(-4), next]);
        setRemain(20);
      };

      await createToken();
      rotation = window.setInterval(() => void createToken(), 20_000);
      tick = window.setInterval(() => setRemain((value) => Math.max(0, value - 1)), 1_000);
    };

    void boot();
    return () => {
      alive = false;
      if (rotation) window.clearInterval(rotation);
      if (tick) window.clearInterval(tick);
    };
  }, [tab]);

  useEffect(() => {
    if (!latest || !qrBase) return;
    let alive = true;
    const url = `${qrBase}/login?pair=${latest.token}`;
    QRCode.toDataURL(url, {
      margin: 1,
      width: 344,
      color: { dark: "#001C3A", light: "#FFFFFF" },
    })
      .then((data) => {
        if (alive) setQr(data);
      })
      .catch(() => setQr(""));
    return () => {
      alive = false;
    };
  }, [latest, qrBase]);

  useEffect(() => {
    if (tab !== "qr" || !tokens.length) return;
    let stopped = false;

    const poll = async () => {
      for (const item of tokens) {
        if (stopped) return;
        try {
          const response = await fetch(`/api/pair/status?token=${item.token}`);
          if (!response.ok) continue;
          const data = (await response.json()) as {
            status: string;
            staffId: string | null;
            staffName: string | null;
          };
          if (data.status === "claimed" && data.staffId) {
            stopped = true;
            const result = loginFromPairing(data.staffId);
            if (result.ok) {
              router.replace("/dashboard");
              return;
            }
            setError(result.error ?? "Accesso non riuscito.");
          }
        } catch {
          // il polling riprova al prossimo ciclo
        }
      }
    };

    void poll();
    const id = window.setInterval(() => void poll(), 2_000);
    return () => {
      stopped = true;
      window.clearInterval(id);
    };
  }, [tab, tokens, loginFromPairing, router]);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    const result = login(username, password);
    if (!result.ok || !result.staff) {
      setError(result.error ?? "Accesso non riuscito.");
      return;
    }
    if (pairToken) {
      await authorizePair(result.staff.id, `${result.staff.firstName} ${result.staff.lastName}`);
      return;
    }
    router.replace("/dashboard");
  };

  const quickFill = (user: string, secret: string) => {
    setUsername(user);
    setPassword(secret);
    setError(null);
  };

  const qrLogin = (staffId: string) => {
    const result = loginWithQR(staffId);
    if (!result.ok) {
      setError(result.error ?? "Accesso QR non riuscito.");
      return;
    }
    router.replace("/dashboard");
  };

  const authorizePair = async (staffId: string, staffName: string) => {
    if (!pairToken) return;
    setPairBusy(true);
    setError(null);
    try {
      const response = await fetch("/api/pair/claim", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: pairToken, staffId, staffName }),
      });
      const data = (await response.json()) as { ok?: boolean; error?: string };
      if (!response.ok || !data.ok) {
        setError(data.error ?? "Richiesta scaduta: genera un nuovo QR sul computer.");
        return;
      }
      setPairDone(true);
    } catch {
      setError("Impossibile completare l'autorizzazione. Verifica la connessione.");
    } finally {
      setPairBusy(false);
    }
  };

  const pairPanel = () => {
    if (pairDone) {
      return (
        <div className="qr-panel" style={{ textAlign: "center" }}>
          <span className="empty-icon" style={{ color: "var(--ok)", borderColor: "rgba(45,92,77,.35)" }}>
            <Icon name="check" size={20} />
          </span>
          <h1 style={{ fontFamily: "var(--font-display)", fontSize: 22, letterSpacing: "-0.02em" }}>
            Accesso autorizzato
          </h1>
          <p className="hint" style={{ maxWidth: "36ch" }}>
            Il computer è stato collegato al tuo profilo. Puoi chiudere questa pagina e tornare alla postazione.
          </p>
          <Link href="/dashboard" className="btn btn--ghost btn--sm">
            Apri il gestionale su questo telefono
          </Link>
        </div>
      );
    }

    if (currentUser) {
      return (
        <div className="qr-panel" style={{ textAlign: "center" }}>
          <span className="empty-icon">
            <Icon name="qr" size={20} />
          </span>
          <span className="eyebrow eyebrow--plain">Richiesta dal computer</span>
          <h1 style={{ fontFamily: "var(--font-display)", fontSize: 22, letterSpacing: "-0.02em" }}>
            Autorizza l&apos;accesso
          </h1>
          <p className="hint" style={{ maxWidth: "36ch" }}>
            Il computer ha richiesto di accedere come <strong>{fullName(currentUser)}</strong>. Confermando,
            il gestionale si aprirà sulla postazione.
          </p>
          <div className="row" style={{ justifyContent: "center", flexWrap: "wrap" }}>
            <button
              type="button"
              className="btn"
              disabled={pairBusy}
              onClick={() => void authorizePair(currentUser.id, fullName(currentUser))}
            >
              {pairBusy ? "Autorizzazione…" : "Autorizza accesso"}
            </button>
            <button
              type="button"
              className="btn btn--ghost"
              onClick={() => {
                setPairToken(null);
                router.replace("/dashboard");
              }}
            >
              Annulla
            </button>
          </div>
          {error ? <div className="error-text">{error}</div> : null}
        </div>
      );
    }

    return null;
  };

  return (
    <div className="login">
      <aside className="login-art">
        <Link href="/" aria-label="Torna alla pagina di benvenuto">
          <Logo variant="light" width={210} priority className="login-art-logo" />
        </Link>

        <div className="login-quote">
          <h2>
            Al servizio delle persone, <em>ogni giorno.</em>
          </h2>
          <p>
            Sei aree di servizio, un solo sportello, una sola voce. Il gestionale tiene insieme anagrafiche,
            documenti, mandati e pratiche dell&apos;ufficio.
          </p>

          <figure className="login-media">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/brand/csi-welcome-poster.jpg"
              alt="Il marchio C.S.I. in rilievo dorato sullo scrittoio dell'ufficio"
              width={360}
              height={239}
            />
          </figure>

          <div className="mt-24">
            <SocialLinks size="md" label="Seguici" />
          </div>
        </div>

        <div className="login-meta">
          <span>
            {db.webmaster.office || "Ceglie del Campo · Bari"}
            <br />
            Tel. 080 817 8431
          </span>
          <span>Brand book 2025 · v1.0</span>
        </div>
      </aside>

      <main className="login-panel">
        <div className="login-card">
          <Link href="/" className="login-mobile-logo" aria-label="C.S.I. — pagina di benvenuto">
            <Logo width={168} />
          </Link>

          {pairToken && pairChecked ? (
            <>
              {!pairDone && !currentUser ? (
                <>
                  <span className="eyebrow">Abbinamento telefono</span>
                  <h1>Accesso dal computer</h1>
                  <p className="lede">
                    Accedi con le tue credenziali per autorizzare la postazione che ha generato il QR.
                  </p>
                  <div className="note mt-16">
                    <strong>Richiesta di accesso in corso.</strong> Il computer ha generato un QR per entrare nel
                    gestionale. Accedi qui con il tuo profilo: la postazione si sbloccherà automaticamente.
                  </div>
                </>
              ) : null}

              {!pairDone && !currentUser ? (
                <form className="login-form mt-16" onSubmit={submit}>
                  <div className="field">
                    <label className="field-label" htmlFor="username">Nome utente</label>
                    <input
                      id="username"
                      className="input"
                      value={username}
                      onChange={(event) => setUsername(event.target.value)}
                      autoComplete="username"
                      placeholder="nome.cognome"
                      required
                    />
                  </div>
                  <div className="field">
                    <label className="field-label" htmlFor="password">Password</label>
                    <input
                      id="password"
                      type="password"
                      className="input"
                      value={password}
                      onChange={(event) => setPassword(event.target.value)}
                      autoComplete="current-password"
                      placeholder="••••••••"
                      required
                    />
                  </div>
                  {error ? <div className="error-text">{error}</div> : null}
                  <button type="submit" className="btn btn--block" disabled={!hydrated || pairBusy}>
                    {pairBusy ? "Autorizzazione…" : "Accedi e autorizza"} <Icon name="arrow-right" />
                  </button>
                </form>
              ) : (
                pairPanel()
              )}

              <div className="mt-24">
                <Link href="/" className="link">
                  ← Pagina di benvenuto
                </Link>
              </div>
            </>
          ) : (
            <>
              <span className="eyebrow">Area riservata</span>
              <h1>Accesso operatori</h1>
              <p className="lede">
                Entra con le credenziali fornite dal webmaster oppure inquadra il QR code con il telefono
                abbinato.
              </p>

              <div className="login-tabs" role="tablist" aria-label="Modalità di accesso">
                <button
                  type="button"
                  role="tab"
                  aria-selected={tab === "credenziali"}
                  className={`login-tab${tab === "credenziali" ? " active" : ""}`}
                  onClick={() => {
                    setTab("credenziali");
                    setError(null);
                  }}
                >
                  <Icon name="lock" /> Credenziali
                </button>
                <button
                  type="button"
                  role="tab"
                  aria-selected={tab === "qr"}
                  className={`login-tab${tab === "qr" ? " active" : ""}`}
                  onClick={() => {
                    setTab("qr");
                    setError(null);
                  }}
                >
                  <Icon name="qr" /> QR code
                </button>
              </div>

              {tab === "credenziali" ? (
                <form className="login-form" onSubmit={submit}>
                  <div className="field">
                    <label className="field-label" htmlFor="username">Nome utente</label>
                    <input
                      id="username"
                      className="input"
                      value={username}
                      onChange={(event) => setUsername(event.target.value)}
                      autoComplete="username"
                      placeholder="nome.cognome"
                      required
                    />
                  </div>
                  <div className="field">
                    <label className="field-label" htmlFor="password">Password</label>
                    <input
                      id="password"
                      type="password"
                      className="input"
                      value={password}
                      onChange={(event) => setPassword(event.target.value)}
                      autoComplete="current-password"
                      placeholder="••••••••"
                      required
                    />
                  </div>

                  {error ? <div className="error-text">{error}</div> : null}

                  <button type="submit" className="btn btn--block" disabled={!hydrated}>
                    Entra nel gestionale <Icon name="arrow-right" />
                  </button>

                  <p className="hint">
                    Il primo accesso con credenziali abbina automaticamente questo dispositivo al profilo. Il QR
                    funziona solo con il telefono abbinato.
                  </p>
                </form>
              ) : (
                <div className="qr-panel">
                  <div className="qr-frame">
                    {qr ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={qr} alt="Codice QR per l'accesso rapido" width={172} height={172} />
                    ) : (
                      <div style={{ width: 172, height: 172, display: "grid", placeItems: "center" }}>
                        <span className="hint">Generazione…</span>
                      </div>
                    )}
                  </div>
                  <div className="qr-timer">
                    <span className="ring" /> Codice {latest?.token ?? "—"} · si rinnova tra {remain}s
                  </div>
                  <p className="hint" style={{ textAlign: "center", maxWidth: "38ch" }}>
                    Inquadra il QR con il telefono e accedi al tuo profilo: la postazione si sbloccherà
                    automaticamente.
                  </p>
                  {qrBase ? (
                    <div className="qr-url">
                      <span className="mono">{qrBase.replace(/^https?:\/\//, "")}</span>
                      <span className="hint">
                        {network?.isLocal
                          ? "Il telefono deve essere connesso alla stessa rete Wi-Fi del computer."
                          : "Puoi scansionare da qualsiasi rete."}
                      </span>
                    </div>
                  ) : null}

                  {pairMode === "fallback" ? (
                    <div className="note" style={{ width: "100%" }}>
                      <strong>Pairing server non disponibile.</strong> In questa modalità il QR apre la pagina
                      di accesso, ma l&apos;abbinamento automatico non è attivo: usa «Simula scansione» qui sotto.
                    </div>
                  ) : null}

                  {boundStaff.length ? (
                    <div className="device-list">
                      <span className="field-label">Telefoni abbinati su questo dispositivo</span>
                      {boundStaff.map((member) => (
                        <button
                          type="button"
                          className="device-row"
                          key={member.id}
                          onClick={() => qrLogin(member.id)}
                        >
                          <span>
                            {fullName(member)} · <span className="mono">{member.role}</span>
                          </span>
                          <span className="pill pill--gold pill--plain">Simula scansione</span>
                        </button>
                      ))}
                      <span className="hint">
                        Se preferisci, puoi simulare l&apos;accesso su questa postazione senza usare il telefono.
                      </span>
                    </div>
                  ) : (
                    <div className="device-list">
                      <span className="hint">
                        Nessun telefono ancora abbinato. Scansiona il QR e accedi dal telefono: la postazione si
                        sbloccherà automaticamente. In alternativa puoi entrare con le credenziali.
                      </span>
                      <button type="button" className="btn btn--ghost btn--sm mt-8" onClick={() => setTab("credenziali")}>
                        Vai alle credenziali
                      </button>
                    </div>
                  )}

                  {error ? <div className="error-text">{error}</div> : null}
                </div>
              )}

              <details className="demo-box">
                <summary>Credenziali di prova</summary>
                <div className="demo-list">
                  <button
                    type="button"
                    className="demo-row"
                    onClick={() => quickFill("giovanni.burdi", "1254gb74H15!")}
                  >
                    <span>
                      Webmaster · Giovanni Burdi
                      <br />
                      <span className="mono">giovanni.burdi · password riservata</span>
                    </span>
                    <Icon name="user" />
                  </button>
                  <button
                    type="button"
                    className="demo-row"
                    onClick={() => quickFill("antonella.ruggiero", "csi2026")}
                  >
                    <span>
                      Operatore desk · Antonella Ruggiero
                      <br />
                      <span className="mono">antonella.ruggiero / csi2026</span>
                    </span>
                    <Icon name="user" />
                  </button>
                </div>
                <p className="hint mt-8">
                  Dati dimostrativi salvati solo su questo browser. Nessun dato reale di clienti è incluso.
                </p>
              </details>

              <div className="mt-24" style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
                <Link href="/" className="link">
                  ← Pagina di benvenuto
                </Link>
                <span className="hint" style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                  <Icon name="lock" size={12} /> Connessione riservata
                </span>
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
