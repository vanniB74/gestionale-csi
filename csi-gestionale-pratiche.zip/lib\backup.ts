import type { Database } from "./types";

export const BACKUP_FORMAT = "csi-gestionale-backup";
export const BACKUP_VERSION = 1;

export const LOCAL_LAST_KEY = "csi.backup.last.local";
export const CLOUD_LAST_KEY = "csi.backup.last.cloud";
export const CLOUD_ENDPOINT_KEY = "csi.backup.cloud.endpoint";
export const CLOUD_TOKEN_KEY = "csi.backup.cloud.token";

export interface BackupEnvelope {
  format: typeof BACKUP_FORMAT;
  version: number;
  createdAt: string;
  application: string;
  counts: {
    clients: number;
    practices: number;
    mandates: number;
    staff: number;
    services: number;
  };
  data: Database;
}

export function buildBackup(db: Database): BackupEnvelope {
  return {
    format: BACKUP_FORMAT,
    version: BACKUP_VERSION,
    createdAt: new Date().toISOString(),
    application: "C.S.I. Gestionale pratiche",
    counts: {
      clients: db.clients.length,
      practices: db.practices.length,
      mandates: db.mandates.length,
      staff: db.staff.length,
      services: db.services.length,
    },
    data: db,
  };
}

export function backupFileName(prefix = "csi-backup"): string {
  const now = new Date();
  const stamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}_${String(now.getHours()).padStart(2, "0")}${String(now.getMinutes()).padStart(2, "0")}`;
  return `${prefix}_${stamp}.json`;
}

export interface ValidationResult {
  ok: boolean;
  error?: string;
  backup?: BackupEnvelope;
}

export function validateBackup(value: unknown): ValidationResult {
  if (!value || typeof value !== "object") return { ok: false, error: "Il file non contiene un backup valido." };
  const raw = value as Partial<BackupEnvelope>;
  if (raw.format !== BACKUP_FORMAT) return { ok: false, error: "Formato del file non riconosciuto." };
  if (!raw.data || typeof raw.data !== "object") return { ok: false, error: "Il backup non contiene i dati dell'archivio." };
  const data = raw.data as Database;
  if (!Array.isArray(data.clients) || !Array.isArray(data.staff) || !Array.isArray(data.practices)) {
    return { ok: false, error: "Struttura dell'archivio incompleta (clienti, staff o pratiche mancanti)." };
  }
  if (typeof data.version !== "number") return { ok: false, error: "Versione dell'archivio non leggibile." };
  if (data.version !== 3) return { ok: false, error: "Versione dell'archivio non compatibile con questa build." };
  if (typeof data.sequence !== "number") return { ok: false, error: "Progressivo pratiche mancante." };
  if (!data.services || !data.activeServiceIds) return { ok: false, error: "Catalogo servizi mancante." };
  if (!Array.isArray(data.mandates) || !Array.isArray(data.documents) || !Array.isArray(data.appointments)) {
    return { ok: false, error: "Archivio incompleto: mandati, documenti o appuntamenti mancanti." };
  }
  return { ok: true, backup: raw as BackupEnvelope };
}

export function parseBackup(text: string): ValidationResult {
  try {
    return validateBackup(JSON.parse(text));
  } catch {
    return { ok: false, error: "Il file non è un JSON leggibile." };
  }
}

export function downloadBackupFile(content: string, fileName: string): void {
  const blob = new Blob([content], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fileName;
  anchor.rel = "noopener";
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 2000);
}

function markLast(key: string): string {
  const at = new Date().toISOString();
  window.localStorage.setItem(key, at);
  return at;
}

export type ShareOutcome = "shared" | "saved" | "downloaded" | "cancelled" | "unsupported";

export async function shareBackup(content: string, fileName: string): Promise<ShareOutcome> {
  const file = new File([content], fileName, { type: "application/json" });
  const nav = navigator as Navigator & {
    canShare?: (data?: ShareData) => boolean;
    share?: (data: ShareData) => Promise<void>;
  };
  if (nav.share && nav.canShare?.({ files: [file] })) {
    try {
      await nav.share({
        files: [file],
        title: "Backup C.S.I. — Gestionale pratiche",
        text: "Backup completo dell'archivio del gestionale.",
      });
      markLast(CLOUD_LAST_KEY);
      return "shared";
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return "cancelled";
      return "unsupported";
    }
  }
  return "unsupported";
}

interface SaveFilePickerOptions {
  suggestedName?: string;
  types?: Array<{ description?: string; accept: Record<string, string[]> }>;
}

type PickerWindow = Window & {
  showSaveFilePicker?: (options?: SaveFilePickerOptions) => Promise<{
    createWritable: () => Promise<{ write: (data: Blob) => Promise<void>; close: () => Promise<void> }>;
  }>;
};

export async function saveBackupToFolder(content: string, fileName: string): Promise<ShareOutcome> {
  const picker = (window as PickerWindow).showSaveFilePicker;
  if (!picker) return "unsupported";
  try {
    const handle = await picker({
      suggestedName: fileName,
      types: [{ description: "Backup C.S.I. (JSON)", accept: { "application/json": [".json"] } }],
    });
    const writable = await handle.createWritable();
    await writable.write(new Blob([content], { type: "application/json" }));
    await writable.close();
    markLast(CLOUD_LAST_KEY);
    return "saved";
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") return "cancelled";
    return "unsupported";
  }
}

export interface CloudResult {
  ok: boolean;
  error?: string;
}

export async function sendBackupToEndpoint(
  endpoint: string,
  token: string,
  content: string,
): Promise<CloudResult> {
  if (!endpoint) return { ok: false, error: "Configura prima un endpoint di backup cloud." };
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: content,
    });
    if (!response.ok) {
      return { ok: false, error: `Il server ha risposto ${response.status}.` };
    }
    markLast(CLOUD_LAST_KEY);
    return { ok: true };
  } catch {
    return {
      ok: false,
      error: "Endpoint non raggiungibile o CORS non consentito. Verifica URL e configurazione del server.",
    };
  }
}

export async function fetchBackupFromEndpoint(
  endpoint: string,
  token: string,
): Promise<{ ok: boolean; error?: string; text?: string }> {
  if (!endpoint) return { ok: false, error: "Configura prima un endpoint di backup cloud." };
  try {
    const response = await fetch(endpoint, {
      method: "GET",
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    if (!response.ok) return { ok: false, error: `Il server ha risposto ${response.status}.` };
    return { ok: true, text: await response.text() };
  } catch {
    return {
      ok: false,
      error: "Endpoint non raggiungibile o CORS non consentito. Verifica URL e configurazione del server.",
    };
  }
}
