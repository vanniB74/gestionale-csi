"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useData, getCoverage } from "@/lib/store";
import { formatDate, fullName, today } from "@/lib/format";
import { PageHeader, StatusPill, EmptyState, STATUS_LABEL } from "@/components/ui";
import { Icon } from "@/components/Icon";
import type { PracticeStatus } from "@/lib/types";

const STATUSES: Array<{ value: PracticeStatus | "tutte"; label: string }> = [
  { value: "tutte", label: "Tutte" },
  { value: "aperta", label: STATUS_LABEL.aperta },
  { value: "in_lavorazione", label: STATUS_LABEL.in_lavorazione },
  { value: "in_attesa", label: STATUS_LABEL.in_attesa },
  { value: "conclusa", label: STATUS_LABEL.conclusa },
];

export default function PratichePage() {
  const { db } = useData();
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<PracticeStatus | "tutte">("tutte");
  const [serviceId, setServiceId] = useState("");
  const [operatorId, setOperatorId] = useState("");

  const activeServices = db.services.filter((service) => db.activeServiceIds.includes(service.id));

  const rows = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return db.practices
      .filter((practice) => {
        const client = db.clients.find((item) => item.id === practice.clientId);
        const service = db.services.find((item) => item.id === practice.serviceId);
        const matchesQuery =
          !normalized ||
          practice.number.toLowerCase().includes(normalized) ||
          `${client?.firstName ?? ""} ${client?.lastName ?? ""}`.toLowerCase().includes(normalized) ||
          (client?.fiscalCode ?? "").toLowerCase().includes(normalized) ||
          (service?.name ?? "").toLowerCase().includes(normalized);
        const matchesStatus = status === "tutte" || practice.status === status;
        const matchesService = !serviceId || practice.serviceId === serviceId;
        const matchesOperator = !operatorId || practice.operatorId === operatorId;
        return matchesQuery && matchesStatus && matchesService && matchesOperator;
      })
      .sort((a, b) => b.openedAt.localeCompare(a.openedAt));
  }, [db, query, status, serviceId, operatorId]);

  const openCount = db.practices.filter((practice) => practice.status !== "conclusa").length;
  const overdue = db.practices.filter(
    (practice) => practice.status !== "conclusa" && practice.nextActionAt && practice.nextActionAt < today(),
  ).length;

  return (
    <div className="page page--wide">
      <PageHeader
        eyebrow={`Pratiche · ${db.practices.length} fascicoli`}
        title="Pratiche dell'ufficio"
        description="Interroga le pratiche aperte e concluse, verifica la copertura del mandato e apri il fascicolo completo."
        actions={
          <Link href="/pratiche/nuova" className="btn">
            <Icon name="plus" /> Nuova pratica
          </Link>
        }
      />

      <div className="grid-4 mb-16">
        <div className="kpi">
          <div className="kpi-label">Aperte</div>
          <div className="kpi-value">{String(openCount).padStart(2, "0")}</div>
          <div className="kpi-hint">Fascicoli attivi</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">In scadenza</div>
          <div className="kpi-value">{String(overdue).padStart(2, "0")}</div>
          <div className="kpi-hint">Prossima azione arretrata</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Concluse</div>
          <div className="kpi-value">
            {String(db.practices.filter((practice) => practice.status === "conclusa").length).padStart(2, "0")}
          </div>
          <div className="kpi-hint">Archiviate</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Risultati filtro</div>
          <div className="kpi-value">{String(rows.length).padStart(2, "0")}</div>
          <div className="kpi-hint">Su {db.practices.length} pratiche</div>
        </div>
      </div>

      <section className="card">
        <div className="filters">
          <div className="search">
            <Icon name="search" />
            <input
              className="input"
              placeholder="Cerca numero, cliente, codice fiscale o servizio…"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              aria-label="Cerca pratiche"
            />
          </div>
          <select
            className="select"
            value={serviceId}
            onChange={(event) => setServiceId(event.target.value)}
            aria-label="Filtra per servizio"
          >
            <option value="">Tutti i servizi</option>
            {activeServices.map((service) => (
              <option key={service.id} value={service.id}>
                {service.name}
              </option>
            ))}
          </select>
          <select
            className="select"
            value={operatorId}
            onChange={(event) => setOperatorId(event.target.value)}
            aria-label="Filtra per operatore"
          >
            <option value="">Tutti gli operatori</option>
            {db.staff.map((member) => (
              <option key={member.id} value={member.id}>
                {fullName(member)}
              </option>
            ))}
          </select>
          {(query || serviceId || operatorId || status !== "tutte") && (
            <button
              type="button"
              className="btn btn--ghost btn--sm"
              onClick={() => {
                setQuery("");
                setServiceId("");
                setOperatorId("");
                setStatus("tutte");
              }}
            >
              Azzera
            </button>
          )}
        </div>

        <div className="filters" style={{ borderTop: 0, background: "transparent" }}>
          <div className="chip-row">
            {STATUSES.map((item) => (
              <button
                type="button"
                key={item.value}
                className={`chip${status === item.value ? " active" : ""}`}
                onClick={() => setStatus(item.value)}
              >
                {item.label}
              </button>
            ))}
          </div>
          <span className="hint" style={{ marginLeft: "auto" }}>
            Ordinamento: apertura più recente
          </span>
        </div>

        {rows.length ? (
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th>Pratica</th>
                  <th>Cliente</th>
                  <th>Servizio</th>
                  <th>Copertura</th>
                  <th>Stato</th>
                  <th>Prossima azione</th>
                  <th>Operatore</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {rows.map((practice) => {
                  const client = db.clients.find((item) => item.id === practice.clientId);
                  const service = db.services.find((item) => item.id === practice.serviceId);
                  const coverage = getCoverage(db, practice.clientId, practice.serviceId);
                  const operator = db.staff.find((member) => member.id === practice.operatorId);
                  return (
                    <tr key={practice.id}>
                      <td>
                        <Link href={`/pratiche/${practice.id}`} className="cell-num">
                          {practice.number}
                        </Link>
                        <div className="cell-sub mono">{formatDate(practice.openedAt)}</div>
                      </td>
                      <td>
                        <div className="cell-strong">{client ? fullName(client) : "—"}</div>
                        <div className="cell-sub mono">{client?.fiscalCode}</div>
                      </td>
                      <td>
                        <div>{service?.name ?? "—"}</div>
                        <div className="cell-sub mono">{service?.code}</div>
                      </td>
                      <td>
                        <span
                          className={`pill ${
                            coverage.state === "omnibus"
                              ? "pill--gold"
                              : coverage.state === "servizio"
                                ? "pill--aperta"
                                : "pill--danger"
                          }`}
                        >
                          {coverage.state === "omnibus"
                            ? "Omnibus"
                            : coverage.state === "servizio"
                              ? "Mandato"
                              : coverage.label}
                        </span>
                      </td>
                      <td>
                        <StatusPill status={practice.status} />
                      </td>
                      <td>
                        <div>{practice.nextActionLabel || "—"}</div>
                        <div className="cell-sub mono">{formatDate(practice.nextActionAt)}</div>
                      </td>
                      <td className="muted">{operator ? fullName(operator) : "—"}</td>
                      <td className="cell-right">
                        <Link href={`/pratiche/${practice.id}`} className="icon-btn" aria-label={`Apri ${practice.number}`}>
                          <Icon name="chevron-right" />
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon="search"
            title="Nessuna pratica con questi criteri"
            text="Modifica la ricerca o azzera i filtri per vedere l'intero archivio."
            action={
              <button
                type="button"
                className="btn btn--ghost btn--sm"
                onClick={() => {
                  setQuery("");
                  setServiceId("");
                  setOperatorId("");
                  setStatus("tutte");
                }}
              >
                Azzera filtri
              </button>
            }
          />
        )}
      </section>

      <p className="hint mt-16">
        La copertura è calcolata incrociando il servizio della pratica con i mandati firmati e non revocati negli
        ultimi 12 mesi.
      </p>
    </div>
  );
}
