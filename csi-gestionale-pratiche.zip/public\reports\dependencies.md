# Report dipendenze — C.S.I. Gestionale

Generato: 24/11/2026, 17:39:53

- File analizzati: 53
- Archi di importazione: 159
- Cicli: 0
- Moduli orfani: 0
- Rotte: 16

## Pacchetti esterni

- next: 29
- react: 28
- qrcode: 1