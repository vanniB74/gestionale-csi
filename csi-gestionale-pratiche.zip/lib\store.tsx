"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type {
  Attachment,
  Client,
  Coverage,
  Database,
  IdentityDocument,
  Mandate,
  Practice,
  PracticeStatus,
  Session,
  Staff,
} from "./types";
import { seedDatabase } from "./seed";
import { addMonths, isoDay, today } from "./format";

const DB_KEY = "csi.gestionale.db.v1";
const SESSION_KEY = "csi.gestionale.session.v1";
const DEVICE_KEY = "csi.gestionale.device.v1";

export const uid = (prefix = "id") =>
  `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-4)}`;

export function getCoverage(db: Database, clientId: string, serviceId: string): Coverage {
  const now = today();
  const mandates = db.mandates.filter((m) => m.clientId === clientId && !m.revokedAt);
  const valid = mandates.filter((m) => m.expiresAt >= now);
  const omnibus = valid.find((m) => m.type === "omnibus");
  if (omnibus) {
    return {
      state: "omnibus",
      mandate: omnibus,
      expiresAt: omnibus.expiresAt,
      label: "Omnibus valido",
      detail: `Copre tutti i servizi dell'agenzia fino al ${new Date(omnibus.expiresAt + "T12:00:00").toLocaleDateString("it-IT")}.`,
    };
  }
  const single = valid.find((m) => m.type === "servizio" && m.serviceIds.includes(serviceId));
  if (single) {
    return {
      state: "servizio",
      mandate: single,
      expiresAt: single.expiresAt,
      label: "Mandato valido per il servizio",
      detail: `Firmato il ${new Date(single.signedAt + "T12:00:00").toLocaleDateString("it-IT")}, scade il ${new Date(single.expiresAt + "T12:00:00").toLocaleDateString("it-IT")}.`,
    };
  }
  const expired = mandates.find(
    (m) => m.expiresAt < now && (m.type === "omnibus" || m.serviceIds.includes(serviceId)),
  );
  if (expired) {
    return {
      state: "scaduto",
      mandate: expired,
      expiresAt: expired.expiresAt,
      label: "Mandato scaduto",
      detail: `Scaduto il ${new Date(expired.expiresAt + "T12:00:00").toLocaleDateString("it-IT")}. Serve un nuovo mandato prima di procedere.`,
    };
  }
  return {
    state: "scoperto",
    mandate: null,
    expiresAt: null,
    label: "Agenzia scoperta",
    detail: "Nessun mandato valido per questo servizio. Far firmare un nuovo mandato prima di procedere.",
  };
}

export function mandateLabel(db: Database, mandate: Mandate): string {
  if (mandate.type === "omnibus") return "Macro-gruppo Omnibus";
  const names = mandate.serviceIds
    .map((id) => db.services.find((s) => s.id === id)?.name ?? id)
    .join(", ");
  return names || "Mandato per servizio";
}

interface NewClientInput {
  firstName: string;
  lastName: string;
  sex: "M" | "F";
  birthDate: string;
  birthPlace: string;
  citizenship: string;
  fiscalCode: string;
  address: string;
  cap: string;
  city: string;
  province: string;
  phone: string;
  email: string;
  notes?: string;
}

interface NewPracticeInput {
  clientId: string;
  serviceId: string;
  description: string;
  operatorId: string;
  nextActionAt: string | null;
  nextActionLabel: string;
  nextActionKind: Practice["nextActionKind"];
  appointmentAt?: string | null;
}

interface NewMandateInput {
  clientId: string;
  type: Mandate["type"];
  areaId: string;
  serviceIds: string[];
  signedScan?: Attachment | null;
  createdBy: string;
}

interface LoginResult {
  ok: boolean;
  error?: string;
  staff?: Staff;
}

interface StoreValue {
  db: Database;
  hydrated: boolean;
  session: Session | null;
  currentUser: Staff | null;
  deviceId: string;
  storageError: boolean;
  login: (username: string, password: string) => LoginResult;
  loginWithQR: (staffId: string) => LoginResult;
  loginFromPairing: (staffId: string) => LoginResult;
  logout: () => void;
  createClient: (input: NewClientInput) => Client;
  updateClient: (id: string, patch: Partial<Client>) => void;
  saveDocument: (clientId: string, patch: Partial<IdentityDocument>) => void;
  createMandate: (input: NewMandateInput) => Mandate;
  revokeMandate: (id: string) => void;
  attachMandateScan: (id: string, attachment: Attachment) => void;
  attachPrivacyScan: (clientId: string, attachment: Attachment) => void;
  createPractice: (input: NewPracticeInput) => Practice;
  updatePractice: (id: string, patch: Partial<Practice>) => void;
  addTimeline: (practiceId: string, label: string, detail: string) => void;
  attachToPractice: (practiceId: string, attachment: Attachment) => void;
  createStaff: (input: Omit<Staff, "id" | "createdAt" | "deviceId" | "deviceLabel">) => Staff;
  updateStaff: (id: string, patch: Partial<Staff>) => void;
  unbindDevice: (id: string) => void;
  toggleService: (id: string) => void;
  updateWebmaster: (patch: Partial<Database["webmaster"]>) => void;
  importDatabase: (next: Database) => void;
  cleanupTestRecords: () => number;
  clearOperationalData: () => number;
  resetDemo: () => void;
}

const StoreContext = createContext<StoreValue | null>(null);

function readDeviceId(): string {
  if (typeof window === "undefined") return "";
  const existing = window.localStorage.getItem(DEVICE_KEY);
  if (existing) return existing;
  const created = uid("device");
  window.localStorage.setItem(DEVICE_KEY, created);
  return created;
}

export function DataProvider({ children }: { children: ReactNode }) {
  const [db, setDb] = useState<Database>(() => seedDatabase());
  const [session, setSession] = useState<Session | null>(null);
  const [hydrated, setHydrated] = useState(false);
  const [deviceId, setDeviceId] = useState("");
  const [storageError, setStorageError] = useState(false);

  useEffect(() => {
    const device = readDeviceId();
    setDeviceId(device);
    try {
      const raw = window.localStorage.getItem(DB_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Database;
        if (parsed?.version === 3 && Array.isArray(parsed.clients)) setDb(parsed);
      }
      const rawSession = window.localStorage.getItem(SESSION_KEY);
      if (rawSession) {
        const parsed = JSON.parse(rawSession) as Session;
        if (parsed?.staffId) setSession(parsed);
      }
    } catch {
      // corrupted local data: fall back to the seeded office
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(DB_KEY, JSON.stringify(db));
      setStorageError(false);
    } catch {
      setStorageError(true);
    }
  }, [db, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    if (session) window.localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    else window.localStorage.removeItem(SESSION_KEY);
  }, [session, hydrated]);

  const currentUser = useMemo(
    () => (session ? db.staff.find((s) => s.id === session.staffId) ?? null : null),
    [session, db.staff],
  );

  const login = useCallback(
    (username: string, password: string): LoginResult => {
      const staff = db.staff.find(
        (s) =>
          s.username.toLowerCase() === username.trim().toLowerCase() &&
          s.password === password &&
          s.active,
      );
      if (!staff) {
        return { ok: false, error: "Credenziali non valide o utente disattivato." };
      }
      const device = deviceId || readDeviceId();
      setDeviceId(device);
      setDb((prev) => ({
        ...prev,
        staff: prev.staff.map((s) =>
          s.id === staff.id
            ? { ...s, deviceId: s.deviceId ?? device, deviceLabel: s.deviceLabel ?? "Dispositivo ufficio" }
            : s,
        ),
      }));
      setSession({ staffId: staff.id, via: "credenziali", at: new Date().toISOString(), deviceId: device });
      return { ok: true, staff };
    },
    [db.staff, deviceId],
  );

  const loginWithQR = useCallback(
    (staffId: string): LoginResult => {
      const staff = db.staff.find((s) => s.id === staffId);
      if (!staff) return { ok: false, error: "Operatore non trovato." };
      if (!staff.deviceId) {
        return { ok: false, error: "Nessun telefono abbinato. Primo accesso con credenziali richiesto." };
      }
      if (staff.deviceId !== deviceId) {
        return { ok: false, error: "Questo dispositivo non è abbinato al profilo. Usa le credenziali." };
      }
      if (!staff.active) return { ok: false, error: "Utente disattivato dal webmaster." };
      setSession({ staffId, via: "qr", at: new Date().toISOString(), deviceId });
      return { ok: true, staff };
    },
    [db.staff, deviceId],
  );

  const loginFromPairing = useCallback(
    (staffId: string): LoginResult => {
      const staff = db.staff.find((s) => s.id === staffId);
      if (!staff) return { ok: false, error: "Operatore non riconosciuto." };
      if (!staff.active) return { ok: false, error: "Utente disattivato dal webmaster." };
      setSession({ staffId, via: "qr", at: new Date().toISOString(), deviceId });
      return { ok: true, staff };
    },
    [db.staff, deviceId],
  );

  const logout = useCallback(() => setSession(null), []);

  const createClient = useCallback((input: NewClientInput): Client => {
    const client: Client = {
      ...input,
      id: uid("cli"),
      createdAt: isoDay(new Date()),
      notes: input.notes ?? "",
    };
    setDb((prev) => ({ ...prev, clients: [client, ...prev.clients] }));
    return client;
  }, []);

  const updateClient = useCallback((id: string, patch: Partial<Client>) => {
    setDb((prev) => ({
      ...prev,
      clients: prev.clients.map((c) => (c.id === id ? { ...c, ...patch } : c)),
    }));
  }, []);

  const saveDocument = useCallback((clientId: string, patch: Partial<IdentityDocument>) => {
    setDb((prev) => {
      const existing = prev.documents.find((d) => d.clientId === clientId);
      if (existing) {
        return {
          ...prev,
          documents: prev.documents.map((d) => (d.clientId === clientId ? { ...d, ...patch } : d)),
        };
      }
      const created: IdentityDocument = {
        id: uid("doc"),
        clientId,
        number: "",
        expiry: "",
        issuer: "",
        type: "Carta d'identità elettronica",
        transcribedBy: "",
        transcribedAt: isoDay(new Date()),
        front: null,
        back: null,
        fiscalCode: null,
        ...patch,
      };
      return { ...prev, documents: [created, ...prev.documents] };
    });
  }, []);

  const createMandate = useCallback((input: NewMandateInput): Mandate => {
    const signedAt = isoDay(new Date());
    const mandate: Mandate = {
      id: uid("man"),
      clientId: input.clientId,
      type: input.type,
      areaId: input.areaId,
      serviceIds: input.type === "omnibus" ? [] : input.serviceIds,
      signedAt,
      expiresAt: addMonths(signedAt, 12),
      revokedAt: null,
      createdBy: input.createdBy,
      signedScan: input.signedScan ?? null,
    };
    setDb((prev) => ({ ...prev, mandates: [mandate, ...prev.mandates] }));
    return mandate;
  }, []);

  const revokeMandate = useCallback((id: string) => {
    setDb((prev) => ({
      ...prev,
      mandates: prev.mandates.map((m) =>
        m.id === id ? { ...m, revokedAt: new Date().toISOString() } : m,
      ),
    }));
  }, []);

  const attachMandateScan = useCallback((id: string, attachment: Attachment) => {
    setDb((prev) => ({
      ...prev,
      mandates: prev.mandates.map((m) => (m.id === id ? { ...m, signedScan: attachment } : m)),
    }));
  }, []);

  const attachPrivacyScan = useCallback((clientId: string, attachment: Attachment) => {
    setDb((prev) => ({
      ...prev,
      clients: prev.clients.map((c) => (c.id === clientId ? { ...c, privacyScan: attachment } : c)),
    }));
  }, []);

  const createPractice = useCallback((input: NewPracticeInput): Practice => {
    const number = `CSI-2026-${db.sequence}`;
    const service = db.services.find((s) => s.id === input.serviceId);
    const openedAt = isoDay(new Date());
    const practice: Practice = {
      id: uid("pr"),
      number,
      clientId: input.clientId,
      serviceId: input.serviceId,
      areaId: service?.containerId ?? "cnt-03",
      description: input.description,
      status: "aperta",
      openedAt,
      operatorId: input.operatorId,
      nextActionAt: input.nextActionAt,
      nextActionLabel: input.nextActionLabel,
      nextActionKind: input.nextActionKind,
      timeline: [
        {
          id: uid("tl"),
          at: new Date().toISOString(),
          label: "Pratica aperta",
          detail: `Servizio: ${service?.name ?? input.serviceId}.`,
          author: db.staff.find((s) => s.id === input.operatorId)?.firstName
            ? `${db.staff.find((s) => s.id === input.operatorId)?.firstName} ${db.staff.find((s) => s.id === input.operatorId)?.lastName}`
            : "Operatore",
        },
      ],
      attachments: [],
      closedAt: null,
    };
    setDb((prev) => ({
      ...prev,
      sequence: prev.sequence + 1,
      practices: [practice, ...prev.practices],
      appointments: input.appointmentAt
        ? [
            {
              id: uid("ap"),
              clientId: input.clientId,
              clientName: `${db.clients.find((c) => c.id === input.clientId)?.firstName ?? ""} ${db.clients.find((c) => c.id === input.clientId)?.lastName ?? ""}`.trim(),
              date: input.appointmentAt.slice(0, 10),
              time: input.appointmentAt.slice(11, 16) || "09:00",
              reason: service?.name ?? "Pratica",
              operatorId: input.operatorId,
              status: "programmato",
            },
            ...prev.appointments,
          ]
        : prev.appointments,
    }));
    return practice;
  }, [db.sequence, db.services, db.staff, db.clients]);

  const updatePractice = useCallback((id: string, patch: Partial<Practice>) => {
    setDb((prev) => ({
      ...prev,
      practices: prev.practices.map((p) => (p.id === id ? { ...p, ...patch } : p)),
    }));
  }, []);

  const addTimeline = useCallback((practiceId: string, label: string, detail: string) => {
    setDb((prev) => ({
      ...prev,
      practices: prev.practices.map((p) =>
        p.id === practiceId
          ? {
              ...p,
              timeline: [
                ...p.timeline,
                {
                  id: uid("tl"),
                  at: new Date().toISOString(),
                  label,
                  detail,
                  author: "Operatore",
                },
              ],
            }
          : p,
      ),
    }));
  }, []);

  const attachToPractice = useCallback((practiceId: string, attachment: Attachment) => {
    setDb((prev) => ({
      ...prev,
      practices: prev.practices.map((p) =>
        p.id === practiceId ? { ...p, attachments: [attachment, ...p.attachments] } : p,
      ),
    }));
  }, []);

  const createStaff = useCallback(
    (input: Omit<Staff, "id" | "createdAt" | "deviceId" | "deviceLabel">): Staff => {
      const staff: Staff = {
        ...input,
        id: uid("st"),
        createdAt: isoDay(new Date()),
        deviceId: null,
        deviceLabel: null,
      };
      setDb((prev) => ({ ...prev, staff: [...prev.staff, staff] }));
      return staff;
    },
    [],
  );

  const updateStaff = useCallback((id: string, patch: Partial<Staff>) => {
    setDb((prev) => ({
      ...prev,
      staff: prev.staff.map((s) => (s.id === id ? { ...s, ...patch } : s)),
    }));
  }, []);

  const unbindDevice = useCallback((id: string) => {
    setDb((prev) => ({
      ...prev,
      staff: prev.staff.map((s) => (s.id === id ? { ...s, deviceId: null, deviceLabel: null } : s)),
    }));
  }, []);

  const toggleService = useCallback((id: string) => {
    setDb((prev) => ({
      ...prev,
      activeServiceIds: prev.activeServiceIds.includes(id)
        ? prev.activeServiceIds.filter((s) => s !== id)
        : [...prev.activeServiceIds, id],
    }));
  }, []);

  const updateWebmaster = useCallback((patch: Partial<Database["webmaster"]>) => {
    setDb((prev) => ({
      ...prev,
      webmaster: { ...prev.webmaster, ...patch, configuredAt: prev.webmaster.configuredAt ?? new Date().toISOString() },
    }));
  }, []);

  const clearOperationalData = useCallback(() => {
    const removed =
      db.clients.length +
      db.documents.length +
      db.mandates.length +
      db.practices.length +
      db.appointments.length;
    setDb((prev) => ({
      ...prev,
      clients: [],
      documents: [],
      mandates: [],
      practices: [],
      appointments: [],
    }));
    return removed;
  }, [db]);

  const resetDemo = useCallback(() => {
    window.localStorage.removeItem(DB_KEY);
    window.localStorage.removeItem(SESSION_KEY);
    setDb(seedDatabase());
    setSession(null);
  }, []);

  const importDatabase = useCallback((next: Database) => {
    setDb(next);
  }, []);

  const cleanupTestRecords = useCallback(() => {
    const isTest = (id: string) => id.startsWith("test-");
    const removed =
      db.clients.filter((item) => isTest(item.id)).length +
      db.documents.filter((item) => isTest(item.id)).length +
      db.mandates.filter((item) => isTest(item.id)).length +
      db.practices.filter((item) => isTest(item.id)).length +
      db.appointments.filter((item) => isTest(item.id)).length +
      db.staff.filter((item) => isTest(item.id)).length;
    setDb((prev) => ({
      ...prev,
      clients: prev.clients.filter((item) => !isTest(item.id)),
      documents: prev.documents.filter((item) => !isTest(item.id)),
      mandates: prev.mandates.filter((item) => !isTest(item.id)),
      practices: prev.practices.filter((item) => !isTest(item.id)),
      appointments: prev.appointments.filter((item) => !isTest(item.id)),
      staff: prev.staff.filter((item) => !isTest(item.id)),
    }));
    return removed;
  }, [db]);

  const value: StoreValue = {
    db,
    hydrated,
    session,
    currentUser,
    deviceId,
    storageError,
    login,
    loginWithQR,
    loginFromPairing,
    logout,
    createClient,
    updateClient,
    saveDocument,
    createMandate,
    revokeMandate,
    attachMandateScan,
    attachPrivacyScan,
    createPractice,
    updatePractice,
    addTimeline,
    attachToPractice,
    createStaff,
    updateStaff,
    unbindDevice,
    toggleService,
    updateWebmaster,
    importDatabase,
    cleanupTestRecords,
    clearOperationalData,
    resetDemo,
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useData(): StoreValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useData must be used inside DataProvider");
  return ctx;
}

export type { NewClientInput, NewPracticeInput, NewMandateInput, PracticeStatus };
