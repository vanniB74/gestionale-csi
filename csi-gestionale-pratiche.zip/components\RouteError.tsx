"use client";

import { useEffect } from "react";
import { Icon } from "./Icon";
import { downloadTextFile, errorsToMarkdown, listGuardErrors, logGuardError } from "@/lib/guards";

export function RouteError({
  error,
  reset,
  section,
}: {
  error: Error & { digest?: string };
  reset: () => void;
  section: string;
}) {
  useEffect(() => {
    logGuardError({
      section,
      error,
      severity: "critical",
      context: { digest: error.digest, route: window.location.pathname },
    });
  }, [error, section]);

  return (
    <div className="page">
      <div className="guard-fallback">
        <span className="guard-icon">
          <Icon name="alert" size={24} />
        </span>
        <span className="eyebrow">Guardiano di rotta</span>
        <h1>La pagina si è fermata in sicurezza</h1>
        <p>
          L&apos;errore è stato registrato. Puoi riprovare la rotta oppure scaricare il report per il code agent.
        </p>
        <div className="guard-detail mono">{error.message}</div>
        <div className="row mt-16" style={{ justifyContent: "center", flexWrap: "wrap" }}>
          <button type="button" className="btn" onClick={reset}>
            Riprova
          </button>
          <button
            type="button"
            className="btn btn--ghost"
            onClick={() => downloadTextFile(errorsToMarkdown(listGuardErrors()), "csi-errori.md", "text/markdown")}
          >
            <Icon name="download" /> Scarica registro
          </button>
        </div>
      </div>
    </div>
  );
}
