"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useData } from "@/lib/store";
import { PageHeader, EmptyState } from "@/components/ui";
import { Icon } from "@/components/Icon";
import { useToast } from "@/components/Toast";
import {
  allFindings,
  analyzeWorkflow,
  findingsFromDependencies,
  findingsFromErrors,
  findingsFromTests,
  loadDependencyReport,
  type DependencyReport,
  type Finding,
  type FindingSeverity,
} from "@/lib/analysis";
import { runTestLab, type TestLabRun } from "@/lib/test-lab";
import {
  clearGuardErrors,
  downloadTextFile,
  errorsToMarkdown,
  listGuardErrors,
  logGuardError,
  type GuardError,
  type GuardSeverity,
} from "@/lib/guards";
import { buildDiagnosticsReport, buildFixPrompt } from "@/lib/fix-prompt";
import { formatDateTime } from "@/lib/format";

type Tab = "panoramica" | "dipendenze" | "test" | "workflow" | "errori" | "prompt";

const TABS: Array<{ id: Tab; label: string }> = [
  { id: "panoramica", label: "Panoramica" },
  { id: "dipendenze", label: "Dipendenze" },
  { id: "test", label: "Test" },
  { id: "workflow", label: "Workflow" },
  { id: "errori", label: "Errori" },
  { id: "prompt", label: "Fix prompt" },
];

function normalizeSeverity(value: FindingSeverity | GuardSeverity): FindingSeverity {
  if (value === "error") return "high";
  if (value === "warning") return "medium";
  return value as FindingSeverity;
}

function Severity({ value }: { value: FindingSeverity | GuardSeverity }) {
  const severity = normalizeSeverity(value);
  return <span className={`severity severity--${severity}`}>{severity}</span>;
}

function FindingCard({
  finding,
  selected,
  onToggle,
}: {
  finding: Finding;
  selected?: boolean;
  onToggle?: (id: string) => void;
}) {
  return (
    <div className={`finding finding--${finding.severity}`}>
      <div className="finding-head">
        <div style={{ minWidth: 0 }}>
          <div className="finding-id">
            {finding.id} · {finding.area}
          </div>
          <div className="finding-title">{finding.title}</div>
        </div>
        <div className="row" style={{ gap: 8, flex: "none" }}>
          <Severity value={finding.severity} />
          {onToggle ? (
            <input
              type="checkbox"
              checked={Boolean(selected)}
              onChange={() => onToggle(finding.id)}
              aria-label={`Seleziona ${finding.title}`}
              style={{ accentColor: "var(--navy)" }}
            />
          ) : null}
        </div>
      </div>
      <div className="finding-detail">{finding.detail}</div>
      {finding.evidence.length ? (
        <ul className="finding-evidence">
          {finding.evidence.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      ) : null}
      {finding.files.length ? (
        <div className="finding-files">
          {finding.files.map((file) => (
            <span key={file}>{file}</span>
          ))}
        </div>
      ) : null}
    </div>
  );
}

export default function DiagnosticaPage() {
  const { db, currentUser, cleanupTestRecords } = useData();
  const toast = useToast();

  const [tab, setTab] = useState<Tab>("panoramica");
  const [deps, setDeps] = useState<DependencyReport | null>(null);
  const [depsLoading, setDepsLoading] = useState(true);
  const [tests, setTests] = useState<TestLabRun | null>(null);
  const [running, setRunning] = useState(false);
  const [cleaned, setCleaned] = useState<number | null>(null);
  const [errors, setErrors] = useState<GuardError[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [initialized, setInitialized] = useState(false);
  const [moduleQuery, setModuleQuery] = useState("");

  useEffect(() => {
    let alive = true;
    loadDependencyReport().then((report) => {
      if (alive) {
        setDeps(report);
        setDepsLoading(false);
      }
    });
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    const update = () => setErrors(listGuardErrors());
    update();
    window.addEventListener("csi:errors-changed", update);
    return () => window.removeEventListener("csi:errors-changed", update);
  }, []);

  const workflow = useMemo(() => analyzeWorkflow(db), [db]);
  const findings = useMemo(
    () => allFindings({ workflow, dependencies: deps, tests, errors }),
    [workflow, deps, tests, errors],
  );

  useEffect(() => {
    if (initialized) return;
    if (!findings.length) return;
    setSelected(findings.filter((finding) => finding.severity === "critical" || finding.severity === "high").map((finding) => finding.id));
    setInitialized(true);
  }, [findings, initialized]);

  const selectedFindings = findings.filter((finding) => selected.includes(finding.id));
  const prompt = useMemo(
    () => buildFixPrompt({ findings: selectedFindings, workflow, dependencies: deps, tests, errors }),
    [selectedFindings, workflow, deps, tests, errors],
  );

  if (currentUser?.role !== "webmaster") {
    return (
      <div className="page">
        <PageHeader eyebrow="Area riservata" title="Diagnostica" description="Accesso riservato al webmaster." />
        <div className="card">
          <EmptyState
            icon="lock"
            title="Accesso riservato"
            text="Dipendendenze, test, workflow, registro errori e fix prompt sono strumenti di governo dell'ufficio."
            action={
              <Link href="/dashboard" className="btn btn--sm">
                Torna alla dashboard
              </Link>
            }
          />
        </div>
      </div>
    );
  }

  const runTests = async () => {
    setRunning(true);
    try {
      const result = await runTestLab(db);
      const removed = cleanupTestRecords();
      setCleaned(removed);
      setTests({ ...result, persistedTestRecords: 0 });
      toast.push(
        result.failed
          ? `Test completati: ${result.passed}/${result.results.length} pass.`
          : `Tutti i ${result.results.length} test passano. Sandbox scartata, record test rimossi: ${removed}.`,
      );
    } catch (error) {
      logGuardError({ section: "diagnostica.test", error, severity: "error" });
      toast.push(error instanceof Error ? error.message : "Test non eseguibili.");
    } finally {
      setRunning(false);
    }
  };

  const downloadReport = () => {
    const content = buildDiagnosticsReport({ workflow, dependencies: deps, tests, errors, findings });
    downloadTextFile(content, `csi-diagnostica_${new Date().toISOString().slice(0, 10)}.md`, "text/markdown");
    toast.push("Report diagnostica scaricato.");
  };

  const copyPrompt = async () => {
    try {
      await navigator.clipboard.writeText(prompt);
      toast.push("Fix prompt copiato negli appunti.");
    } catch {
      toast.push("Copia non riuscita: usa il download del prompt.");
    }
  };

  const toggle = (id: string) =>
    setSelected((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]));

  const depFindings = findingsFromDependencies(deps);
  const testFindings = findingsFromTests(tests);
  const errorFindings = findingsFromErrors(errors);
  const moduleRows = deps
    ? deps.nodes
        .filter((node) => !moduleQuery || node.id.toLowerCase().includes(moduleQuery.toLowerCase()))
        .slice(0, 60)
    : [];

  return (
    <div className="page page--wide">
      <PageHeader
        eyebrow="Area riservata · Webmaster"
        title="Diagnostica e qualità"
        description="Dipendenze statiche, test su fixture esterna, workflow dell'ufficio, registro errori e prompt pronti per il code agent."
        actions={
          <>
            <button type="button" className="btn btn--ghost" onClick={downloadReport}>
              <Icon name="download" /> Scarica report
            </button>
            <button type="button" className="btn" onClick={runTests} disabled={running}>
              <Icon name="check-circle" /> {running ? "Esecuzione…" : "Esegui test"}
            </button>
          </>
        }
      />

      <div className="grid-4 mb-16">
        <div className="kpi">
          <div className="kpi-label">Finding aperti</div>
          <div className="kpi-value">{String(findings.length).padStart(2, "0")}</div>
          <div className="kpi-hint">{findings.filter((finding) => finding.severity === "critical").length} critici</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Test esterni</div>
          <div className="kpi-value">{tests ? `${tests.passed}/${tests.results.length}` : "—"}</div>
          <div className="kpi-hint">{tests ? `${tests.failed} falliti` : "Laboratorio non eseguito"}</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Cicli dipendenze</div>
          <div className="kpi-value">{deps ? String(deps.summary.cycles).padStart(2, "0") : "—"}</div>
          <div className="kpi-hint">{deps ? `${deps.summary.files} file analizzati` : "Report da generare"}</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Errori registrati</div>
          <div className="kpi-value">{String(errors.length).padStart(2, "0")}</div>
          <div className="kpi-hint">
            {errors.filter((error) => error.severity === "critical").length} critici ·{" "}
            {errors.length ? formatDateTime(errors[0].at) : "registro pulito"}
          </div>
        </div>
      </div>

      <div className="tabs" role="tablist" aria-label="Sezioni diagnostica">
        {TABS.map((item) => (
          <button
            key={item.id}
            type="button"
            role="tab"
            aria-selected={tab === item.id}
            className={`tab${tab === item.id ? " active" : ""}`}
            onClick={() => setTab(item.id)}
          >
            {item.label}
          </button>
        ))}
      </div>

      {tab === "panoramica" ? (
        <div className="stack">
          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Workflow dell&apos;ufficio</div>
                <div className="card-sub">Dal primo appuntamento alla pratica aperta</div>
              </div>
              <span className="hint">{workflow.metrics.openPractices} pratiche aperte</span>
            </div>
            <div className="card-body">
              <div className="stage-flow">
                {workflow.stages.map((stage) => (
                  <div className="stage" key={stage.key}>
                    <div className="stage-count">{String(stage.count).padStart(2, "0")}</div>
                    <div className="stage-label">{stage.label}</div>
                    <div className="stage-detail">{stage.detail}</div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <div className="grid-2">
            <section className="card">
              <div className="card-head">
                <div>
                  <div className="card-title">Priorità</div>
                  <div className="card-sub">Finding con impatto operativo</div>
                </div>
                <Link href="#" className="link" onClick={(event) => { event.preventDefault(); setTab("prompt"); }}>
                  Fix prompt
                </Link>
              </div>
              <div className="card-body stack-sm">
                {findings.slice(0, 4).map((finding) => (
                  <FindingCard key={finding.id} finding={finding} selected={selected.includes(finding.id)} onToggle={toggle} />
                ))}
                {!findings.length ? (
                  <p className="hint">
                    Nessun finding: archivio vuoto o tutto in regola. Esegui il laboratorio test per verificare le
                    regole di dominio sul fixture esterno.
                  </p>
                ) : null}
              </div>
            </section>

            <section className="card">
              <div className="card-head">
                <div>
                  <div className="card-title">Stato laboratorio</div>
                  <div className="card-sub">Fixture esterna · sandbox in memoria</div>
                </div>
                <Icon name="check-circle" style={{ color: "var(--slate)" }} />
              </div>
              <div className="card-body stack-sm">
                <div className="stat-line">
                  <span>Fixture</span>
                  <strong className="mono">/test-data/office.json</strong>
                </div>
                <div className="stat-line">
                  <span>Casi</span>
                  <strong className="mono">/test-data/cases.json</strong>
                </div>
                <div className="stat-line">
                  <span>Record di test nell&apos;archivio</span>
                  <strong>{tests ? tests.persistedTestRecords : 0}</strong>
                </div>
                <div className="stat-line">
                  <span>Ultimo run</span>
                  <strong>{tests ? formatDateTime(tests.runAt) : "—"}</strong>
                </div>
                <div className="note mt-8">
                  <strong>Nessun seed nel codice.</strong> Il laboratorio costruisce una copia del database, applica
                  la tabella esterna e scarta la sandbox. I record `test-*` vengono rimossi anche in caso di run
                  interrotto.
                </div>
              </div>
            </section>
          </div>
        </div>
      ) : null}

      {tab === "dipendenze" ? (
        <div className="stack">
          {depsLoading ? (
            <div className="card">
              <div className="card-body">
                <p className="hint">Caricamento del report dipendenze…</p>
              </div>
            </div>
          ) : !deps ? (
            <section className="card">
              <div className="card-head">
                <div>
                  <div className="card-title">Report non trovato</div>
                  <div className="card-sub">L&apos;analisi statica non è stata ancora generata</div>
                </div>
                <Icon name="alert" style={{ color: "var(--danger)" }} />
              </div>
              <div className="card-body">
                <p className="hint">
                  Esegui <span className="mono">npm run analyze</span>: lo script analizza import, alias, rotte,
                  pacchetti e cicli e scrive <span className="mono">public/reports/dependencies.json</span>.
                </p>
              </div>
            </section>
          ) : (
            <>
              <div className="grid-4">
                <div className="kpi">
                  <div className="kpi-label">File</div>
                  <div className="kpi-value">{deps.summary.files}</div>
                  <div className="kpi-hint">Moduli TypeScript/TSX</div>
                </div>
                <div className="kpi">
                  <div className="kpi-label">Archi</div>
                  <div className="kpi-value">{deps.summary.edges}</div>
                  <div className="kpi-hint">Import risolti</div>
                </div>
                <div className="kpi">
                  <div className="kpi-label">Cicli</div>
                  <div className="kpi-value">{deps.summary.cycles}</div>
                  <div className="kpi-hint">{deps.cycles.length ? "Da interrompere" : "Nessun ciclo"}</div>
                </div>
                <div className="kpi">
                  <div className="kpi-label">Orfani</div>
                  <div className="kpi-value">{deps.summary.orphans}</div>
                  <div className="kpi-hint">Moduli non referenziati</div>
                </div>
              </div>

              {depFindings.length ? (
                <div className="stack-sm">
                  {depFindings.map((finding) => (
                    <FindingCard key={finding.id} finding={finding} selected={selected.includes(finding.id)} onToggle={toggle} />
                  ))}
                </div>
              ) : (
                <div className="note">
                  <strong>Grafo pulito.</strong> Nessun ciclo o modulo orfano rilevato nell&apos;ultima analisi.
                </div>
              )}

              <div className="grid-2" style={{ alignItems: "start" }}>
                <section className="card">
                  <div className="card-head">
                    <div className="card-title">Pacchetti esterni</div>
                    <span className="hint">{deps.summary.packages}</span>
                  </div>
                  <div className="table-wrap">
                    <table className="table table--compact">
                      <thead>
                        <tr>
                          <th>Pacchetto</th>
                          <th className="cell-right">Import</th>
                        </tr>
                      </thead>
                      <tbody>
                        {deps.packages.map((pkg) => (
                          <tr key={pkg.name}>
                            <td className="cell-num">{pkg.name}</td>
                            <td className="cell-right mono">{pkg.count}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </section>

                <section className="card">
                  <div className="card-head">
                    <div className="card-title">Rotte</div>
                    <span className="hint">{deps.summary.routes}</span>
                  </div>
                  <div className="table-wrap" style={{ maxHeight: 420, overflowY: "auto" }}>
                    <table className="table table--compact">
                      <thead>
                        <tr>
                          <th>Percorso</th>
                          <th>Tipo</th>
                        </tr>
                      </thead>
                      <tbody>
                        {deps.routes.map((route) => (
                          <tr key={`${route.type}-${route.path}`}>
                            <td className="cell-num">{route.path}</td>
                            <td className="mono">{route.type}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </section>
              </div>

              <section className="card">
                <div className="card-head">
                  <div>
                    <div className="card-title">Moduli</div>
                    <div className="card-sub">File, righe e import in uscita</div>
                  </div>
                  <div className="search" style={{ maxWidth: 300 }}>
                    <Icon name="search" />
                    <input
                      className="input"
                      value={moduleQuery}
                      onChange={(event) => setModuleQuery(event.target.value)}
                      placeholder="Filtra per percorso…"
                      aria-label="Filtra moduli"
                    />
                  </div>
                </div>
                <div className="table-wrap" style={{ maxHeight: 520, overflowY: "auto" }}>
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Modulo</th>
                        <th className="cell-right">Righe</th>
                        <th className="cell-right">Import</th>
                        <th>Esterne</th>
                      </tr>
                    </thead>
                    <tbody>
                      {moduleRows.map((node) => (
                        <tr key={node.id}>
                          <td className="cell-num">{node.id}</td>
                          <td className="cell-right mono">{node.lines}</td>
                          <td className="cell-right mono">{node.imports.length}</td>
                          <td className="muted" style={{ fontSize: 10.5 }}>
                            {node.externals.join(", ") || "—"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="card-foot">
                  <span className="hint">Generato: {formatDateTime(deps.generatedAt)}</span>
                  <span className="hint mono">npm run analyze</span>
                </div>
              </section>
            </>
          )}
        </div>
      ) : null}

      {tab === "test" ? (
        <div className="stack">
          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Laboratorio test</div>
                <div className="card-sub">Fixture e casi sono tabelle esterne, non dati nel codice</div>
              </div>
              <button type="button" className="btn btn--sm" onClick={runTests} disabled={running}>
                <Icon name="check-circle" /> {running ? "Esecuzione…" : "Esegui test"}
              </button>
            </div>
            <div className="card-body">
              <div className="grid-3">
                <div className="summary-box">
                  <div className="row-between">
                    <span>Fixture</span>
                    <a className="link" href="/test-data/office.json" target="_blank" rel="noopener noreferrer">
                      office.json
                    </a>
                  </div>
                  <div className="row-between">
                    <span>Casi</span>
                    <a className="link" href="/test-data/cases.json" target="_blank" rel="noopener noreferrer">
                      cases.json
                    </a>
                  </div>
                </div>
                <div className="summary-box">
                  <div className="row-between">
                    <span>Sandbox</span>
                    <strong className="mono">{tests ? `${tests.sandbox.clients} clienti` : "—"}</strong>
                  </div>
                  <div className="row-between">
                    <span>Record persistenti</span>
                    <strong>{tests ? tests.persistedTestRecords : 0}</strong>
                  </div>
                </div>
                <div className="summary-box">
                  <div className="row-between">
                    <span>Ultimo run</span>
                    <strong className="mono">{tests ? formatDateTime(tests.runAt) : "—"}</strong>
                  </div>
                  <div className="row-between">
                    <span>Record rimossi</span>
                    <strong>{cleaned ?? "—"}</strong>
                  </div>
                </div>
              </div>
              <div className="note mt-16">
                <strong>Come funziona.</strong> Il runner carica la fixture esterna, costruisce una copia in memoria
                del database, applica i casi e scarta la sandbox. Non scrive mai i record di test nell&apos;archivio;
                <span className="mono"> cleanupTestRecords()</span> rimuove comunque eventuali residui `test-*`.
              </div>
            </div>
          </section>

          {tests ? (
            <>
              <div className="grid-4">
                <div className="kpi">
                  <div className="kpi-label">Passati</div>
                  <div className="kpi-value">{tests.passed}</div>
                  <div className="kpi-hint">Su {tests.results.length} casi</div>
                </div>
                <div className="kpi">
                  <div className="kpi-label">Falliti</div>
                  <div className="kpi-value">{tests.failed}</div>
                  <div className="kpi-hint">Da correggere</div>
                </div>
                <div className="kpi">
                  <div className="kpi-label">Durata</div>
                  <div className="kpi-value">{tests.durationMs}</div>
                  <div className="kpi-hint">Millisecondi</div>
                </div>
                <div className="kpi">
                  <div className="kpi-label">Record residui</div>
                  <div className="kpi-value">{tests.persistedTestRecords}</div>
                  <div className="kpi-hint">Archivio operativo</div>
                </div>
              </div>

              {testFindings.length ? (
                <div className="stack-sm">
                  {testFindings.map((finding) => (
                    <FindingCard key={finding.id} finding={finding} selected={selected.includes(finding.id)} onToggle={toggle} />
                  ))}
                </div>
              ) : null}

              <section className="card">
                <div className="card-head">
                  <div className="card-title">Esiti</div>
                  <button
                    type="button"
                    className="btn btn--ghost btn--sm"
                    onClick={() => downloadTextFile(JSON.stringify(tests, null, 2), "csi-test-lab.json", "application/json")}
                  >
                    <Icon name="download" /> JSON
                  </button>
                </div>
                <div className="table-wrap">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Area</th>
                        <th>Caso</th>
                        <th>Atteso</th>
                        <th>Ottenuto</th>
                        <th className="cell-right">Esito</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tests.results.map((result) => (
                        <tr key={result.id}>
                          <td className="cell-num">{result.id}</td>
                          <td>{result.area}</td>
                          <td>
                            {result.title}
                            {result.error ? <div className="cell-sub">{result.error}</div> : null}
                          </td>
                          <td className="mono">{result.expected}</td>
                          <td className="mono">{result.actual}</td>
                          <td className="cell-right">
                            <span className={`pill ${result.pass ? "pill--conclusa" : "pill--danger"}`}>
                              {result.pass ? "pass" : "fail"}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>
            </>
          ) : (
            <EmptyState
              icon="check-circle"
              title="Laboratorio non ancora eseguito"
              text="Esegui i test per applicare la fixture esterna alla sandbox e verificare copertura mandati, workflow, scadenze e integrità."
              action={
                <button type="button" className="btn btn--sm" onClick={runTests} disabled={running}>
                  Esegui test
                </button>
              }
            />
          )}
        </div>
      ) : null}

      {tab === "workflow" ? (
        <div className="stack">
          <div className="grid-4">
            <div className="kpi">
              <div className="kpi-label">Pratiche aperte</div>
              <div className="kpi-value">{workflow.metrics.openPractices}</div>
              <div className="kpi-hint">{workflow.metrics.blockedPractices} bloccate</div>
            </div>
            <div className="kpi">
              <div className="kpi-label">Azioni arretrate</div>
              <div className="kpi-value">{workflow.metrics.overdueActions}</div>
              <div className="kpi-hint">{workflow.metrics.missingNextAction} senza prossima azione</div>
            </div>
            <div className="kpi">
              <div className="kpi-label">Mandati in scadenza</div>
              <div className="kpi-value">{workflow.metrics.expiringMandates}</div>
              <div className="kpi-hint">Entro 30 giorni</div>
            </div>
            <div className="kpi">
              <div className="kpi-label">Documenti mancanti</div>
              <div className="kpi-value">{workflow.metrics.missingDocuments}</div>
              <div className="kpi-hint">{workflow.metrics.clientsWithoutPrivacy} privacy mancanti</div>
            </div>
          </div>

          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Flusso operativo</div>
                <div className="card-sub">Conteggi sul database corrente</div>
              </div>
              <Icon name="activity" style={{ color: "var(--slate)" }} />
            </div>
            <div className="card-body">
              <div className="stage-flow">
                {workflow.stages.map((stage) => (
                  <div className="stage" key={stage.key}>
                    <div className="stage-count">{String(stage.count).padStart(2, "0")}</div>
                    <div className="stage-label">{stage.label}</div>
                    <div className="stage-detail">{stage.detail}</div>
                  </div>
                ))}
              </div>
              <div className="grid-2 mt-16">
                <div className="summary-box">
                  <div className="row-between">
                    <span>Mandati senza scansione</span>
                    <strong>{workflow.metrics.mandatesWithoutScan}</strong>
                  </div>
                  <div className="row-between">
                    <span>Pratiche ferme &gt; 30 gg</span>
                    <strong>{workflow.metrics.stalePractices}</strong>
                  </div>
                  <div className="row-between">
                    <span>Record orfani</span>
                    <strong>{workflow.metrics.orphanRecords}</strong>
                  </div>
                </div>
                <div className="summary-box">
                  <div className="row-between">
                    <span>Numeri duplicati</span>
                    <strong>{workflow.metrics.duplicateNumbers}</strong>
                  </div>
                  <div className="row-between">
                    <span>Clienti scoperti</span>
                    <strong>{workflow.metrics.uncoveredClients}</strong>
                  </div>
                  <div className="row-between">
                    <span>Prossime azioni mancanti</span>
                    <strong>{workflow.metrics.missingNextAction}</strong>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Finding di workflow</div>
                <div className="card-sub">{workflow.findings.length} regole da verificare</div>
              </div>
            </div>
            <div className="card-body stack-sm">
              {workflow.findings.length ? (
                workflow.findings.map((finding) => (
                  <FindingCard key={finding.id} finding={finding} selected={selected.includes(finding.id)} onToggle={toggle} />
                ))
              ) : (
                <p className="hint">Nessun problema rilevato sul database corrente.</p>
              )}
            </div>
          </section>
        </div>
      ) : null}

      {tab === "errori" ? (
        <div className="stack">
          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Registro errori</div>
                <div className="card-sub">Errori client, error boundary e rejection non gestite</div>
              </div>
              <div className="row">
                <button
                  type="button"
                  className="btn btn--ghost btn--sm"
                  onClick={() => downloadTextFile(errorsToMarkdown(errors), "csi-errori.md", "text/markdown")}
                >
                  <Icon name="download" /> Markdown
                </button>
                <button
                  type="button"
                  className="btn btn--danger btn--sm"
                  onClick={() => {
                    clearGuardErrors();
                    setErrors([]);
                    toast.push("Registro errori svuotato.");
                  }}
                >
                  <Icon name="trash" /> Svuota
                </button>
              </div>
            </div>
            <div className="card-body stack-sm">
              {errors.length ? (
                errors.map((error) => (
                  <details className="finding" key={error.id} style={{ borderLeftColor: error.severity === "critical" ? "var(--danger)" : "var(--gold)" }}>
                    <summary style={{ cursor: "pointer", listStyle: "none" }}>
                      <div className="finding-head">
                        <div>
                          <div className="finding-id">
                            {error.section} · {formatDateTime(error.at)}
                          </div>
                          <div className="finding-title">{error.message}</div>
                        </div>
                        <Severity value={error.severity} />
                      </div>
                    </summary>
                    {error.stack ? <pre className="guard-detail">{error.stack}</pre> : null}
                    {error.context ? (
                      <div className="hint mt-8" style={{ wordBreak: "break-word" }}>
                        {JSON.stringify(error.context)}
                      </div>
                    ) : null}
                  </details>
                ))
              ) : (
                <EmptyState
                  icon="check-circle"
                  title="Nessun errore registrato"
                  text="I guardiani non hanno rilevato errori runtime. Il registro si popola automaticamente da error boundary e rejection."
                />
              )}
            </div>
          </section>
          <div className="note">
            <strong>Errori API.</strong> Gli errori delle rotte server (`apiGuard`) vengono scritti nel log del
            server con un requestId, non nel localStorage: non contengono dati del browser.
          </div>
        </div>
      ) : null}

      {tab === "prompt" ? (
        <div className="prompt-layout">
          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Finding da correggere</div>
                <div className="card-sub">Seleziona le evidenze per il code agent</div>
              </div>
              <span className="hint">{selectedFindings.length}</span>
            </div>
            <div className="card-body">
              <div className="diag-subnav mb-16">
                <button type="button" className="chip active" onClick={() => setSelected(findings.map((finding) => finding.id))}>
                  Tutti
                </button>
                <button
                  type="button"
                  className="chip"
                  onClick={() =>
                    setSelected(
                      findings
                        .filter((finding) => finding.severity === "critical" || finding.severity === "high")
                        .map((finding) => finding.id),
                    )
                  }
                >
                  Critici
                </button>
                <button type="button" className="chip" onClick={() => setSelected([])}>
                  Nessuno
                </button>
              </div>
              <div>
                {findings.length ? (
                  findings.map((finding) => (
                    <label className="check-item" key={finding.id}>
                      <input
                        type="checkbox"
                        checked={selected.includes(finding.id)}
                        onChange={() => toggle(finding.id)}
                      />
                      <span className="check-item-body">
                        <span className="check-item-title">{finding.title}</span>
                        <span className="check-item-meta">
                          {finding.id} · {finding.area} · {finding.severity}
                        </span>
                      </span>
                    </label>
                  ))
                ) : (
                  <p className="hint">Nessun finding: il prompt genererà comunque un audit mirato.</p>
                )}
              </div>
            </div>
          </section>

          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Fix prompt</div>
                <div className="card-sub">Pronto per Cursor / Claude Code / agenti compatibili</div>
              </div>
              <div className="row">
                <button type="button" className="btn btn--ghost btn--sm" onClick={copyPrompt}>
                  <Icon name="file" /> Copia
                </button>
                <button
                  type="button"
                  className="btn btn--sm"
                  onClick={() => downloadTextFile(prompt, "csi-fix-prompt.md", "text/markdown")}
                >
                  <Icon name="download" /> Scarica
                </button>
              </div>
            </div>
            <div className="card-body">
              <pre className="prompt-preview">{prompt}</pre>
              <p className="hint mt-8">
                Generazione deterministica: nessun modello esterno viene chiamato e nessun dato lascia il browser.
                Le evidenze provengono dal database locale, dal report dipendenze e dal registro errori.
              </p>
            </div>
          </section>
        </div>
      ) : null}
    </div>
  );
}
