import { NextResponse } from "next/server";

export function apiGuard(
  route: string,
  handler: (request: Request) => Promise<Response>,
): (request: Request) => Promise<Response> {
  return async (request: Request) => {
    const requestId = crypto.randomUUID().slice(0, 8);
    try {
      return await handler(request);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Errore sconosciuto";
      const stack = error instanceof Error ? error.stack : undefined;
      console.error(
        JSON.stringify({
          level: "error",
          route,
          requestId,
          message,
          stack,
          at: new Date().toISOString(),
        }),
      );
      return NextResponse.json(
        {
          ok: false,
          error: "Errore interno del servizio.",
          requestId,
        },
        { status: 500 },
      );
    }
  };
}
