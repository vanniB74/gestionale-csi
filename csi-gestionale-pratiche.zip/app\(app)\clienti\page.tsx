"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useData } from "@/lib/store";
import { ageOf, fullName, formatDate, today } from "@/lib/format";
import { PageHeader, EmptyState } from "@/components/ui";
import { Icon } from "@/components/Icon";
import { ClientForm } from "@/components/ClientForm";
import { Modal } from "@/components/Modal";
import { useToast } from "@/components/Toast";

export default function ClientiPage() {
  const { db, createClient } = useData();
  const toast = useToast();
  const [query, setQuery] = useState("");
  const [creating, setCreating] = useState(false);

  const rows = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return db.clients
      .filter((client) =>
        !normalized
          ? true
          : `${client.firstName} ${client.lastName} ${client.fiscalCode} ${client.city} ${client.phone}`
              .toLowerCase()
              .includes(normalized),
      )
      .sort((a, b) => a.lastName.localeCompare(b.lastName));
  }, [db.clients, query]);

  return (
    <div className="page page--wide">
      <PageHeader
        eyebrow={`Anagrafiche · ${db.clients.length} clienti`}
        title="Clienti"
        description="L'anagrafica è il punto di partenza: documenti, moduli e pratiche restano raccolti nella scheda del cliente."
        actions={
          <button type="button" className="btn" onClick={() => setCreating(true)}>
            <Icon name="plus" /> Nuovo cliente
          </button>
        }
      />

      <section className="card">
        <div className="filters">
          <div className="search">
            <Icon name="search" />
            <input
              className="input"
              placeholder="Cerca per nome, codice fiscale, comune o telefono…"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              aria-label="Cerca clienti"
            />
          </div>
          <span className="hint" style={{ marginLeft: "auto" }}>
            {rows.length} risultati
          </span>
        </div>

        {rows.length ? (
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th>Cliente</th>
                  <th>Codice fiscale</th>
                  <th>Residenza</th>
                  <th>Contatti</th>
                  <th>Pratiche</th>
                  <th>Copertura</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {rows.map((client) => {
                  const practices = db.practices.filter(
                    (practice) => practice.clientId === client.id && practice.status !== "conclusa",
                  );
                  const mandates = db.mandates.filter(
                    (mandate) => mandate.clientId === client.id && !mandate.revokedAt && mandate.expiresAt >= today(),
                  );
                  const omnibus = mandates.some((mandate) => mandate.type === "omnibus");
                  return (
                    <tr key={client.id}>
                      <td>
                        <Link
                          href={`/clienti/${client.id}`}
                          className="row"
                          style={{ gap: 10, color: "var(--navy)" }}
                        >
                          <span className="avatar" style={{ width: 28, height: 28, fontSize: 9 }}>
                            {client.firstName.charAt(0)}
                            {client.lastName.charAt(0)}
                          </span>
                          <span>
                            <span className="cell-strong" style={{ display: "block" }}>
                              {fullName(client)}
                            </span>
                            <span className="cell-sub">
                              {ageOf(client.birthDate)} anni · {client.birthPlace}
                            </span>
                          </span>
                        </Link>
                      </td>
                      <td className="cell-num">{client.fiscalCode}</td>
                      <td>
                        {client.city} ({client.province})
                        <div className="cell-sub">{client.address}</div>
                      </td>
                      <td>
                        <div>{client.phone || "—"}</div>
                        <div className="cell-sub">{client.email}</div>
                      </td>
                      <td>
                        <span className="mono">{String(practices.length).padStart(2, "0")}</span>
                        <div className="cell-sub">aperte</div>
                      </td>
                      <td>
                        {omnibus ? (
                          <span className="pill pill--gold">Omnibus</span>
                        ) : mandates.length ? (
                          <span className="pill pill--aperta">Mandato</span>
                        ) : (
                          <span className="pill pill--danger">Scoperto</span>
                        )}
                      </td>
                      <td className="cell-right">
                        <Link href={`/clienti/${client.id}`} className="icon-btn" aria-label={`Apri scheda di ${fullName(client)}`}>
                          <Icon name="chevron-right" />
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <EmptyState
            icon="users"
            title="Nessun cliente trovato"
            text="Prova con un altro termine di ricerca oppure crea una nuova anagrafica."
            action={
              <button type="button" className="btn btn--sm" onClick={() => setCreating(true)}>
                <Icon name="plus" /> Nuovo cliente
              </button>
            }
          />
        )}
      </section>

      <p className="hint mt-16">
        Ultimo aggiornamento: {formatDate(today())} · archivio locale del prototipo.
      </p>

      {creating ? (
        <Modal eyebrow="Anagrafica" title="Nuovo cliente" onClose={() => setCreating(false)} width="wide">
          <ClientForm
            submitLabel="Crea cliente"
            onCancel={() => setCreating(false)}
            onSubmit={(values) => {
              const created = createClient(values);
              setCreating(false);
              toast.push(`Anagrafica creata: ${created.firstName} ${created.lastName}.`);
            }}
          />
        </Modal>
      ) : null}
    </div>
  );
}
