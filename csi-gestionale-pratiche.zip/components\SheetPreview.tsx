"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";

export function SheetPreview({ children }: { children: ReactNode }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(0.78);
  const [height, setHeight] = useState(1123);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const measure = () => {
      const width = container.clientWidth;
      const next = Math.min(1, width / 794);
      setScale(next);
      const inner = innerRef.current;
      if (inner) setHeight(inner.scrollHeight * next);
    };

    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(container);
    const timer = window.setTimeout(measure, 180);
    const onResize = () => measure();
    window.addEventListener("resize", onResize);

    return () => {
      observer.disconnect();
      window.clearTimeout(timer);
      window.removeEventListener("resize", onResize);
    };
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      const inner = innerRef.current;
      if (inner) setHeight(inner.scrollHeight * scale);
    }, 120);
    return () => window.clearTimeout(timer);
  }, [children, scale]);

  return (
    <div className="sheet-frame">
      <div className="sheet-scaler" ref={containerRef} style={{ height }}>
        <div
          ref={innerRef}
          style={{ width: 794, transform: `scale(${scale})`, transformOrigin: "top left" }}
        >
          {children}
        </div>
      </div>
    </div>
  );
}
