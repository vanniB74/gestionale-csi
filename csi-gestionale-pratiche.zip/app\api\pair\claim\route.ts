import { NextResponse } from "next/server";
import { claimPairRequest } from "@/lib/pairing";
import { apiGuard } from "@/lib/api-guard";

export const dynamic = "force-dynamic";

export const POST = apiGuard("api/pair/claim", async (request) => {
  let body: { token?: string; staffId?: string; staffName?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Richiesta non valida." }, { status: 400 });
  }
  if (!body.token || !body.staffId) {
    return NextResponse.json({ ok: false, error: "Token o operatore mancante." }, { status: 400 });
  }
  const pair = claimPairRequest(body.token, body.staffId, body.staffName ?? "Operatore");
  if (!pair) {
    return NextResponse.json(
      { ok: false, error: "Richiesta scaduta. Torna al computer e genera un nuovo QR." },
      { status: 404 },
    );
  }
  return NextResponse.json({ ok: true, expiresAt: pair.expiresAt });
});
