"use client";

import Link from "next/link";
import { useMemo } from "react";
import { useData, getCoverage } from "@/lib/store";
import { daysUntil, formatDate, formatLongDate, fullName, today } from "@/lib/format";
import { PageHeader, StatusPill, CoverageBanner, EmptyState } from "@/components/ui";
import { Icon } from "@/components/Icon";

export default function DashboardPage() {
  const { db, currentUser } = useData();

  const data = useMemo(() => {
    const now = today();
    const open = db.practices.filter((practice) => practice.status !== "conclusa");
    const due = open
      .filter((practice) => practice.nextActionAt && practice.nextActionAt <= now)
      .sort((a, b) => (a.nextActionAt ?? "").localeCompare(b.nextActionAt ?? ""));
    const uncovered = open.filter((practice) => {
      const coverage = getCoverage(db, practice.clientId, practice.serviceId);
      return coverage.state === "scoperto" || coverage.state === "scaduto";
    });
    const expiring = db.mandates
      .filter((mandate) => {
        if (mandate.revokedAt) return false;
        const days = daysUntil(mandate.expiresAt);
        return days >= 0 && days <= 45;
      })
      .sort((a, b) => a.expiresAt.localeCompare(b.expiresAt));
    const appointments = db.appointments
      .filter((appointment) => appointment.date === now && appointment.status !== "annullato")
      .sort((a, b) => a.time.localeCompare(b.time));
    const recent = [...db.practices].sort((a, b) => b.openedAt.localeCompare(a.openedAt)).slice(0, 6);
    const byStatus = {
      aperta: open.filter((p) => p.status === "aperta").length,
      in_lavorazione: open.filter((p) => p.status === "in_lavorazione").length,
      in_attesa: open.filter((p) => p.status === "in_attesa").length,
    };
    return { open, due, uncovered, expiring, appointments, recent, byStatus };
  }, [db]);

  const hour = new Date().getHours();
  const greeting = hour < 13 ? "Buongiorno" : "Buon pomeriggio";
  const clientName = (id: string) => {
    const client = db.clients.find((item) => item.id === id);
    return client ? fullName(client) : "Cliente";
  };
  const serviceName = (id: string) => db.services.find((service) => service.id === id)?.name ?? "Servizio";
  const operatorName = (id: string) => {
    const staff = db.staff.find((member) => member.id === id);
    return staff ? fullName(staff) : "—";
  };

  return (
    <div className="page page--wide">
      <PageHeader
        eyebrow={`Dashboard · ${formatLongDate(new Date())}`}
        title={`${greeting}, ${currentUser?.firstName ?? ""}.`}
        description={
          data.due.length
            ? `${data.due.length} azioni da chiudere oggi, ${data.open.length} pratiche aperte e ${data.appointments.length} appuntamenti in agenda.`
            : `Nessuna azione in scadenza: ${data.open.length} pratiche aperte e ${data.appointments.length} appuntamenti in agenda.`
        }
        actions={
          <>
            <Link href="/pratiche/nuova" className="btn">
              <Icon name="plus" /> Nuova pratica
            </Link>
            <Link href="/clienti" className="btn btn--ghost">
              <Icon name="users" /> Clienti
            </Link>
          </>
        }
      />

      <div className="grid-4">
        <div className="kpi">
          <div className="kpi-label">Pratiche aperte</div>
          <div className="kpi-value">{String(data.open.length).padStart(2, "0")}</div>
          <div className="kpi-hint">
            {data.byStatus.in_lavorazione} in lavorazione · {data.byStatus.in_attesa} in attesa
          </div>
        </div>
        <div className="kpi kpi--alert">
          <div className="kpi-label">Da fare oggi</div>
          <div className="kpi-value">{String(data.due.length).padStart(2, "0")}</div>
          <div className="kpi-hint">Appuntamenti, chiamate e adempimenti</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Copertura da regolarizzare</div>
          <div className="kpi-value">{String(data.uncovered.length).padStart(2, "0")}</div>
          <div className="kpi-hint">Pratiche senza mandato valido</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Appuntamenti oggi</div>
          <div className="kpi-value">{String(data.appointments.length).padStart(2, "0")}</div>
          <div className="kpi-hint">
            {data.appointments[0] ? `Primo alle ${data.appointments[0].time}` : "Agenda libera"}
          </div>
        </div>
      </div>

      <div className="split mt-24">
        <div className="stack">
          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Da fare oggi</div>
                <div className="card-sub">Prossime azioni con data entro oggi</div>
              </div>
              <Link href="/pratiche" className="link">Tutte le pratiche</Link>
            </div>
            {data.due.length ? (
              <div className="table-wrap">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Pratica</th>
                      <th>Cliente</th>
                      <th>Prossima azione</th>
                      <th className="cell-right">Stato</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.due.slice(0, 5).map((practice) => (
                      <tr key={practice.id}>
                        <td>
                          <Link href={`/pratiche/${practice.id}`} className="cell-num">
                            {practice.number}
                          </Link>
                          <div className="cell-sub">{serviceName(practice.serviceId)}</div>
                        </td>
                        <td className="cell-strong">{clientName(practice.clientId)}</td>
                        <td>
                          <div className="row" style={{ gap: 8 }}>
                            <Icon
                              name={
                                practice.nextActionKind === "appuntamento"
                                  ? "calendar"
                                  : practice.nextActionKind === "chiamata"
                                    ? "phone"
                                    : "check-circle"
                              }
                              size={14}
                              style={{ color: "var(--gold-deep)", flex: "none" }}
                            />
                            <span>{practice.nextActionLabel}</span>
                          </div>
                          <div className="cell-sub mono">{formatDate(practice.nextActionAt)}</div>
                        </td>
                        <td className="cell-right">
                          <StatusPill status={practice.status} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <EmptyState
                icon="check-circle"
                title="Nessuna azione in scadenza"
                text="Le prossime azioni delle pratiche aperte sono tutte programmate nei prossimi giorni."
              />
            )}
          </section>

          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Pratiche recenti</div>
                <div className="card-sub">Ultime aperture dell&apos;ufficio</div>
              </div>
              <Link href="/pratiche" className="link">Apri elenco</Link>
            </div>
            <div className="table-wrap">
              <table className="table">
                <thead>
                  <tr>
                    <th>Numero</th>
                    <th>Cliente</th>
                    <th>Servizio</th>
                    <th>Operatore</th>
                    <th className="cell-right">Aperta il</th>
                  </tr>
                </thead>
                <tbody>
                  {data.recent.map((practice) => (
                    <tr key={practice.id}>
                      <td>
                        <Link href={`/pratiche/${practice.id}`} className="cell-num">
                          {practice.number}
                        </Link>
                      </td>
                      <td className="cell-strong">{clientName(practice.clientId)}</td>
                      <td>{serviceName(practice.serviceId)}</td>
                      <td className="muted">{operatorName(practice.operatorId)}</td>
                      <td className="cell-right mono">{formatDate(practice.openedAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </div>

        <div className="stack">
          <section className="card card--accent">
            <div className="card-head">
              <div>
                <div className="card-title">Agenda di oggi</div>
                <div className="card-sub">{formatDate(today())}</div>
              </div>
              <Icon name="calendar" style={{ color: "var(--slate)" }} />
            </div>
            <div className="card-body" style={{ paddingTop: 8, paddingBottom: 8 }}>
              {data.appointments.length ? (
                <div className="schedule">
                  {data.appointments.map((appointment, index) => (
                    <div className={`schedule-item${index === 0 ? " is-now" : ""}`} key={appointment.id}>
                      <div className="schedule-time">{appointment.time}</div>
                      <div className="schedule-rule" />
                      <div>
                        <div className="schedule-reason">{appointment.reason}</div>
                        <div className="schedule-client">{appointment.clientName}</div>
                      </div>
                      <span className={`pill ${appointment.status === "confermato" ? "pill--confermato" : "pill--in_attesa"}`}>
                        {appointment.status}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState icon="calendar" title="Agenda libera" text="Nessun appuntamento registrato per oggi." />
              )}
            </div>
            <div className="card-foot">
              <span className="hint">Gli appuntamenti si registrano dalla nuova pratica.</span>
              <Link href="/pratiche/nuova" className="link">Aggiungi</Link>
            </div>
          </section>

          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Mandati in scadenza</div>
                <div className="card-sub">Entro 45 giorni</div>
              </div>
              <Icon name="clock" style={{ color: "var(--slate)" }} />
            </div>
            <div className="card-body" style={{ paddingTop: 6, paddingBottom: 6 }}>
              {data.expiring.length ? (
                <div className="mini-list">
                  {data.expiring.map((mandate) => {
                    const days = daysUntil(mandate.expiresAt);
                    const client = db.clients.find((item) => item.id === mandate.clientId);
                    return (
                      <div className="mini-item" key={mandate.id}>
                        <div>
                          <div className="cell-strong">{client ? fullName(client) : "Cliente"}</div>
                          <div className="mono" style={{ fontSize: 10 }}>
                            {mandate.type === "omnibus" ? "Omnibus" : "Servizio"} · scade {formatDate(mandate.expiresAt)}
                          </div>
                        </div>
                        <span className={`pill ${days <= 15 ? "pill--danger" : "pill--gold"}`}>
                          {days} gg
                        </span>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="hint" style={{ padding: "18px 0" }}>Nessun mandato in scadenza nel periodo.</p>
              )}
            </div>
            <div className="card-foot">
              <span className="hint">Rinnovo: 12 mesi dalla firma.</span>
              <Link href="/pratiche" className="link">Verifica</Link>
            </div>
          </section>
        </div>
      </div>

      <div className="section-head" id="avvisi">
        <h2>Avvisi operativi</h2>
        <span className="hint">Controlli automatici all&apos;apertura della pratica</span>
      </div>

      <div className="grid-2">
        <section className="card">
          <div className="card-head">
            <div>
              <div className="card-title">Pratiche senza copertura</div>
              <div className="card-sub">Serve un nuovo mandato prima di procedere</div>
            </div>
            <span className="pill pill--danger pill--plain">{data.uncovered.length}</span>
          </div>
          <div className="card-body" style={{ paddingTop: 6 }}>
            {data.uncovered.length ? (
              <div className="mini-list">
                {data.uncovered.slice(0, 5).map((practice) => {
                  const coverage = getCoverage(db, practice.clientId, practice.serviceId);
                  return (
                    <div className="mini-item" key={practice.id}>
                      <div>
                        <Link href={`/pratiche/${practice.id}`} className="cell-strong">
                          {practice.number} · {clientName(practice.clientId)}
                        </Link>
                        <div className="hint">{serviceName(practice.serviceId)}</div>
                      </div>
                      <span className={`pill ${coverage.state === "scaduto" ? "pill--danger" : "pill--danger"}`}>
                        {coverage.label}
                      </span>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="hint" style={{ padding: "14px 0" }}>
                Tutte le pratiche aperte hanno un mandato valido per il servizio richiesto.
              </p>
            )}
          </div>
        </section>

        <section className="card">
          <div className="card-head">
            <div>
              <div className="card-title">Copertura dell&apos;ufficio</div>
              <div className="card-sub">Stato dei mandati per area</div>
            </div>
            <Icon name="shield" style={{ color: "var(--slate)" }} />
          </div>
          <div className="card-body" style={{ paddingTop: 10 }}>
            {db.containers
              .filter((container) => container.id !== "cnt-06")
              .map((container, index) => {
                const total = db.mandates.filter((mandate) => !mandate.revokedAt && mandate.areaId === container.id).length;
                const max = Math.max(
                  1,
                  ...db.containers.map(
                    (item) => db.mandates.filter((m) => !m.revokedAt && m.areaId === item.id).length,
                  ),
                );
                return (
                  <div key={container.id} style={{ marginTop: index === 0 ? 0 : 12 }}>
                    <div className="stat-line" style={{ borderBottom: 0, paddingBottom: 4 }}>
                      <span>
                        {container.code} · {container.area}
                      </span>
                      <strong>{String(total).padStart(2, "0")}</strong>
                    </div>
                    <div className="bar bar--gold">
                      <span style={{ width: `${(total / max) * 100}%` }} />
                    </div>
                  </div>
                );
              })}
            <div className="note mt-16">
              <strong>Regola di controllo.</strong> Omnibus valido, mandato valido per il servizio, oppure agenzia
              scoperta: il gestionale avvisa prima di aprire la pratica.
            </div>
          </div>
        </section>
      </div>

      <div className="mt-32">
        <CoverageBanner
          coverage={{
            state: "omnibus",
            mandate: null,
            expiresAt: null,
            label: "Controllo mandato attivo su tutte le pratiche",
            detail: "All'apertura il sistema incrocia cliente e servizio con i mandati firmati negli ultimi 12 mesi.",
          }}
        />
      </div>

      <div className="mt-24" style={{ display: "flex", justifyContent: "space-between", gap: 16, flexWrap: "wrap" }}>
        <span className="hint">Ultimo aggiornamento archivio: {formatDate(today())} · {db.practices.length} pratiche totali</span>
        <span className="hint">
          Operatori attivi: {db.staff.filter((member) => member.active).length} · Clienti in anagrafica:{" "}
          {db.clients.length}
        </span>
      </div>
    </div>
  );
}
