"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { getCoverage, useData } from "@/lib/store";
import { ageOf, formatDate, formatDateTime, fullName, today } from "@/lib/format";
import { PageHeader, Definition, EmptyState, StatusPill, Crumbs, CoverageBanner } from "@/components/ui";import { Icon } from "@/components/Icon";
import { ClientForm } from "@/components/ClientForm";
import { Modal } from "@/components/Modal";
import { NewMandateModal } from "@/components/NewMandateModal";
import { useToast } from "@/components/Toast";
import { fileToAttachment, shortSize } from "@/lib/upload";
import type { Attachment } from "@/lib/types";

type Tab = "anagrafica" | "documenti" | "moduli" | "pratica";

const TABS: Array<{ id: Tab; label: string }> = [
  { id: "anagrafica", label: "Anagrafica" },
  { id: "documenti", label: "Documenti e varie" },
  { id: "moduli", label: "Moduli" },
  { id: "pratica", label: "Pratica aperta" },
];

export default function ClienteDetailPage() {
  const params = useParams<{ id: string }>();
  const { db, updateClient, saveDocument, revokeMandate, attachPrivacyScan } = useData();
  const toast = useToast();

  const client = db.clients.find((item) => item.id === params?.id);
  const identityDoc = client ? db.documents.find((item) => item.clientId === client.id) : null;
  const mandates = client ? db.mandates.filter((item) => item.clientId === client.id) : [];
  const practices = client
    ? db.practices
        .filter((item) => item.clientId === client.id)
        .sort((a, b) => (a.status === "conclusa" ? 1 : 0) - (b.status === "conclusa" ? 1 : 0) || b.openedAt.localeCompare(a.openedAt))
    : [];

  const [tab, setTab] = useState<Tab>("anagrafica");
  const [editing, setEditing] = useState(false);
  const [mandateOpen, setMandateOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [docType, setDocType] = useState(identityDoc?.type ?? "Carta d'identità elettronica");
  const [docNumber, setDocNumber] = useState(identityDoc?.number ?? "");
  const [docExpiry, setDocExpiry] = useState(identityDoc?.expiry ?? "");
  const [docIssuer, setDocIssuer] = useState(identityDoc?.issuer ?? "");

  useEffect(() => {
    const query = new URLSearchParams(window.location.search).get("tab");
    if (query && TABS.some((item) => item.id === query)) setTab(query as Tab);
  }, []);

  if (!client) {
    return (
      <div className="page">
        <EmptyState
          icon="users"
          title="Cliente non trovato"
          text="L'anagrafica richiesta non è presente nell'archivio locale."
          action={
            <Link href="/clienti" className="btn btn--sm">
              Torna ai clienti
            </Link>
          }
        />
      </div>
    );
  }

  const validMandates = mandates.filter(
    (mandate) => !mandate.revokedAt && mandate.expiresAt >= today(),
  );
  const openPractices = practices.filter((practice) => practice.status !== "conclusa");
  const allAttachments = practices.flatMap((practice) =>
    practice.attachments.map((attachment) => ({ attachment, practice })),
  );

  const uploadDoc = async (category: Attachment["category"], key: "front" | "back" | "fiscalCode", file: File | undefined) => {
    if (!file) return;
    try {
      const attachment = await fileToAttachment(file, category);
      saveDocument(client.id, {
        [key]: attachment,
        transcribedBy: "Operatore desk",
        transcribedAt: today(),
      } as never);
      toast.push("Documento caricato.");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Caricamento non riuscito.";
      setError(message);
      toast.push(message);
    }
  };

  const saveTranscription = () => {
    saveDocument(client.id, {
      type: docType,
      number: docNumber.toUpperCase(),
      expiry: docExpiry,
      issuer: docIssuer,
      transcribedBy: "Operatore desk",
      transcribedAt: today(),
    });
    toast.push("Trascrizione documento salvata.");
  };

  return (
    <div className="page">
      <PageHeader
        eyebrow="Scheda cliente"
        crumbs={<Crumbs items={[{ label: "Clienti", href: "/clienti" }, { label: fullName(client) }]} />}
        title={fullName(client)}
        description={
          <>
            <span className="mono">{client.fiscalCode}</span> · {ageOf(client.birthDate)} anni · {client.birthPlace}
          </>
        }
        actions={
          <>
            <Link href={`/pratiche/nuova?cliente=${client.id}`} className="btn">
              <Icon name="plus" /> Nuova pratica
            </Link>
            <button type="button" className="btn btn--ghost" onClick={() => setEditing(true)}>
              <Icon name="edit" /> Modifica
            </button>
          </>
        }
      />

      <section className="card mb-16">
        <div className="card-body" style={{ display: "flex", gap: 20, flexWrap: "wrap", alignItems: "center" }}>
          <span className="avatar avatar--lg">
            {client.firstName.charAt(0)}
            {client.lastName.charAt(0)}
          </span>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
              <span className="mono" style={{ fontSize: 11, color: "var(--slate)" }}>
                {client.fiscalCode}
              </span>
              {validMandates.some((mandate) => mandate.type === "omnibus") ? (
                <span className="pill pill--gold">Omnibus valido</span>
              ) : validMandates.length ? (
                <span className="pill pill--aperta">{validMandates.length} mandati validi</span>
              ) : (
                <span className="pill pill--danger">Agenzia scoperta</span>
              )}
            </div>
            <div className="row mt-8" style={{ gap: 16, flexWrap: "wrap", fontSize: 12 }}>
              <span className="row" style={{ gap: 6 }}>
                <Icon name="phone" size={13} /> {client.phone || "—"}
              </span>
              <span className="row" style={{ gap: 6 }}>
                <Icon name="mail" size={13} /> {client.email || "—"}
              </span>
              <span className="row" style={{ gap: 6 }}>
                <Icon name="building" size={13} /> {client.city} ({client.province})
              </span>
            </div>
          </div>
          <div style={{ display: "flex", gap: 26, flexWrap: "wrap" }}>
            <div>
              <div className="kpi-label">Pratiche aperte</div>
              <div className="kpi-value" style={{ fontSize: 22 }}>{String(openPractices.length).padStart(2, "0")}</div>
            </div>
            <div>
              <div className="kpi-label">Mandati</div>
              <div className="kpi-value" style={{ fontSize: 22 }}>{String(mandates.length).padStart(2, "0")}</div>
            </div>
            <div>
              <div className="kpi-label">In archivio dal</div>
              <div className="mono" style={{ fontSize: 12, marginTop: 12 }}>{formatDate(client.createdAt)}</div>
            </div>
          </div>
        </div>
      </section>

      <div className="tabs" role="tablist" aria-label="Sezioni della scheda cliente">
        {TABS.map((item) => (
          <button
            key={item.id}
            type="button"
            role="tab"
            aria-selected={tab === item.id}
            className={`tab${tab === item.id ? " active" : ""}`}
            onClick={() => setTab(item.id)}
          >
            {item.label}
          </button>
        ))}
      </div>

      {tab === "anagrafica" ? (
        <div className="grid-2">
          <section className="card">
            <div className="card-head">
              <div className="card-title">Dati personali</div>
              <Icon name="user" style={{ color: "var(--slate)" }} />
            </div>
            <div className="card-body" style={{ paddingTop: 4 }}>
              <Definition
                items={[
                  { label: "Cognome", value: client.lastName },
                  { label: "Nome", value: client.firstName },
                  { label: "Sesso", value: client.sex },
                  { label: "Data di nascita", value: formatDate(client.birthDate) },
                  { label: "Luogo di nascita", value: client.birthPlace },
                  { label: "Cittadinanza", value: client.citizenship },
                  { label: "Codice fiscale", value: client.fiscalCode, mono: true },
                ]}
              />
            </div>
          </section>

          <section className="card">
            <div className="card-head">
              <div className="card-title">Residenza e recapiti</div>
              <Icon name="mail" style={{ color: "var(--slate)" }} />
            </div>
            <div className="card-body" style={{ paddingTop: 4 }}>
              <Definition
                items={[
                  { label: "Indirizzo", value: client.address },
                  { label: "CAP / Comune", value: `${client.cap} ${client.city}` },
                  { label: "Provincia", value: client.province },
                  { label: "Telefono", value: client.phone },
                  { label: "E-mail / PEC", value: client.email },
                ]}
              />
              {client.notes ? (
                <div className="note mt-16">
                  <strong>Note operative.</strong> {client.notes}
                </div>
              ) : null}
            </div>
          </section>
        </div>
      ) : null}

      {tab === "documenti" ? (
        <div className="stack">
          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Documento d&apos;identità</div>
                <div className="card-sub">Fronte, retro e codice fiscale in contenitori separati</div>
              </div>
              <span className={`pill ${identityDoc ? "pill--aperta" : "pill--danger"}`}>
                {identityDoc ? "Trascritto" : "Da acquisire"}
              </span>
            </div>
            <div className="card-body">
              <div className="doc-grid">
                <DocSlot
                  label="Carta d'identità · fronte"
                  attachment={identityDoc?.front ?? null}
                  onFile={(file) => uploadDoc("ci_fronte", "front", file)}
                />
                <DocSlot
                  label="Carta d'identità · retro"
                  attachment={identityDoc?.back ?? null}
                  onFile={(file) => uploadDoc("ci_retro", "back", file)}
                />
                <DocSlot
                  label="Codice fiscale"
                  attachment={identityDoc?.fiscalCode ?? null}
                  onFile={(file) => uploadDoc("codice_fiscale", "fiscalCode", file)}
                />
              </div>

              <div className="hr" />

              <div className="form-grid form-grid--3">
                <div className="field">
                  <label className="field-label" htmlFor="type">Tipo documento</label>
                  <select id="type" className="select" value={docType} onChange={(event) => setDocType(event.target.value)}>
                    <option>Carta d&apos;identità elettronica</option>
                    <option>Passaporto</option>
                    <option>Patente di guida</option>
                    <option>Permesso di soggiorno</option>
                  </select>
                </div>
                <div className="field">
                  <label className="field-label" htmlFor="number">Numero</label>
                  <input
                    id="number"
                    className="input input--mono"
                    value={docNumber}
                    onChange={(event) => setDocNumber(event.target.value.toUpperCase())}
                  />
                </div>
                <div className="field">
                  <label className="field-label" htmlFor="expiry">Scadenza</label>
                  <input
                    id="expiry"
                    type="date"
                    className="input"
                    value={docExpiry}
                    onChange={(event) => setDocExpiry(event.target.value)}
                  />
                </div>
                <div className="field span-2">
                  <label className="field-label" htmlFor="issuer">Ente di rilascio</label>
                  <input id="issuer" className="input" value={docIssuer} onChange={(event) => setDocIssuer(event.target.value)} />
                </div>
                <div className="field">
                  <span className="field-label">Ultima trascrizione</span>
                  <div className="mono" style={{ fontSize: 11, paddingTop: 10 }}>
                    {identityDoc ? formatDate(identityDoc.transcribedAt) : "—"}
                  </div>
                </div>
              </div>

              <div className="form-actions">
                <button type="button" className="btn btn--sm" onClick={saveTranscription}>
                  Salva trascrizione
                </button>
                <span className="hint" style={{ marginLeft: "auto" }}>
                  I file restano allegati all&apos;anagrafica.
                </span>
              </div>
            </div>
          </section>

          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Documenti e varie</div>
                <div className="card-sub">Allegati dei fascicoli del cliente</div>
              </div>
              <span className="hint">{allAttachments.length}</span>
            </div>
            <div className="card-body" style={{ paddingTop: 6 }}>
              {allAttachments.length ? (
                <div className="mini-list">
                  {allAttachments.map(({ attachment, practice }) => (
                    <div className="mini-item" key={attachment.id}>
                      <div>
                        <div className="cell-strong">{attachment.name}</div>
                        <div className="mono" style={{ fontSize: 10 }}>
                          {practice.number} · {shortSize(attachment.size)} · {formatDateTime(attachment.uploadedAt)}
                        </div>
                      </div>
                      <div className="row" style={{ gap: 4 }}>
                        <a className="icon-btn" href={attachment.dataUrl} target="_blank" rel="noopener noreferrer" aria-label="Apri allegato">
                          <Icon name="eye" />
                        </a>
                        <a className="icon-btn" href={attachment.dataUrl} download={attachment.name} aria-label="Scarica allegato">
                          <Icon name="download" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="hint" style={{ padding: "10px 0" }}>
                  Nessun allegato nei fascicoli. I documenti caricati nelle pratiche compaiono qui.
                </p>
              )}
            </div>
          </section>
        </div>
      ) : null}

      {tab === "moduli" ? (
        <div className="stack">
          <div className="grid-2">
            <section className="card card--accent">
              <div className="card-head">
                <div>
                  <div className="card-title">Mandato di assistenza</div>
                  <div className="card-sub">Area di interesse · validità 12 mesi</div>
                </div>
                <span className="pill pill--gold pill--plain">{mandates.length}</span>
              </div>
              <div className="card-body stack-sm">
                {mandates.length ? (
                  <div className="mini-list">
                    {mandates.slice(0, 3).map((mandate) => (
                      <div className="mini-item" key={mandate.id}>
                        <div>
                          <div className="cell-strong">
                            {mandate.type === "omnibus" ? "Macro-gruppo Omnibus" : "Mandato per servizio"}
                          </div>
                          <div className="mono" style={{ fontSize: 10 }}>
                            {formatDate(mandate.signedAt)} → {formatDate(mandate.expiresAt)}
                          </div>
                        </div>
                        <span className={`pill ${mandate.expiresAt >= today() && !mandate.revokedAt ? "pill--gold" : "pill--danger"}`}>
                          {mandate.revokedAt ? "Revocato" : mandate.expiresAt >= today() ? "Valido" : "Scaduto"}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="hint">Nessun mandato firmato per questo cliente.</p>
                )}
                <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
                  <Link href={`/moduli/${client.id}/mandato`} className="btn btn--sm">
                    <Icon name="printer" /> Apri e stampa
                  </Link>
                  <button type="button" className="btn btn--ghost btn--sm" onClick={() => setMandateOpen(true)}>
                    <Icon name="plus" /> Nuovo mandato
                  </button>
                </div>
              </div>
            </section>

            <section className="card">
              <div className="card-head">
                <div>
                  <div className="card-title">Consenso privacy</div>
                  <div className="card-sub">Identico per tutti, senza numero pratica</div>
                </div>
                {client.privacyScan ? (
                  <span className="pill pill--conclusa">Firmato</span>
                ) : (
                  <span className="pill pill--in_attesa">Da acquisire</span>
                )}
              </div>
              <div className="card-body stack-sm">
                {client.privacyScan ? (
                  <a href={client.privacyScan.dataUrl} target="_blank" rel="noopener noreferrer">
                    <img src={client.privacyScan.dataUrl} alt="Privacy firmata" className="scan-thumb" style={{ maxHeight: 170, objectFit: "cover" }} />
                  </a>
                ) : (
                  <p className="hint">
                    Stampa il modulo, fai firmare e carica la scansione. Il consenso non è legato a una singola
                    pratica.
                  </p>
                )}
                <Link href={`/moduli/${client.id}/privacy`} className="btn btn--sm btn--ghost">
                  <Icon name="printer" /> Apri e stampa privacy
                </Link>
              </div>
            </section>
          </div>

          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Storico mandati</div>
                <div className="card-sub">Copertura per area e servizi</div>
              </div>
              <Icon name="shield" style={{ color: "var(--slate)" }} />
            </div>
            {mandates.length ? (
              <div className="table-wrap">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Tipo</th>
                      <th>Area</th>
                      <th>Firma</th>
                      <th>Scadenza</th>
                      <th>Scansione</th>
                      <th className="cell-right">Azioni</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mandates.map((mandate) => {
                      const area = db.containers.find((item) => item.id === mandate.areaId);
                      return (
                        <tr key={mandate.id}>
                          <td className="cell-strong">
                            {mandate.type === "omnibus" ? "Omnibus" : "Per servizio"}
                            {mandate.type === "servizio" ? (
                              <div className="cell-sub">
                                {mandate.serviceIds
                                  .map((id) => db.services.find((service) => service.id === id)?.name)
                                  .filter(Boolean)
                                  .join(", ")}
                              </div>
                            ) : null}
                          </td>
                          <td>{area?.code ?? "—"}</td>
                          <td className="mono">{formatDate(mandate.signedAt)}</td>
                          <td>
                            <span className={`pill ${mandate.expiresAt >= today() && !mandate.revokedAt ? "pill--gold" : "pill--danger"}`}>
                              {formatDate(mandate.expiresAt)}
                            </span>
                          </td>
                          <td>
                            {mandate.signedScan ? (
                              <a className="link" href={mandate.signedScan.dataUrl} target="_blank" rel="noopener noreferrer">
                                Apri
                              </a>
                            ) : (
                              <span className="hint">Mancante</span>
                            )}
                          </td>
                          <td className="cell-right">
                            {!mandate.revokedAt ? (
                              <button
                                type="button"
                                className="btn btn--danger btn--sm"
                                onClick={() => {
                                  revokeMandate(mandate.id);
                                  toast.push("Mandato revocato.");
                                }}
                              >
                                Revoca
                              </button>
                            ) : (
                              <span className="hint">Revocato</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <EmptyState icon="shield" title="Nessun mandato" text="Il cliente risulta scoperto: apri un nuovo mandato prima della prossima pratica." />
            )}
          </section>

          <div className="note">
            <strong>Controllo all&apos;apertura.</strong> Un cliente può avere più mandati per servizi diversi. Ogni
            mandato scade dopo 12 mesi e copre solo i servizi per cui è stato firmato; l&apos;omnibus copre tutto.
          </div>
        </div>
      ) : null}

      {tab === "pratica" ? (
        <div className="stack">
          {practices.length ? (
            practices.map((practice) => {
              const service = db.services.find((item) => item.id === practice.serviceId);
              const coverage = getCoverage(db, client.id, practice.serviceId);
              return (
                <section className="card" key={practice.id}>
                  <div className="card-head">
                    <div>
                      <div className="row" style={{ gap: 10 }}>
                        <Link href={`/pratiche/${practice.id}`} className="mono" style={{ fontSize: 12 }}>
                          {practice.number}
                        </Link>
                        <StatusPill status={practice.status} />
                      </div>
                      <div className="card-sub">
                        {service?.name} · aperta il {formatDate(practice.openedAt)}
                      </div>
                    </div>
                    <Link href={`/pratiche/${practice.id}`} className="btn btn--ghost btn--sm">
                      Apri fascicolo
                    </Link>
                  </div>
                  <div className="card-body">
                    <p style={{ fontSize: 12.5 }}>{practice.description}</p>
                    <div className="grid-2 mt-16">
                      <CoverageBanner coverage={coverage} compact />
                      <div className="summary-box">
                        <div className="row-between">
                          <span>Prossima azione</span>
                          <strong>{practice.nextActionLabel || "—"}</strong>
                        </div>
                        <div className="row-between">
                          <span>Data</span>
                          <span className="mono">{formatDate(practice.nextActionAt)}</span>
                        </div>
                        <div className="row-between">
                          <span>Allegati</span>
                          <span>{practice.attachments.length}</span>
                        </div>
                      </div>
                    </div>
                    {practice.attachments.length ? (
                      <div className="mini-list mt-8">
                        {practice.attachments.map((attachment) => (
                          <div className="mini-item" key={attachment.id}>
                            <div>
                              <div className="cell-strong">{attachment.name}</div>
                              <div className="mono" style={{ fontSize: 10 }}>
                                {shortSize(attachment.size)} · {formatDateTime(attachment.uploadedAt)}
                              </div>
                            </div>
                            <div className="row" style={{ gap: 4 }}>
                              <a
                                className="icon-btn"
                                href={attachment.dataUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                aria-label={`Apri ${attachment.name}`}
                              >
                                <Icon name="eye" />
                              </a>
                              <a
                                className="icon-btn"
                                href={attachment.dataUrl}
                                download={attachment.name}
                                aria-label={`Scarica ${attachment.name}`}
                              >
                                <Icon name="download" />
                              </a>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : null}
                  </div>
                </section>
              );
            })
          ) : (
            <EmptyState
              icon="folder"
              title="Nessuna pratica"
              text="Questo cliente non ha ancora fascicoli aperti."
              action={
                <Link href={`/pratiche/nuova?cliente=${client.id}`} className="btn btn--sm">
                  Apri una pratica
                </Link>
              }
            />
          )}
        </div>
      ) : null}

      {error ? <div className="error-text mt-16">{error}</div> : null}

      {editing ? (
        <Modal eyebrow="Anagrafica" title="Modifica cliente" onClose={() => setEditing(false)} width="wide">
          <ClientForm
            initial={client}
            submitLabel="Salva modifiche"
            onCancel={() => setEditing(false)}
            onSubmit={(values) => {
              updateClient(client.id, values);
              setEditing(false);
              toast.push("Anagrafica aggiornata.");
            }}
          />
        </Modal>
      ) : null}

      {mandateOpen ? (
        <NewMandateModal clientId={client.id} onClose={() => setMandateOpen(false)} />
      ) : null}
    </div>
  );
}

function DocSlot({
  label,
  attachment,
  onFile,
}: {
  label: string;
  attachment: Attachment | null;
  onFile: (file: File | undefined) => void;
}) {
  return (
    <div className="doc-tile">
      <div className={`doc-frame doc-frame--action${attachment ? " doc-frame--filled" : ""}`}>
        <input
          type="file"
          accept="image/*,application/pdf"
          onChange={(event) => {
            onFile(event.target.files?.[0]);
            event.target.value = "";
          }}
          aria-label={`Carica ${label}`}
        />
        {attachment ? (
          attachment.mime.startsWith("image/") ? (
            <img src={attachment.dataUrl} alt={`Anteprima ${label}`} />
          ) : (
            <div className="doc-placeholder" style={{ color: "var(--ivory)" }}>
              <Icon name="file" />
              PDF
            </div>
          )
        ) : (
          <div className="doc-placeholder">
            <Icon name="upload" />
            Carica
          </div>
        )}
      </div>
      <div className="doc-label">
        <strong>{label}</strong>
        <span>{attachment ? "Caricato" : "Mancante"}</span>
      </div>
    </div>
  );
}
