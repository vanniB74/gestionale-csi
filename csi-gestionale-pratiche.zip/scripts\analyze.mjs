import fs from "node:fs";
import path from "node:path";
import ts from "typescript";

const root = process.cwd();
const sourceRoots = ["app", "components", "lib"];
const skipDirs = new Set(["node_modules", ".next", ".git", "public", "scripts", "data", "_shots", "_assets_tmp", "_research"]);
const extensions = [".ts", ".tsx", ".js", ".jsx"];

function walk(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    if (entry.name.startsWith(".")) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (skipDirs.has(entry.name)) continue;
      files.push(...walk(full));
    } else if (extensions.includes(path.extname(entry.name))) {
      files.push(full);
    }
  }
  return files;
}

const files = sourceRoots.flatMap((dir) => {
  const full = path.join(root, dir);
  return fs.existsSync(full) ? walk(full) : [];
});

const relative = (file) => path.relative(root, file).split(path.sep).join("/");
const nodes = new Map();
const unresolved = [];

function resolveSpecifier(fromFile, specifier) {
  let base = null;
  if (specifier.startsWith("@/")) base = path.join(root, specifier.slice(2));
  else if (specifier.startsWith(".")) base = path.resolve(path.dirname(fromFile), specifier);
  if (!base) return null;
  const candidates = [
    base,
    ...extensions.map((ext) => `${base}${ext}`),
    ...extensions.map((ext) => path.join(base, `index${ext}`)),
  ];
  for (const candidate of candidates) {
    if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return relative(candidate);
  }
  unresolved.push({ from: relative(fromFile), specifier });
  return null;
}

for (const file of files) {
  const text = fs.readFileSync(file, "utf8");
  const source = ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  const imports = [];
  const externals = [];

  const addSpecifier = (specifier) => {
    if (!specifier) return;
    if (specifier.startsWith(".") || specifier.startsWith("@/")) {
      const resolved = resolveSpecifier(file, specifier);
      if (resolved) imports.push(resolved);
    } else {
      externals.push(specifier);
    }
  };

  const visit = (node) => {
    if (ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) {
      if (node.moduleSpecifier && ts.isStringLiteral(node.moduleSpecifier)) addSpecifier(node.moduleSpecifier.text);
    }
    if (ts.isCallExpression(node) && node.expression.kind === ts.SyntaxKind.ImportKeyword) {
      const argument = node.arguments[0];
      if (argument && ts.isStringLiteral(argument)) addSpecifier(argument.text);
    }
    ts.forEachChild(node, visit);
  };
  visit(source);

  const id = relative(file);
  nodes.set(id, {
    id,
    label: path.basename(file),
    lines: text.split(/\r?\n/).length,
    imports: [...new Set(imports)],
    externals: [...new Set(externals)],
  });
}

const edges = [];
for (const node of nodes.values()) {
  for (const target of node.imports) edges.push({ from: node.id, to: target });
}

const adjacency = new Map();
for (const node of nodes.keys()) adjacency.set(node, []);
for (const edge of edges) {
  if (!adjacency.has(edge.from)) adjacency.set(edge.from, []);
  adjacency.get(edge.from).push(edge.to);
}

const visiting = new Set();
const visited = new Set();
const stack = [];
const cycles = [];
const seenCycles = new Set();

function recordCycle(from) {
  const index = stack.indexOf(from);
  if (index === -1) return;
  const cycle = [...stack.slice(index), from];
  const key = [...new Set(cycle)].sort().join("|");
  if (seenCycles.has(key)) return;
  seenCycles.add(key);
  cycles.push(cycle);
}

function dfs(node) {
  visiting.add(node);
  stack.push(node);
  for (const next of adjacency.get(node) ?? []) {
    if (!nodes.has(next)) continue;
    if (visiting.has(next)) recordCycle(next);
    else if (!visited.has(next)) dfs(next);
  }
  stack.pop();
  visiting.delete(node);
  visited.add(node);
}

for (const node of nodes.keys()) if (!visited.has(node)) dfs(node);

const inbound = new Map([...nodes.keys()].map((id) => [id, 0]));
for (const edge of edges) if (inbound.has(edge.to)) inbound.set(edge.to, inbound.get(edge.to) + 1);
const orphans = [...nodes.keys()].filter(
  (id) => inbound.get(id) === 0 && !id.startsWith("app/") && !id.endsWith("next-env.d.ts"),
);

const isRoute = (file) => /\/(page|route)\.(ts|tsx)$/.test(file);
const routes = [];
for (const id of nodes.keys()) {
  if (!id.startsWith("app/") || !isRoute(id)) continue;
  const segments = id
    .replace(/^app\//, "")
    .replace(/\/?(page|route)\.(ts|tsx)$/, "")
    .split("/")
    .filter((segment) => segment && !segment.startsWith("(") && !segment.startsWith("@"));
  const routePath = `/${segments.join("/")}`.replace(/\/$/, "") || "/";
  routes.push({
    path: routePath || "/",
    file: id,
    type: id.endsWith("route.ts") || id.endsWith("route.tsx") ? "api" : "page",
  });
}
routes.sort((a, b) => a.path.localeCompare(b.path));

const packageCounts = new Map();
for (const node of nodes.values()) {
  for (const external of node.externals) {
    if (external.startsWith("node:")) continue;
    const name = external.startsWith("@") ? external.split("/").slice(0, 2).join("/") : external.split("/")[0];
    packageCounts.set(name, (packageCounts.get(name) ?? 0) + 1);
  }
}
const packages = [...packageCounts.entries()]
  .map(([name, count]) => ({ name, count }))
  .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));

const report = {
  generatedAt: new Date().toISOString(),
  summary: {
    files: nodes.size,
    edges: edges.length,
    cycles: cycles.length,
    orphans: orphans.length,
    packages: packages.length,
    routes: routes.length,
  },
  nodes: [...nodes.values()].sort((a, b) => a.id.localeCompare(b.id)),
  edges,
  cycles,
  orphans,
  packages,
  routes,
  unresolved,
};

const outDir = path.join(root, "public", "reports");
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, "dependencies.json"), JSON.stringify(report, null, 2));

const md = [];
md.push("# Report dipendenze — C.S.I. Gestionale");
md.push("");
md.push(`Generato: ${new Date().toLocaleString("it-IT")}`);
md.push("");
md.push(`- File analizzati: ${report.summary.files}`);
md.push(`- Archi di importazione: ${report.summary.edges}`);
md.push(`- Cicli: ${report.summary.cycles}`);
md.push(`- Moduli orfani: ${report.summary.orphans}`);
md.push(`- Rotte: ${report.summary.routes}`);
md.push("");
md.push("## Pacchetti esterni");
md.push("");
packages.forEach((pkg) => md.push(`- ${pkg.name}: ${pkg.count}`));
if (cycles.length) {
  md.push("");
  md.push("## Cicli");
  cycles.forEach((cycle) => md.push(`- ${cycle.join(" → ")}`));
}
if (orphans.length) {
  md.push("");
  md.push("## Moduli non referenziati");
  orphans.forEach((id) => md.push(`- ${id}`));
}
fs.writeFileSync(path.join(outDir, "dependencies.md"), md.join("\n"));

console.log(
  `[analyze] files=${report.summary.files} edges=${report.summary.edges} cycles=${report.summary.cycles} orphans=${report.summary.orphans} routes=${report.summary.routes}`,
);
