"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { getCoverage, useData } from "@/lib/store";
import { PageHeader, Stepper, CoverageBanner, Crumbs } from "@/components/ui";
import { Icon } from "@/components/Icon";
import { ClientForm, type ClientFormValues } from "@/components/ClientForm";
import { ContainerPicker } from "@/components/ContainerPicker";
import { NewMandateModal } from "@/components/NewMandateModal";
import { useToast } from "@/components/Toast";
import { fileToAttachment } from "@/lib/upload";
import { ageOf, formatDate, fullName, today } from "@/lib/format";
import type { Attachment, Mandate } from "@/lib/types";

const STEPS = ["Appuntamento", "Anagrafica", "Documenti", "Moduli", "Pratica"];

export default function NuovaPraticaPage() {
  const { db, currentUser, createClient, saveDocument, createMandate, createPractice } = useData();
  const router = useRouter();
  const toast = useToast();

  const [step, setStep] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const [appointmentDate, setAppointmentDate] = useState(today());
  const [appointmentTime, setAppointmentTime] = useState("09:00");
  const [noAppointment, setNoAppointment] = useState(false);

  const [clientId, setClientId] = useState<string | null>(null);
  const [newClient, setNewClient] = useState(false);
  const [clientQuery, setClientQuery] = useState("");

  const [docType, setDocType] = useState("Carta d'identità elettronica");
  const [docNumber, setDocNumber] = useState("");
  const [docExpiry, setDocExpiry] = useState("");
  const [docIssuer, setDocIssuer] = useState("");
  const [front, setFront] = useState<Attachment | null>(null);
  const [back, setBack] = useState<Attachment | null>(null);
  const [fiscalCodeDoc, setFiscalCodeDoc] = useState<Attachment | null>(null);

  const [areaId, setAreaId] = useState("cnt-03");
  const [mandateType, setMandateType] = useState<"omnibus" | "servizio">("omnibus");
  const [mandateServices, setMandateServices] = useState<string[]>([]);
  const [scan, setScan] = useState<Attachment | null>(null);
  const [mandate, setMandate] = useState<Mandate | null>(null);

  const [serviceId, setServiceId] = useState("");
  const [description, setDescription] = useState("");
  const [operatorId, setOperatorId] = useState(currentUser?.id ?? db.staff[0]?.id ?? "");
  const [nextActionAt, setNextActionAt] = useState("");
  const [nextActionLabel, setNextActionLabel] = useState("");
  const [nextActionKind, setNextActionKind] = useState<"appuntamento" | "chiamata" | "adempimento">("appuntamento");
  const [mandateOpen, setMandateOpen] = useState(false);

  useEffect(() => {
    const selected = new URLSearchParams(window.location.search).get("cliente");
    if (selected && db.clients.some((item) => item.id === selected)) {
      setClientId(selected);
    }
  }, [db.clients]);

  const client = clientId ? db.clients.find((item) => item.id === clientId) ?? null : null;

  useEffect(() => {
    if (!clientId) return;
    const existing = db.documents.find((item) => item.clientId === clientId);
    if (existing) {
      setDocType(existing.type);
      setDocNumber(existing.number);
      setDocExpiry(existing.expiry);
      setDocIssuer(existing.issuer);
      setFront(existing.front);
      setBack(existing.back);
      setFiscalCodeDoc(existing.fiscalCode);
    } else {
      setDocType("Carta d'identità elettronica");
      setDocNumber("");
      setDocExpiry("");
      setDocIssuer("");
      setFront(null);
      setBack(null);
      setFiscalCodeDoc(null);
    }
  }, [clientId, db.documents]);

  const filteredClients = useMemo(() => {
    const normalized = clientQuery.trim().toLowerCase();
    if (!normalized) return db.clients.slice(0, 8);
    return db.clients
      .filter((item) =>
        `${item.firstName} ${item.lastName} ${item.fiscalCode} ${item.city}`.toLowerCase().includes(normalized),
      )
      .slice(0, 10);
  }, [db.clients, clientQuery]);

  const area = db.containers.find((container) => container.id === areaId)!;
  const areaServices = db.services.filter(
    (service) => service.containerId === areaId && db.activeServiceIds.includes(service.id),
  );
  const activeServices = db.services.filter((service) => db.activeServiceIds.includes(service.id));
  const coverage = clientId && serviceId ? getCoverage(db, clientId, serviceId) : null;
  const clientMandates = clientId ? db.mandates.filter((item) => item.clientId === clientId) : [];

  const handleUpload = async (
    file: File | undefined,
    category: Attachment["category"],
    setter: (attachment: Attachment) => void,
  ) => {
    if (!file) return;
    setError(null);
    try {
      setter(await fileToAttachment(file, category));
      toast.push("Documento caricato.");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Caricamento non riuscito.";
      setError(message);
      toast.push(message);
    }
  };

  const goNext = () => {
    setError(null);
    if (step === 0) {
      if (!noAppointment && !appointmentDate) {
        setError("Indica la data dell'appuntamento oppure seleziona l'accesso diretto.");
        return;
      }
      setStep(1);
      return;
    }
    if (step === 1) {
      if (!clientId) {
        setError("Seleziona un cliente dall'anagrafica oppure creane uno nuovo.");
        return;
      }
      setStep(2);
      return;
    }
    if (step === 2) {
      saveDocument(clientId!, {
        type: docType,
        number: docNumber.toUpperCase(),
        expiry: docExpiry,
        issuer: docIssuer,
        front,
        back,
        fiscalCode: fiscalCodeDoc,
        transcribedBy: currentUser ? fullName(currentUser) : "Operatore",
        transcribedAt: today(),
      });
      setStep(3);
      return;
    }
    if (step === 3) {
      setStep(4);
      return;
    }
  };

  const goBack = () => {
    setError(null);
    setStep((value) => Math.max(0, value - 1));
  };

  const registerMandate = () => {
    if (!clientId) return;
    if (mandateType === "servizio" && mandateServices.length === 0) {
      setError("Seleziona almeno un servizio per il mandato specifico.");
      return;
    }
    const created = createMandate({
      clientId,
      type: mandateType,
      areaId,
      serviceIds: mandateServices,
      signedScan: scan,
      createdBy: currentUser ? `${currentUser.firstName} ${currentUser.lastName}` : "Operatore",
    });
    setMandate(created);
    setScan(null);
    setError(null);
    toast.push(`Mandato registrato · valido fino al ${formatDate(created.expiresAt)}`);
  };

  const createNewClient = (values: ClientFormValues) => {
    const created = createClient(values);
    setClientId(created.id);
    setNewClient(false);
    setStep(2);
    toast.push("Anagrafica creata.");
  };

  const submitPractice = () => {
    if (!clientId) return;
    if (!serviceId) {
      setError("Scegli il tipo di servizio della pratica.");
      return;
    }
    if (!description.trim()) {
      setError("Aggiungi una breve descrizione della pratica.");
      return;
    }
    if (coverage && (coverage.state === "scoperto" || coverage.state === "scaduto")) {
      setError("La copertura del mandato non è valida: registra un nuovo mandato prima di aprire la pratica.");
      return;
    }
    const practice = createPractice({
      clientId,
      serviceId,
      description: description.trim(),
      operatorId,
      nextActionAt: nextActionAt || null,
      nextActionLabel: nextActionLabel.trim(),
      nextActionKind,
      appointmentAt: noAppointment || !appointmentDate ? null : `${appointmentDate}T${appointmentTime}`,
    });
    toast.push(`Pratica ${practice.number} aperta.`);
    router.push(`/pratiche/${practice.id}`);
  };

  return (
    <div className="page">
      <PageHeader
        eyebrow="Nuova pratica"
        crumbs={
          <Crumbs
            items={[
              { label: "Pratiche", href: "/pratiche" },
              { label: "Nuova pratica" },
            ]}
          />
        }
        title="Apri una pratica"
        description="Appuntamento, anagrafica, documenti, moduli e pratica: il percorso completo senza uscire dalla pagina."
        actions={
          <Link href="/pratiche" className="btn btn--ghost">
            Annulla
          </Link>
        }
      />

      <div className="wizard-layout">
        <div className="card">
          <div className="card-body">
            <Stepper steps={STEPS} current={step} />

          <div className="wizard-head">
            <h2>{STEPS[step]}</h2>
            <span className="hint mono">Passo {step + 1} di 5</span>
          </div>

          {step === 0 ? (
            <div className="stack">
              <div className="grid-2">
                <div className="field">
                  <label className="field-label" htmlFor="app-date">Data appuntamento</label>
                  <input
                    id="app-date"
                    type="date"
                    className="input"
                    value={appointmentDate}
                    onChange={(event) => setAppointmentDate(event.target.value)}
                    disabled={noAppointment}
                  />
                </div>
                <div className="field">
                  <label className="field-label" htmlFor="app-time">Ora</label>
                  <input
                    id="app-time"
                    type="time"
                    className="input"
                    value={appointmentTime}
                    onChange={(event) => setAppointmentTime(event.target.value)}
                    disabled={noAppointment}
                  />
                </div>
                <div className="field span-2">
                  <label className="check">
                    <input
                      type="checkbox"
                      checked={noAppointment}
                      onChange={(event) => setNoAppointment(event.target.checked)}
                    />
                    <span>
                      Accesso diretto, senza appuntamento
                      <span className="hint" style={{ display: "block" }}>
                        La pratica viene aperta subito; nessun appuntamento viene aggiunto all&apos;agenda.
                      </span>
                    </span>
                  </label>
                </div>
              </div>

              <div className="note">
                <strong>Prima di iniziare.</strong> Il percorso segue l&apos;ordine dell&apos;ufficio:
                appuntamento, anagrafica, documenti d&apos;identità, moduli di mandato e privacy, quindi la pratica
                con numero interno e servizio.
              </div>
            </div>
          ) : null}

          {step === 1 ? (
            <div className="stack">
              <div className="row" style={{ justifyContent: "space-between", flexWrap: "wrap" }}>
                <div className="chip-row">
                  <button
                    type="button"
                    className={`chip${!newClient ? " active" : ""}`}
                    onClick={() => setNewClient(false)}
                  >
                    Cliente esistente
                  </button>
                  <button
                    type="button"
                    className={`chip${newClient ? " active" : ""}`}
                    onClick={() => setNewClient(true)}
                  >
                    Nuovo cliente
                  </button>
                </div>
                {!newClient ? (
                  <div className="search" style={{ maxWidth: 360 }}>
                    <Icon name="search" />
                    <input
                      className="input"
                      placeholder="Cerca per nome, CF o comune…"
                      value={clientQuery}
                      onChange={(event) => setClientQuery(event.target.value)}
                      aria-label="Cerca cliente"
                    />
                  </div>
                ) : null}
              </div>

              {newClient ? (
                <ClientForm
                  compact
                  submitLabel="Crea anagrafica e continua"
                  onSubmit={createNewClient}
                  onCancel={() => setNewClient(false)}
                />
              ) : (
                <div className="select-list">
                  {filteredClients.map((item) => {
                    const mandates = db.mandates.filter((m) => m.clientId === item.id && !m.revokedAt);
                    const valid = mandates.filter((m) => m.expiresAt >= today());
                    return (
                      <button
                        type="button"
                        key={item.id}
                        className={`select-card${clientId === item.id ? " active" : ""}`}
                        onClick={() => setClientId(item.id)}
                      >
                        <span className="avatar">
                          {item.firstName.charAt(0)}
                          {item.lastName.charAt(0)}
                        </span>
                        <span className="select-card-body">
                          <span className="select-card-name">{fullName(item)}</span>
                          <span className="select-card-meta">
                            <span className="mono">{item.fiscalCode}</span> · {item.city} ({item.province}) ·{" "}
                            {ageOf(item.birthDate)} anni
                          </span>
                        </span>
                        <span className="select-card-tail">
                          {valid.length ? (
                            <span className="pill pill--gold">{valid.length} mandati</span>
                          ) : (
                            <span className="pill pill--danger pill--plain">Scoperto</span>
                          )}
                          {clientId === item.id ? <Icon name="check" size={16} /> : null}
                        </span>
                      </button>
                    );
                  })}
                  {!filteredClients.length ? (
                    <div className="note">
                      Nessun cliente trovato. Passa a <strong>Nuovo cliente</strong> per creare l&apos;anagrafica.
                    </div>
                  ) : null}
                </div>
              )}
            </div>
          ) : null}

          {step === 2 ? (
            <div className="stack">
              {client ? (
                <div className="summary-box">
                  <div className="row-between">
                    <span>Cliente</span>
                    <strong>{fullName(client)}</strong>
                  </div>
                  <div className="row-between">
                    <span>Codice fiscale</span>
                    <span className="mono">{client.fiscalCode}</span>
                  </div>
                </div>
              ) : null}

              <div className="doc-grid">
                <DocSlot
                  label="Carta d'identità · fronte"
                  attachment={front}
                  onFile={(file) => handleUpload(file, "ci_fronte", setFront)}
                  icon="user"
                />
                <DocSlot
                  label="Carta d'identità · retro"
                  attachment={back}
                  onFile={(file) => handleUpload(file, "ci_retro", setBack)}
                  icon="file"
                />
                <DocSlot
                  label="Codice fiscale"
                  attachment={fiscalCodeDoc}
                  onFile={(file) => handleUpload(file, "codice_fiscale", setFiscalCodeDoc)}
                  icon="file"
                />
              </div>

              <div className="form-grid form-grid--3">
                <div className="field">
                  <label className="field-label" htmlFor="doc-type">Tipo documento</label>
                  <select id="doc-type" className="select" value={docType} onChange={(event) => setDocType(event.target.value)}>
                    <option>Carta d&apos;identità elettronica</option>
                    <option>Passaporto</option>
                    <option>Patente di guida</option>
                    <option>Permesso di soggiorno</option>
                  </select>
                </div>
                <div className="field">
                  <label className="field-label" htmlFor="doc-number">Numero documento</label>
                  <input
                    id="doc-number"
                    className="input input--mono"
                    value={docNumber}
                    onChange={(event) => setDocNumber(event.target.value.toUpperCase())}
                    placeholder="CA88124AX"
                  />
                </div>
                <div className="field">
                  <label className="field-label" htmlFor="doc-expiry">Data di scadenza</label>
                  <input
                    id="doc-expiry"
                    type="date"
                    className="input"
                    value={docExpiry}
                    onChange={(event) => setDocExpiry(event.target.value)}
                  />
                </div>
                <div className="field span-3">
                  <label className="field-label" htmlFor="doc-issuer">Ente di rilascio</label>
                  <input
                    id="doc-issuer"
                    className="input"
                    value={docIssuer}
                    onChange={(event) => setDocIssuer(event.target.value)}
                    placeholder="Comune di Bari"
                  />
                </div>
              </div>

              <div className="note">
                <strong>Trascrizione.</strong> L&apos;operatore guarda le immagini caricate e riporta numero,
                scadenza ed ente di rilascio. I tre contenitori restano separati e allegati all&apos;anagrafica.
                I file vengono registrati quando premi <strong>Continua</strong>. Puoi integrarli anche in un
                secondo momento.
              </div>
            </div>
          ) : null}

          {step === 3 ? (
            <div className="stack">
              <div className="form-grid">
                <div className="field">
                  <span className="field-label">Area di interesse</span>
                  <ContainerPicker
                    containers={db.containers.filter((container) => container.loaded !== false)}
                    value={areaId}
                    onChange={(value) => {
                      setAreaId(value);
                      setMandateServices([]);
                    }}
                  />
                  <span className="hint">
                    Il mandato riporta l&apos;area, non il numero pratica. Il testo cambia in base alla scelta.
                  </span>
                </div>
                <div className="field">
                  <span className="field-label">Tipo di mandato</span>
                  <select
                    className="select"
                    value={mandateType}
                    onChange={(event) => setMandateType(event.target.value as "omnibus" | "servizio")}
                  >
                    <option value="omnibus">Macro-gruppo omnibus · 12 mesi</option>
                    <option value="servizio">Servizi specifici dell&apos;area</option>
                  </select>
                </div>
              </div>

              {mandateType === "servizio" ? (
                <div className="field">
                  <span className="field-label">Servizi coperti · {area.code}</span>
                  <div style={{ display: "grid", gap: 2, maxHeight: 220, overflowY: "auto", border: "1px solid var(--line-soft)", padding: "4px 12px" }}>
                    {areaServices.map((service) => (
                      <label className="check" key={service.id} style={{ borderBottom: "1px solid var(--line-soft)" }}>
                        <input
                          type="checkbox"
                          checked={mandateServices.includes(service.id)}
                          onChange={() =>
                            setMandateServices((prev) =>
                              prev.includes(service.id)
                                ? prev.filter((id) => id !== service.id)
                                : [...prev, service.id],
                            )
                          }
                        />
                        <span>
                          {service.name} <span className="mono hint">{service.code}</span>
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="note">
                  <strong>Omnibus.</strong> Copre tutti i servizi dell&apos;agenzia per 12 mesi, revocabile in
                  qualsiasi momento. Non richiede un nuovo mandato per ogni pratica.
                </div>
              )}

              <div className="grid-2">
                <div className="card">
                  <div className="card-head">
                    <div>
                      <div className="card-title">Stampa il modulo</div>
                      <div className="card-sub">Si compila con i dati dell&apos;anagrafica</div>
                    </div>
                    <Icon name="printer" />
                  </div>
                  <div className="card-body stack-sm">
                    <a
                      className="btn btn--ghost btn--sm"
                      href={`/moduli/${clientId}/mandato?area=${areaId}&tipo=${mandateType}&servizi=${encodeURIComponent(
                        mandateServices.join(","),
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Icon name="printer" /> Apri anteprima stampabile
                    </a>
                    <span className="hint">
                      Firma in ufficio, scansiona e allega qui accanto. Il mandato resta valido 12 mesi.
                    </span>
                  </div>
                </div>

                <div className="card">
                  <div className="card-head">
                    <div>
                      <div className="card-title">Modulo firmato</div>
                      <div className="card-sub">Carica la scansione</div>
                    </div>
                    <Icon name="upload" />
                  </div>
                  <div className="card-body stack-sm">
                    <label className="dropzone">
                      <input
                        type="file"
                        accept="image/*,application/pdf"
                        onChange={(event) => handleUpload(event.target.files?.[0], "mandato_firmato", setScan)}
                      />
                      <Icon name="upload" />
                      <strong>{scan ? "Sostituisci scansione" : "Allega scansione"}</strong>
                      <span>JPG, PNG o PDF · max 8 MB</span>
                    </label>
                    {scan ? <span className="hint">{scan.name}</span> : null}
                    <button type="button" className="btn btn--sm" onClick={registerMandate}>
                      Registra mandato
                    </button>
                    {mandate ? (
                      <span className="hint" style={{ color: "var(--ok)" }}>
                        Mandato attivo fino al {formatDate(mandate.expiresAt)}.
                      </span>
                    ) : null}
                  </div>
                </div>
              </div>

              {clientMandates.length ? (
                <div className="card">
                  <div className="card-head">
                    <div className="card-title">Mandati già presenti</div>
                    <span className="hint">{clientMandates.length}</span>
                  </div>
                  <div className="card-body" style={{ paddingTop: 6 }}>
                    <div className="mini-list">
                      {clientMandates.map((item) => (
                        <div className="mini-item" key={item.id}>
                          <div>
                            <div className="cell-strong">
                              {item.type === "omnibus" ? "Macro-gruppo Omnibus" : "Mandato per servizio"}
                            </div>
                            <div className="mono" style={{ fontSize: 10 }}>
                              {formatDate(item.signedAt)} → {formatDate(item.expiresAt)}
                            </div>
                          </div>
                          <span className={`pill ${item.expiresAt >= today() ? "pill--gold" : "pill--danger"}`}>
                            {item.expiresAt >= today() ? "Valido" : "Scaduto"}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : null}

              <div className="note">
                <strong>Puoi anche procedere senza firmare ora.</strong> La pratica potrà essere aperta solo con
                una copertura valida: il controllo avviene al passo successivo.
              </div>
            </div>
          ) : null}

          {step === 4 ? (
            <div className="stack">
              <div className="form-grid">
                <div className="field">
                  <label className="field-label" htmlFor="service">Tipo di servizio<span className="req">*</span></label>
                  <select
                    id="service"
                    className="select"
                    value={serviceId}
                    onChange={(event) => setServiceId(event.target.value)}
                  >
                    <option value="">Scegli un servizio attivo…</option>
                    {db.containers
                      .filter((container) => container.loaded !== false)
                      .map((container) => {
                        const services = activeServices.filter((service) => service.containerId === container.id);
                        if (!services.length) return null;
                        return (
                          <optgroup key={container.id} label={`${container.code} — ${container.name}`}>
                            {services.map((service) => (
                              <option key={service.id} value={service.id}>
                                {service.name}
                              </option>
                            ))}
                          </optgroup>
                        );
                      })}
                  </select>
                </div>
                <div className="field">
                  <label className="field-label" htmlFor="operator">Operatore assegnato</label>
                  <select
                    id="operator"
                    className="select"
                    value={operatorId}
                    onChange={(event) => setOperatorId(event.target.value)}
                  >
                    {db.staff
                      .filter((member) => member.active)
                      .map((member) => (
                        <option key={member.id} value={member.id}>
                          {fullName(member)} · {member.role}
                        </option>
                      ))}
                  </select>
                </div>
                <div className="field span-2">
                  <label className="field-label" htmlFor="description">Breve descrizione<span className="req">*</span></label>
                  <textarea
                    id="description"
                    className="textarea"
                    value={description}
                    onChange={(event) => setDescription(event.target.value)}
                    placeholder="Oggetto della pratica, documenti ricevuti, note per il lavoro…"
                    rows={3}
                  />
                </div>
              </div>

              {coverage ? (
                <CoverageBanner
                  coverage={coverage}
                  action={
                    coverage.state === "scoperto" || coverage.state === "scaduto" ? (
                      <button type="button" className="btn btn--sm" onClick={() => setMandateOpen(true)}>
                        <Icon name="plus" /> Nuovo mandato
                      </button>
                    ) : undefined
                  }
                />
              ) : (
                <div className="note">Scegli il servizio per attivare il controllo del mandato.</div>
              )}

              <div className="card">
                <div className="card-head">
                  <div>
                    <div className="card-title">Prossima azione</div>
                    <div className="card-sub">Alimenta la dashboard e la progressione</div>
                  </div>
                  <Icon name="clock" />
                </div>
                <div className="card-body">
                  <div className="form-grid form-grid--3">
                    <div className="field">
                      <label className="field-label" htmlFor="next-kind">Tipo</label>
                      <select
                        id="next-kind"
                        className="select"
                        value={nextActionKind}
                        onChange={(event) =>
                          setNextActionKind(event.target.value as "appuntamento" | "chiamata" | "adempimento")
                        }
                      >
                        <option value="appuntamento">Appuntamento</option>
                        <option value="chiamata">Chiamata</option>
                        <option value="adempimento">Adempimento</option>
                      </select>
                    </div>
                    <div className="field">
                      <label className="field-label" htmlFor="next-date">Data</label>
                      <input
                        id="next-date"
                        type="date"
                        className="input"
                        value={nextActionAt}
                        onChange={(event) => setNextActionAt(event.target.value)}
                      />
                    </div>
                    <div className="field">
                      <label className="field-label" htmlFor="next-label">Nota</label>
                      <input
                        id="next-label"
                        className="input"
                        value={nextActionLabel}
                        onChange={(event) => setNextActionLabel(event.target.value)}
                        placeholder="Es. ricontattare per integrazione"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="summary-box">
                <div className="row-between">
                  <span>Cliente</span>
                  <strong>{client ? fullName(client) : "—"}</strong>
                </div>
                <div className="row-between">
                  <span>Appuntamento</span>
                  <span className="mono">
                    {noAppointment || !appointmentDate ? "Accesso diretto" : `${formatDate(appointmentDate)} · ${appointmentTime}`}
                  </span>
                </div>
                <div className="row-between">
                  <span>Area moduli</span>
                  <span className="mono">{area.code}</span>
                </div>
                <div className="row-between">
                  <span>Mandato</span>
                  <span>{mandate ? `Firmato · scade ${formatDate(mandate.expiresAt)}` : "Da verificare"}</span>
                </div>
              </div>
            </div>
          ) : null}

          {error ? <div className="error-text mt-16">{error}</div> : null}

          <div className="wizard-actions">
            <button
              type="button"
              className="btn btn--ghost"
              onClick={step === 0 ? () => router.push("/pratiche") : goBack}
            >
              <Icon name="chevron-left" /> {step === 0 ? "Annulla" : "Indietro"}
            </button>
            {step < 4 ? (
              <button type="button" className="btn" onClick={goNext}>
                Continua <Icon name="arrow-right" />
              </button>
            ) : (
              <button type="button" className="btn" onClick={submitPractice}>
                <Icon name="check" /> Apri la pratica
              </button>
            )}
          </div>
        </div>
      </div>

      <aside className="side-panel">
          <section className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Riepilogo</div>
                <div className="card-sub">Passo {step + 1} di 5</div>
              </div>
              <Icon name="file" style={{ color: "var(--slate)" }} />
            </div>
            <div className="card-body stack-sm">
              <div className="summary-box">
                <div className="row-between">
                  <span>Cliente</span>
                  <strong>{client ? fullName(client) : "Da selezionare"}</strong>
                </div>
                <div className="row-between">
                  <span>Appuntamento</span>
                  <span className="mono">
                    {noAppointment || !appointmentDate ? "Accesso diretto" : `${formatDate(appointmentDate)} · ${appointmentTime}`}
                  </span>
                </div>
                <div className="row-between">
                  <span>Area moduli</span>
                  <span className="mono">{area.code}</span>
                </div>
                <div className="row-between">
                  <span>Mandato</span>
                  <span>
                    {mandate
                      ? `Scade ${formatDate(mandate.expiresAt)}`
                      : coverage
                        ? coverage.label
                        : "Da verificare"}
                  </span>
                </div>
                <div className="row-between">
                  <span>Servizio</span>
                  <span>
                    {serviceId
                      ? activeServices.find((service) => service.id === serviceId)?.name ?? "—"
                      : "Da scegliere"}
                  </span>
                </div>
              </div>
              {coverage ? (
                <CoverageBanner coverage={coverage} compact />
              ) : (
                <p className="hint">Il controllo del mandato si attiva quando scegli il servizio, al passo 5.</p>
              )}
            </div>
          </section>

          <div className="note">
            <strong>Percorso reversibile.</strong> Puoi tornare indietro e correggere i dati fino all&apos;apertura
            della pratica. I documenti già caricati restano nell&apos;anagrafica.
          </div>
        </aside>
      </div>

      {mandateOpen && clientId ? (
        <NewMandateModal
          clientId={clientId}
          defaultServiceId={serviceId}
          onClose={() => setMandateOpen(false)}
        />
      ) : null}
    </div>
  );
}

function DocSlot({
  label,
  attachment,
  onFile,
  icon,
}: {
  label: string;
  attachment: Attachment | null;
  onFile: (file: File | undefined) => void;
  icon: "user" | "file";
}) {
  return (
    <div className="doc-tile">
      <div className={`doc-frame doc-frame--action${attachment ? " doc-frame--filled" : ""}`}>
        <input
          type="file"
          accept="image/*,application/pdf"
          onChange={(event) => {
            onFile(event.target.files?.[0]);
            event.target.value = "";
          }}
          aria-label={`Carica ${label}`}
        />
        {attachment ? (
          attachment.mime.startsWith("image/") ? (
            <img src={attachment.dataUrl} alt={`Anteprima ${label}`} />
          ) : (
            <div className="doc-placeholder" style={{ color: "var(--ivory)" }}>
              <Icon name={icon} />
              PDF
            </div>
          )
        ) : (
          <div className="doc-placeholder">
            <Icon name="upload" />
            Carica
          </div>
        )}
      </div>
      <div className="doc-label">
        <strong>{label}</strong>
        <span>{attachment ? "Caricato" : "Mancante"}</span>
      </div>
    </div>
  );
}
