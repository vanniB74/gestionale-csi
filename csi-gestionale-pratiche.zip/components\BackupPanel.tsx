"use client";

import { useEffect, useRef, useState } from "react";
import { useData } from "@/lib/store";
import { Icon } from "@/components/Icon";
import { useToast } from "@/components/Toast";
import { formatDateTime } from "@/lib/format";
import {
  CLOUD_ENDPOINT_KEY,
  CLOUD_LAST_KEY,
  CLOUD_TOKEN_KEY,
  LOCAL_LAST_KEY,
  backupFileName,
  buildBackup,
  downloadBackupFile,
  fetchBackupFromEndpoint,
  parseBackup,
  saveBackupToFolder,
  sendBackupToEndpoint,
  shareBackup,
} from "@/lib/backup";

export function BackupPanel() {
  const { db, importDatabase } = useData();
  const toast = useToast();
  const fileInput = useRef<HTMLInputElement>(null);

  const [lastLocal, setLastLocal] = useState<string | null>(null);
  const [lastCloud, setLastCloud] = useState<string | null>(null);
  const [endpoint, setEndpoint] = useState("");
  const [token, setToken] = useState("");
  const [endpointDraft, setEndpointDraft] = useState("");
  const [tokenDraft, setTokenDraft] = useState("");
  const [configOpen, setConfigOpen] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setLastLocal(window.localStorage.getItem(LOCAL_LAST_KEY));
    setLastCloud(window.localStorage.getItem(CLOUD_LAST_KEY));
    const storedEndpoint = window.localStorage.getItem(CLOUD_ENDPOINT_KEY) ?? "";
    const storedToken = window.localStorage.getItem(CLOUD_TOKEN_KEY) ?? "";
    setEndpoint(storedEndpoint);
    setToken(storedToken);
    setEndpointDraft(storedEndpoint);
    setTokenDraft(storedToken);
    setConfigOpen(Boolean(storedEndpoint));
  }, []);

  const serialize = () => JSON.stringify(buildBackup(db), null, 2);

  const downloadLocal = () => {
    const content = serialize();
    downloadBackupFile(content, backupFileName());
    const at = new Date().toISOString();
    window.localStorage.setItem(LOCAL_LAST_KEY, at);
    setLastLocal(at);
    toast.push("Backup locale scaricato.");
  };

  const shareCloud = async () => {
    setError(null);
    setBusy("share");
    try {
      const content = serialize();
      const outcome = await shareBackup(content, backupFileName("csi-backup-cloud"));
      if (outcome === "shared") {
        setLastCloud(window.localStorage.getItem(CLOUD_LAST_KEY));
        toast.push("Backup inviato alla destinazione cloud scelta.");
        return;
      }
      if (outcome === "cancelled") {
        toast.push("Condivisione annullata.");
        return;
      }
      setBusy(null);
      await saveFolder();
    } finally {
      setBusy(null);
    }
  };

  const saveFolder = async () => {
    setError(null);
    setBusy("folder");
    try {
      const content = serialize();
      const outcome = await saveBackupToFolder(content, backupFileName("csi-backup-cloud"));
      if (outcome === "saved") {
        setLastCloud(window.localStorage.getItem(CLOUD_LAST_KEY));
        toast.push("Backup salvato nella cartella scelta.");
      } else if (outcome === "cancelled") {
        toast.push("Salvataggio annullato.");
      } else {
        downloadBackupFile(content, backupFileName("csi-backup-cloud"));
        const at = new Date().toISOString();
        window.localStorage.setItem(CLOUD_LAST_KEY, at);
        setLastCloud(at);
        setError(
          "Il browser non consente la scelta della cartella: il file è stato scaricato. Spostalo nella cartella sincronizzata con il tuo cloud.",
        );
      }
    } finally {
      setBusy(null);
    }
  };

  const saveEndpoint = () => {
    const clean = endpointDraft.trim();
    window.localStorage.setItem(CLOUD_ENDPOINT_KEY, clean);
    window.localStorage.setItem(CLOUD_TOKEN_KEY, tokenDraft);
    setEndpoint(clean);
    setToken(tokenDraft);
    setError(null);
    toast.push(clean ? "Endpoint di backup cloud salvato." : "Endpoint rimosso.");
  };

  const sendCloud = async () => {
    setError(null);
    setBusy("send");
    try {
      const result = await sendBackupToEndpoint(endpoint, token, serialize());
      if (!result.ok) {
        setError(result.error ?? "Invio non riuscito.");
        return;
      }
      setLastCloud(window.localStorage.getItem(CLOUD_LAST_KEY));
      toast.push("Backup inviato all'endpoint cloud.");
    } finally {
      setBusy(null);
    }
  };

  const restoreFromText = (text: string, source: "file" | "cloud") => {
    const result = parseBackup(text);
    if (!result.ok || !result.backup) {
      setError(result.error ?? "Backup non valido.");
      return;
    }
    const backup = result.backup;
    const created = formatDateTime(backup.createdAt);
    const confirmed = window.confirm(
      `Ripristinare il backup del ${created}?\n\nClienti: ${backup.counts.clients} · Pratiche: ${backup.counts.practices} · Mandati: ${backup.counts.mandates}.\n\nI dati attuali dell'archivio locale verranno sostituiti.`,
    );
    if (!confirmed) return;
    importDatabase(backup.data);
    setError(null);
    if (source === "file") {
      const at = new Date().toISOString();
      window.localStorage.setItem(LOCAL_LAST_KEY, at);
      setLastLocal(at);
    }
    toast.push("Backup ripristinato.");
  };

  const restoreFile = async (file: File | undefined) => {
    if (!file) return;
    try {
      restoreFromText(await file.text(), "file");
    } catch {
      setError("Impossibile leggere il file selezionato.");
    }
  };

  const restoreCloud = async () => {
    setError(null);
    setBusy("restore");
    try {
      const result = await fetchBackupFromEndpoint(endpoint, token);
      if (!result.ok || !result.text) {
        setError(result.error ?? "Ripristino cloud non riuscito.");
        return;
      }
      restoreFromText(result.text, "cloud");
    } finally {
      setBusy(null);
    }
  };

  return (
    <section className="card" id="backup">
      <div className="card-head">
        <div>
          <div className="card-title">Backup e ripristino</div>
          <div className="card-sub">Copia completa di anagrafiche, pratiche, mandati e credenziali</div>
        </div>
        <span className="pill pill--gold pill--plain">
          <Icon name="shield" size={12} /> Dati sensibili
        </span>
      </div>

      <div className="backup-grid">
        <div className="backup-block">
          <span className="eyebrow">Locale</span>
          <p className="hint" style={{ margin: "8px 0 14px" }}>
            Scarica un file JSON con tutto l&apos;archivio. Conservalo su un supporto protetto: contiene dati
            personali e password dello staff.
          </p>
          <div className="row" style={{ flexWrap: "wrap" }}>
            <button type="button" className="btn btn--sm" onClick={downloadLocal}>
              <Icon name="download" /> Scarica backup
            </button>
            <button type="button" className="btn btn--ghost btn--sm" onClick={() => fileInput.current?.click()}>
              <Icon name="upload" /> Ripristina da file
            </button>
            <input
              ref={fileInput}
              type="file"
              accept="application/json,.json"
              onChange={(event) => {
                void restoreFile(event.target.files?.[0]);
                event.target.value = "";
              }}
              hidden
            />
          </div>
          <div className="stat-line mt-16">
            <span>Ultimo backup locale</span>
            <strong>{lastLocal ? formatDateTime(lastLocal) : "—"}</strong>
          </div>
          <div className="stat-line">
            <span>Contenuto</span>
            <strong>
              {db.clients.length} clienti · {db.practices.length} pratiche
            </strong>
          </div>
        </div>

        <div className="backup-block">
          <span className="eyebrow">Cloud</span>
          <p className="hint" style={{ margin: "8px 0 14px" }}>
            Salva il backup nel cloud del dispositivo (Google Drive, OneDrive, iCloud) con la condivisione di
            sistema, oppure in una cartella sincronizzata.
          </p>
          <div className="row" style={{ flexWrap: "wrap" }}>
            <button type="button" className="btn btn--sm" onClick={shareCloud} disabled={busy === "share"}>
              <Icon name="external" /> {busy === "share" ? "Preparazione…" : "Salva su cloud"}
            </button>
            <button type="button" className="btn btn--ghost btn--sm" onClick={saveFolder} disabled={busy === "folder"}>
              <Icon name="folder" /> Cartella cloud
            </button>
            {endpoint ? (
              <button type="button" className="btn btn--ghost btn--sm" onClick={sendCloud} disabled={busy === "send"}>
                <Icon name="upload" /> Invia all&apos;endpoint
              </button>
            ) : null}
            {endpoint ? (
              <button type="button" className="btn btn--ghost btn--sm" onClick={restoreCloud} disabled={busy === "restore"}>
                <Icon name="download" /> Ripristina dal cloud
              </button>
            ) : null}
          </div>
          <div className="stat-line mt-16">
            <span>Ultimo backup cloud</span>
            <strong>{lastCloud ? formatDateTime(lastCloud) : "—"}</strong>
          </div>
          <div className="stat-line">
            <span>Endpoint</span>
            <strong>{endpoint ? "configurato" : "non configurato"}</strong>
          </div>
        </div>
      </div>

      <div className="card-body" style={{ borderTop: "1px solid var(--line-soft)" }}>
        <button
          type="button"
          className="backup-config-toggle"
          onClick={() => setConfigOpen((value) => !value)}
          aria-expanded={configOpen}
        >
          <span className="eyebrow eyebrow--plain">Endpoint di backup cloud (opzionale)</span>
          <Icon name={configOpen ? "chevron-right" : "plus"} size={14} />
        </button>

        {configOpen ? (
          <div className="backup-config">
            <div className="form-grid">
              <div className="field">
                <label className="field-label" htmlFor="backup-endpoint">URL endpoint</label>
                <input
                  id="backup-endpoint"
                  className="input input--mono"
                  value={endpointDraft}
                  onChange={(event) => setEndpointDraft(event.target.value)}
                  placeholder="https://api.esempio.it/csi/backup"
                  autoComplete="off"
                />
              </div>
              <div className="field">
                <label className="field-label" htmlFor="backup-token">Token (opzionale)</label>
                <input
                  id="backup-token"
                  className="input"
                  type="password"
                  value={tokenDraft}
                  onChange={(event) => setTokenDraft(event.target.value)}
                  autoComplete="off"
                />
              </div>
            </div>
            <p className="hint mt-8">
              L&apos;endpoint riceve <span className="mono">POST</span> con il JSON del backup e{" "}
              <span className="mono">GET</span> per il ripristino, con <span className="mono">Authorization: Bearer</span> se
              il token è impostato. Deve consentire CORS dal dominio del gestionale.
            </p>
            <div className="row mt-8">
              <button type="button" className="btn btn--sm" onClick={saveEndpoint}>
                Salva configurazione
              </button>
              {endpoint ? (
                <button
                  type="button"
                  className="btn btn--ghost btn--sm"
                  onClick={() => {
                    setEndpointDraft("");
                    setTokenDraft("");
                    window.localStorage.removeItem(CLOUD_ENDPOINT_KEY);
                    window.localStorage.removeItem(CLOUD_TOKEN_KEY);
                    setEndpoint("");
                    setToken("");
                    toast.push("Endpoint rimosso.");
                  }}
                >
                  Rimuovi endpoint
                </button>
              ) : null}
            </div>
          </div>
        ) : null}

        {error ? <div className="error-text mt-16">{error}</div> : null}

        <div className="note mt-16">
          <strong>Protezione dei dati.</strong> Il backup contiene dati personali e credenziali in chiaro:
          trattalo come un documento riservato. Il ripristino sostituisce integralmente l&apos;archivio locale e
          non è reversibile.
        </div>
      </div>
    </section>
  );
}
