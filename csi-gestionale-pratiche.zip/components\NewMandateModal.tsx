"use client";

import { useMemo, useState } from "react";
import { Modal } from "./Modal";
import { Icon } from "./Icon";
import { useData } from "@/lib/store";
import { getCoverage } from "@/lib/store";
import type { Attachment, Mandate, MandateType, Service } from "@/lib/types";
import { fileToAttachment } from "@/lib/upload";
import { ContainerPicker } from "./ContainerPicker";
import { useToast } from "./Toast";
import { addMonths, formatDate, today } from "@/lib/format";

export function NewMandateModal({
  clientId,
  defaultServiceId,
  onClose,
  onCreated,
}: {
  clientId: string;
  defaultServiceId?: string;
  onClose: () => void;
  onCreated?: (mandate: Mandate) => void;
}) {
  const { db, currentUser, createMandate, attachMandateScan } = useData();
  const toast = useToast();

  const defaultService = defaultServiceId
    ? db.services.find((service) => service.id === defaultServiceId)
    : undefined;
  const latestMandate = db.mandates.find((mandate) => mandate.clientId === clientId);

  const [areaId, setAreaId] = useState(defaultService?.containerId ?? latestMandate?.areaId ?? "cnt-03");
  const [type, setType] = useState<MandateType>("omnibus");
  const [selected, setSelected] = useState<string[]>(
    defaultService ? [defaultService.id] : [],
  );
  const [scan, setScan] = useState<Attachment | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const area = db.containers.find((c) => c.id === areaId)!;
  const areaServices = useMemo(
    () =>
      db.services.filter(
        (service) => service.containerId === areaId && db.activeServiceIds.includes(service.id),
      ),
    [db, areaId],
  );

  const coverage = defaultServiceId ? getCoverage(db, clientId, defaultServiceId) : null;

  const toggleService = (service: Service) => {
    setSelected((prev) =>
      prev.includes(service.id) ? prev.filter((id) => id !== service.id) : [...prev, service.id],
    );
  };

  const handleFile = async (file: File | undefined) => {
    if (!file) return;
    setError(null);
    setBusy(true);
    try {
      const attachment = await fileToAttachment(file, "mandato_firmato");
      setScan(attachment);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Caricamento non riuscito.");
    } finally {
      setBusy(false);
    }
  };

  const save = () => {
    if (type === "servizio" && selected.length === 0) {
      setError("Seleziona almeno un servizio coperto dal mandato.");
      return;
    }
    if (!scan) {
      setError("Allega la scansione del modulo firmato per registrare il mandato.");
      return;
    }
    const mandate = createMandate({
      clientId,
      type,
      areaId,
      serviceIds: selected,
      signedScan: scan,
      createdBy: currentUser ? `${currentUser.firstName} ${currentUser.lastName}` : "Operatore",
    });
    if (scan) attachMandateScan(mandate.id, scan);
    toast.push(`Mandato registrato · valido fino al ${formatDate(mandate.expiresAt)}`);
    onCreated?.(mandate);
    onClose();
  };

  const previewHref = `/moduli/${clientId}/mandato?area=${areaId}&tipo=${type}&servizi=${encodeURIComponent(
    selected.join(","),
  )}`;

  return (
    <Modal
      eyebrow="Copertura del cliente"
      title="Nuovo mandato"
      onClose={onClose}
      width="wide"
      footer={
        <>
          <a className="btn btn--ghost btn--sm" href={previewHref} target="_blank" rel="noopener noreferrer">
            <Icon name="printer" /> Apri modulo stampabile
          </a>
          <span className="spacer" />
          <button type="button" className="btn btn--ghost" onClick={onClose}>
            Annulla
          </button>
          <button type="button" className="btn" onClick={save} disabled={busy}>
            Registra mandato
          </button>
        </>
      }
    >
      <div className="module-layout" style={{ gridTemplateColumns: "minmax(0, 1.15fr) minmax(280px, 0.85fr)" }}>
        <div className="stack">
          {coverage ? (
            <div className={`coverage coverage--${coverage.state}`}>
              <span className="coverage-icon">
                <Icon name={coverage.state === "scoperto" || coverage.state === "scaduto" ? "alert" : "shield"} />
              </span>
              <div>
                <div className="coverage-title">Situazione attuale · {coverage.label}</div>
                <div className="coverage-detail">{coverage.detail}</div>
              </div>
            </div>
          ) : null}

          <div className="field">
            <span className="field-label">Area di interesse</span>
            <ContainerPicker containers={db.containers} value={areaId} onChange={setAreaId} />
            <span className="hint">
              Il mandato riporta l&apos;area di servizio, non il numero di pratica. Il testo cambia in base
              all&apos;area scelta.
            </span>
          </div>

          <div className="field">
            <span className="field-label">Tipo di copertura</span>
            <div className="grid-2">
              <label className="check" style={{ border: "1px solid var(--line)", padding: "12px 14px" }}>
                <input type="radio" name="mandate-type" checked={type === "omnibus"} onChange={() => setType("omnibus")} />
                <span>
                  <strong>Macro-gruppo omnibus</strong>
                  <span className="hint" style={{ display: "block" }}>
                    Tutti i servizi dell&apos;agenzia · 12 mesi · revocabile
                  </span>
                </span>
              </label>
              <label className="check" style={{ border: "1px solid var(--line)", padding: "12px 14px" }}>
                <input type="radio" name="mandate-type" checked={type === "servizio"} onChange={() => setType("servizio")} />
                <span>
                  <strong>Servizi specifici</strong>
                  <span className="hint" style={{ display: "block" }}>
                    Solo i servizi selezionati dell&apos;area
                  </span>
                </span>
              </label>
            </div>
          </div>

          <div className="field">
            <span className="field-label">Servizi coperti · {area.code}</span>
            {type === "omnibus" ? (
              <div className="note">
                L&apos;omnibus copre tutti i servizi C.S.I. e resta valido 12 mesi. Include l&apos;accesso alle
                banche dati degli enti eroganti.
              </div>
            ) : areaServices.length ? (
              <div style={{ display: "grid", gap: 2, maxHeight: 210, overflowY: "auto", border: "1px solid var(--line-soft)", padding: "4px 12px" }}>
                {areaServices.map((service) => (
                  <label className="check" key={service.id} style={{ borderBottom: "1px solid var(--line-soft)" }}>
                    <input
                      type="checkbox"
                      checked={selected.includes(service.id)}
                      onChange={() => toggleService(service)}
                    />
                    <span>
                      {service.name}
                      <span className="mono hint" style={{ marginLeft: 6 }}>{service.code}</span>
                    </span>
                  </label>
                ))}
              </div>
            ) : (
              <div className="hint">Nessun servizio attivo in questa area. Attivali dall&apos;area Webmaster.</div>
            )}
          </div>
        </div>

        <div className="stack">
          <div className="card">
            <div className="card-head">
              <div>
                <div className="card-title">Modulo firmato</div>
                <div className="card-sub">Stampa, firma, scansiona, allega</div>
              </div>
              <Icon name="file" />
            </div>
            <div className="card-body stack-sm">
              <label className="dropzone">
                <input
                  type="file"
                  accept="image/*,application/pdf"
                  onChange={(e) => handleFile(e.target.files?.[0])}
                />
                <Icon name="upload" />
                <strong>{scan ? "Sostituisci scansione" : "Carica il modulo firmato"}</strong>
                <span>JPG, PNG o PDF · max 8 MB</span>
              </label>
              {scan ? (
                <div>
                  <img src={scan.dataUrl} alt="Anteprima del mandato firmato" className="scan-thumb" />
                  <div className="hint mt-8">{scan.name}</div>
                </div>
              ) : null}
            </div>
          </div>

          <div className="note">
            <strong>Validità 12 mesi.</strong> Decorrenza {formatDate(today())} · scadenza{" "}
            {formatDate(addMonths(today(), 12))}. Revocabile in qualsiasi momento per iscritto.
          </div>

          {error ? <div className="error-text">{error}</div> : null}
        </div>
      </div>
    </Modal>
  );
}
