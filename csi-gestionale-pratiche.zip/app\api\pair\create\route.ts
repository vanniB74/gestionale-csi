import { NextResponse } from "next/server";
import { createPairRequest } from "@/lib/pairing";
import { apiGuard } from "@/lib/api-guard";

export const dynamic = "force-dynamic";

export const POST = apiGuard("api/pair/create", async () => {
  const request = createPairRequest();
  return NextResponse.json({
    token: request.token,
    expiresAt: request.expiresAt,
  });
});
