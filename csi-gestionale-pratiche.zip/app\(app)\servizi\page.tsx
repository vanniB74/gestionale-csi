"use client";

import { useMemo, useState } from "react";
import { useData } from "@/lib/store";
import { PageHeader } from "@/components/ui";
import { Icon } from "@/components/Icon";
import { useToast } from "@/components/Toast";

export default function ServiziPage() {
  const { db, currentUser, toggleService } = useData();
  const toast = useToast();
  const [query, setQuery] = useState("");
  const isWebmaster = currentUser?.role === "webmaster";

  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return db.containers.map((container) => ({
      container,
      services: db.services.filter(
        (service) =>
          service.containerId === container.id &&
          (!normalized || service.name.toLowerCase().includes(normalized) || service.code.toLowerCase().includes(normalized)),
      ),
    }));
  }, [db.containers, db.services, query]);

  const activeCount = db.activeServiceIds.length;
  const localCount = db.services.filter((service) => service.local).length;

  const areaActive = (containerId: string) => {
    const services = db.services.filter((service) => service.containerId === containerId);
    if (!services.length) return db.activeServiceIds.includes(containerId);
    return services.every((service) => db.activeServiceIds.includes(service.id));
  };

  const toggleArea = (containerId: string, active: boolean) => {
    const services = db.services.filter((service) => service.containerId === containerId);
    services.forEach((service) => {
      const isActive = db.activeServiceIds.includes(service.id);
      if (active !== isActive) toggleService(service.id);
    });
    toast.push(active ? "Area attivata nel catalogo." : "Area disattivata.");
  };

  return (
    <div className="page page--wide">
      <PageHeader
        eyebrow="Catalogo · CNT-01 / CNT-06"
        title="Servizi dell'ufficio"
        description="Il catalogo sorgente C.S.I. con i codici originali. Il webmaster attiva i servizi: solo quelli compaiono nei campi delle pratiche."
        actions={
          isWebmaster ? (
            <span className="pill pill--gold pill--plain">
              <Icon name="shield" size={12} /> Webmaster
            </span>
          ) : (
            <span className="pill pill--in_attesa pill--plain">Sola lettura</span>
          )
        }
      />

      <div className="grid-4 mb-16">
        <div className="kpi">
          <div className="kpi-label">Contenitori</div>
          <div className="kpi-value">{String(db.containers.length).padStart(2, "0")}</div>
          <div className="kpi-hint">Aree di servizio del catalogo</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Servizi attivi</div>
          <div className="kpi-value">{String(activeCount).padStart(2, "0")}</div>
          <div className="kpi-hint">Visibili nelle pratiche</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Servizi a catalogo</div>
          <div className="kpi-value">{String(db.services.length).padStart(2, "0")}</div>
          <div className="kpi-hint">Codici caricati in questa build</div>
        </div>
        <div className="kpi">
          <div className="kpi-label">Voci locali</div>
          <div className="kpi-value">{String(localCount).padStart(2, "0")}</div>
          <div className="kpi-hint">Da mappare al master CSI</div>
        </div>
      </div>

      {!isWebmaster ? (
        <div className="note mb-16">
          <strong>Catalogo in sola lettura.</strong> L&apos;attivazione dei servizi è riservata all&apos;area
          webmaster. Gli operatori vedono solo i servizi già attivi.
        </div>
      ) : null}

      <section className="card mb-16">
        <div className="filters">
          <div className="search">
            <Icon name="search" />
            <input
              className="input"
              placeholder="Cerca servizio o codice…"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              aria-label="Cerca servizi"
            />
          </div>
          <span className="hint" style={{ marginLeft: "auto" }}>
            {db.activeServiceIds.length} attivi su {db.services.length} codici
          </span>
        </div>
      </section>

      <div className="stack">
        {filtered.map(({ container, services }) => {
          const active = areaActive(container.id);
          const activeInArea = services.filter((service) => db.activeServiceIds.includes(service.id)).length;
          return (
            <section className="card" key={container.id}>
              <div className="card-head">
                <div>
                  <div className="row" style={{ gap: 10 }}>
                    <span className="mono" style={{ fontSize: 10.5, color: "var(--gold-deep)" }}>
                      {container.code}
                    </span>
                    <span className="card-title">{container.name}</span>
                  </div>
                  <div className="card-sub">
                    {container.subareas.join(" · ")}
                    {container.declaredCount ? ` · ${container.declaredCount} servizi dichiarati` : ""}
                  </div>
                </div>
                {container.loaded === false ? (
                  <span className="pill pill--in_attesa">Da importare</span>
                ) : isWebmaster ? (
                  <label className="switch">
                    <input
                      type="checkbox"
                      checked={active}
                      onChange={(event) => toggleArea(container.id, event.target.checked)}
                    />
                    <span className="switch-track" />
                    {active ? "Attiva" : "Spenta"}
                  </label>
                ) : (
                  <span className={`pill ${active ? "pill--gold" : "pill--in_attesa"}`}>
                    {active ? "Attiva" : "Spenta"}
                  </span>
                )}
              </div>

              <div className="card-body">
                {container.loaded === false ? (
                  <div className="note">
                    <strong>Contenitore non ancora importato.</strong> Il master dichiara {container.declaredCount}{" "}
                    servizi di visura e multiservizi. L&apos;import verrà fatto dall&apos;area webmaster quando
                    l&apos;attività lo richiede: nessun codice viene inventato in questa sede.
                  </div>
                ) : services.length ? (
                  <>
                    <div className="service-list">
                      {services.map((service) => {
                        const isActive = db.activeServiceIds.includes(service.id);
                        return (
                          <label
                            key={service.id}
                            className={`service-item${isActive ? "" : " is-off"}`}
                            style={{ cursor: isWebmaster ? "pointer" : "default" }}
                          >
                            <input
                              type="checkbox"
                              checked={isActive}
                              disabled={!isWebmaster}
                              onChange={() => toggleService(service.id)}
                              aria-label={`Attiva ${service.name}`}
                            />
                            <span className="service-code">{service.code}</span>
                            <span className="service-name">{service.name}</span>
                            {service.local ? <span className="service-tag">locale</span> : null}
                          </label>
                        );
                      })}
                    </div>
                    <div className="row mt-16" style={{ justifyContent: "space-between", flexWrap: "wrap" }}>
                      <span className="hint">
                        {activeInArea} di {services.length} attivi in questa area
                      </span>
                      <span className="hint mono">originali: {container.code} · 01–{String(services.length).padStart(2, "0")}</span>
                    </div>
                  </>
                ) : (
                  <p className="hint">Nessun servizio corrisponde alla ricerca.</p>
                )}
              </div>
            </section>
          );
        })}
      </div>

      <div className="note mt-24">
        <strong>Nota di allineamento.</strong> I codici CNT-01…CNT-05 sono trascritti dal documento «Architettura
        contenitori e codici progressivi dei servizi». Le voci contrassegnate come locali (ISEE, 730, ricalcolo
        pensione, pagamenti comunali, bonus fiscali) servono a coprire le pratiche descritte nelle specifiche e
        vanno mappate al master CSI. Il contenitore CNT-06 non è importato.
      </div>
    </div>
  );
}
