import type { Attachment } from "./types";
import { uid } from "./store";

const MAX_INPUT = 8 * 1024 * 1024;

function readAsDataURL(file: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Lettura del file non riuscita."));
    reader.readAsDataURL(file);
  });
}

async function compressImage(file: File, maxSide = 1280, quality = 0.78): Promise<string> {
  const dataUrl = await readAsDataURL(file);
  const image = await new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () =>
      reject(
        new Error(
          "Impossibile leggere l'immagine. Se è una foto HEIC/HEIF (iPhone), convertila in JPG o PNG e riprova.",
        ),
      );
    img.src = dataUrl;
  });
  const ratio = Math.min(1, maxSide / Math.max(image.width, image.height));
  const width = Math.round(image.width * ratio);
  const height = Math.round(image.height * ratio);
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) return dataUrl;
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(image, 0, 0, width, height);
  return canvas.toDataURL("image/jpeg", quality);
}

export async function fileToAttachment(
  file: File,
  category: Attachment["category"],
): Promise<Attachment> {
  if (file.size > MAX_INPUT) {
    throw new Error("File troppo grande: il limite è 8 MB.");
  }
  let dataUrl: string;
  if (file.type.startsWith("image/")) {
    dataUrl = await compressImage(file, 1200, 0.76);
    if (dataUrl.length > 1_100_000) {
      dataUrl = await compressImage(file, 960, 0.62);
    }
  } else {
    dataUrl = await readAsDataURL(file);
  }
  const mime = dataUrl.startsWith("data:image/jpeg") ? "image/jpeg" : file.type || "application/octet-stream";
  return {
    id: uid("att"),
    name: file.name,
    mime,
    size: Math.round((dataUrl.length * 3) / 4),
    dataUrl,
    uploadedAt: new Date().toISOString(),
    category,
  };
}

export function shortSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
