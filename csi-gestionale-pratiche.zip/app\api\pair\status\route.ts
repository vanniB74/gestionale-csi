import { NextResponse } from "next/server";
import { getPairRequest } from "@/lib/pairing";
import { apiGuard } from "@/lib/api-guard";

export const dynamic = "force-dynamic";

export const GET = apiGuard("api/pair/status", async (request) => {
  const token = new URL(request.url).searchParams.get("token") ?? "";
  const pair = getPairRequest(token);
  if (!pair) {
    return NextResponse.json({ status: "expired" });
  }
  return NextResponse.json({
    status: pair.claimedBy ? "claimed" : "pending",
    staffId: pair.claimedBy?.staffId ?? null,
    staffName: pair.claimedBy?.staffName ?? null,
    expiresAt: pair.expiresAt,
  });
});
