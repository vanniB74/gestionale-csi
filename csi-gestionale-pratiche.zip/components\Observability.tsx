"use client";

import { useEffect } from "react";
import { installGlobalGuards } from "@/lib/guards";

export function Observability() {
  useEffect(() => installGlobalGuards(), []);
  return null;
}
