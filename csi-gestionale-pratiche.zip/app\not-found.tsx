import Link from "next/link";
import { Logo } from "@/components/Logo";

export default function NotFound() {
  return (
    <div className="welcome" style={{ minHeight: "100vh", display: "grid", placeItems: "center" }}>
      <div style={{ textAlign: "center", padding: 32, maxWidth: 520 }}>
        <Logo variant="light" width={200} />
        <div className="eyebrow eyebrow--invert" style={{ marginTop: 40 }}>Errore 404</div>
        <h1 style={{ fontFamily: "var(--font-display)", fontSize: 42, fontWeight: 500, letterSpacing: "-0.03em", marginTop: 12 }}>
          Pagina non trovata
        </h1>
        <p style={{ marginTop: 12, color: "rgba(247,244,237,.6)", fontSize: 14 }}>
          La pagina che cerchi non esiste o è stata spostata. Torna al gestionale o alla pagina di benvenuto.
        </p>
        <div className="wl-actions" style={{ justifyContent: "center" }}>
          <Link href="/dashboard" className="btn btn--light">Dashboard</Link>
          <Link href="/" className="btn btn--ghost" style={{ color: "var(--ivory)", borderColor: "rgba(247,244,237,.3)" }}>
            Pagina di benvenuto
          </Link>
        </div>
      </div>
    </div>
  );
}
