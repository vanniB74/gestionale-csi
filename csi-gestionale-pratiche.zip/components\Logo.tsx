import Image from "next/image";

export function Logo({
  variant = "color",
  width = 190,
  priority = false,
  className = "",
}: {
  variant?: "color" | "light";
  width?: number;
  priority?: boolean;
  className?: string;
}) {
  return (
    <Image
      src={variant === "light" ? "/brand/csi-logo-light.png" : "/brand/csi-logo.png"}
      alt="C.S.I. — Centro Servizi Integrati"
      width={1200}
      height={603}
      priority={priority}
      className={className}
      style={{ width, height: "auto" }}
    />
  );
}
