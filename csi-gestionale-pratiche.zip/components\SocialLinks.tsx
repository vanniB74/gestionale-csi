"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { Icon } from "./Icon";

export const SOCIAL_PROFILES = [
  {
    id: "linkedin",
    name: "LinkedIn",
    href: "https://www.linkedin.com/company/csi-sportello-al-cittadino/",
    icon: "link" as const,
  },
  {
    id: "facebook",
    name: "Facebook",
    href: "https://www.facebook.com/cassano.giuseppe.csi/about/",
    icon: "user" as const,
  },
];

export function SocialLinks({
  size = "sm",
  label = "Seguici",
  className = "",
}: {
  size?: "sm" | "md" | "lg";
  label?: string | null;
  className?: string;
}) {
  const [still, setStill] = useState(false);

  useEffect(() => {
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setStill(query.matches);
    update();
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);

  const sizeClass = size === "lg" ? "social-btn--lg" : size === "md" ? "social-btn--md" : "";

  return (
    <div className={`social social--inline ${className}`}>
      {label ? <span className="social-label">{label}</span> : null}
      <div className="social-links">
        {SOCIAL_PROFILES.map((profile) => (
          <a
            key={profile.id}
            href={profile.href}
            target="_blank"
            rel="noopener noreferrer"
            className={`social-btn ${sizeClass}`}
            aria-label={`C.S.I. su ${profile.name} — si apre in una nuova scheda`}
          >
            <span className="social-media">
              {still ? (
                <Image
                  src={`/social/${profile.id}.png`}
                  alt=""
                  width={144}
                  height={144}
                  aria-hidden="true"
                />
              ) : (
                <video autoPlay muted loop playsInline preload="metadata" poster={`/social/${profile.id}.png`}>
                  <source src={`/social/${profile.id}.webm`} type="video/webm" />
                  <source src={`/social/${profile.id}.mp4`} type="video/mp4" />
                </video>
              )}
            </span>
            <span className="social-tip">{profile.name}</span>
          </a>
        ))}
        <span className="sr-only">
          Profili social ufficiali C.S.I. — si aprono in una nuova scheda.
        </span>
      </div>
    </div>
  );
}

export function SocialRow({ label = "Seguici" }: { label?: string }) {
  return (
    <div className="social-row">
      <SocialLinks label={label} />
      <span className="dim" style={{ fontSize: 9, letterSpacing: "0.14em", textTransform: "uppercase" }}>
        <Icon name="external" size={10} style={{ verticalAlign: "-1px", marginRight: 5 }} />
        profili ufficiali
      </span>
    </div>
  );
}
