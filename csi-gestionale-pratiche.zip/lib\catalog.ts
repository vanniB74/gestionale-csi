import type { Database, ServiceContainer, Service } from "./types";

export const OFFICE = {
  name: "C.S.I. — Centro Servizi Integrati",
  legal: "Di Cassano Giuseppe",
  vat: "C.F. / P.IVA 92860040728",
  address: "Sezione Piazza Vittorio Emanuele 41",
  city: "Ceglie del Campo · 70129 Bari (BA)",
  phone: "080 817 8431",
  email: "info.csi.bari@gmail.com",
  site: "www.centroserviziintegrati.it",
  legalRep: "Giuseppe Cassano",
};

export const CONTAINERS: ServiceContainer[] = [
  {
    id: "cnt-01",
    code: "CNT-01",
    name: "Servizi Generali, Finanziari, Legali e Digitali",
    area: "Servizi generali",
    subareas: ["Legale", "Finanziario", "Digitale"],
  },
  {
    id: "cnt-02",
    code: "CNT-02",
    name: "Immobiliare e Tecnici",
    area: "Immobiliare",
    subareas: ["Immobiliare", "Tecnici"],
  },
  {
    id: "cnt-03",
    code: "CNT-03",
    name: "Fisco, Lavoro e Previdenza",
    area: "Fisco e previdenza",
    subareas: ["Agenzia Entrate", "CAF", "Lavoro", "Patronato"],
  },
  {
    id: "cnt-04",
    code: "CNT-04",
    name: "Stranieri",
    area: "Stranieri",
    subareas: ["Stranieri"],
  },
  {
    id: "cnt-05",
    code: "CNT-05",
    name: "Utenze: Gas, Luce e Telefonia",
    area: "Utenze",
    subareas: ["Gas", "Luce", "Telefonia"],
  },
  {
    id: "cnt-06",
    code: "CNT-06",
    name: "Visure & Multiservizi",
    area: "Visure",
    subareas: ["Certificati", "Immobili e Catasto", "Imprese e Persone", "Indagini e Rintracci"],
    declaredCount: 153,
    loaded: false,
  },
];

type Raw = [string, string, string];

const raw: Record<string, Raw[]> = {
  "cnt-01": [
    ["CNT-01-01", "Assistenza Legale", "ALT01"],
    ["CNT-01-02", "Certificati INAIL", "ALT03"],
    ["CNT-01-03", "Certificati Medici", "ALT02"],
    ["CNT-01-04", "Cessione del 5 (1)", "—"],
    ["CNT-01-05", "Cessione del 5 (2)", "—"],
    ["CNT-01-06", "Finanziamenti (1)", "—"],
    ["CNT-01-07", "Finanziamenti (2)", "—"],
    ["CNT-01-08", "Firma Digitale", "ALT04"],
    ["CNT-01-09", "PEC 1 anno", "ALT05"],
    ["CNT-01-10", "SPID Identità Digitale", "MSR-01"],
  ],
  "cnt-02": [
    ["CNT-02-01", "APE Attestato Certificazione Energetica", "TEC02"],
    ["CNT-02-02", "Accatastamento", "TEC01"],
    ["CNT-02-03", "ENEA Certificazione", "TEC03"],
    ["CNT-02-04", "Estratto di Mappa", "TEC04"],
    ["CNT-02-05", "Finanziamenti Assicurazioni FIMASS", "FIN-01"],
    ["CNT-02-06", "Frazionamento Terreni", "TEC05"],
    ["CNT-02-07", "Incarico Acquisto FIMASS", "IMM-02"],
    ["CNT-02-08", "Incarico Vendita FIMASS", "IMM-01"],
    ["CNT-02-09", "Planimetria Asseverata", "TEC06"],
    ["CNT-02-10", "Planimetria Catastale", "TEC07"],
    ["CNT-02-11", "Variazione Catastale", "TEC08"],
    ["CNT-02-12", "Variazione di Coltura", "TEC09"],
    ["CNT-02-13", "Visura Catastale Ordinaria", "TEC10"],
    ["CNT-02-14", "Visura Catastale Storica", "TEC11"],
    ["CNT-02-15", "Visure Ipotecarie · Servizio", "TEC13"],
    ["CNT-02-16", "Voltura Catastale · Servizio", "—"],
  ],
  "cnt-03": [
    ["CNT-03-01", "Adempimenti Successivi alla Locazione", "AGE03"],
    ["CNT-03-02", "Apertura Posizione INPS Gestione Autonoma", "AGE09"],
    ["CNT-03-03", "Assistenza Annuale Paghe Domestico", "LAV06"],
    ["CNT-03-04", "Assistenza Assunzione Domestico", "LAV07"],
    ["CNT-03-05", "Assistenza CUD Domestico", "LAV09"],
    ["CNT-03-06", "Assistenza Cessazione Domestico", "LAV08"],
    ["CNT-03-07", "Attestazione Asseverata Canoni Concordati", "AGE05"],
    ["CNT-03-08", "Camera di Commercio Apertura/Chiusura", "AGE08"],
    ["CNT-03-09", "Comodato d'Uso Gratuito", "AGE04"],
    ["CNT-03-10", "Conciliazione in Sede Sindacale", "LAV10"],
    ["CNT-03-11", "Conteggi Altri Settori fino 5 anni", "LAV03"],
    ["CNT-03-12", "Conteggi Altri Settori oltre 5 anni", "LAV04"],
    ["CNT-03-13", "Conteggi di Lavoro Domestico", "LAV02"],
    ["CNT-03-14", "Dimissioni", "LAV01"],
    ["CNT-03-15", "Paghe e Contributi", "LAV05"],
    ["CNT-03-16", "Partita IVA Apertura/Chiusura", "AGE07"],
    ["CNT-03-17", "Registrazione Contratto di Locazione", "AGE02"],
    ["CNT-03-18", "SCIA per Apertura Attività", "AGE10"],
    ["CNT-03-19", "Stesura Contratto di Locazione", "AGE01"],
    ["CNT-03-20", "Successioni", "AGE06"],
  ],
  "cnt-04": [
    ["CNT-04-01", "Apostille Procura", "STR08"],
    ["CNT-04-02", "Cittadinanza Residenza/Matrimonio", "STR01"],
    ["CNT-04-03", "Esame A2", "STR10"],
    ["CNT-04-04", "Esami B1", "STR06"],
    ["CNT-04-05", "Legalizzazione in Prefettura", "STR09"],
    ["CNT-04-06", "Permesso di Soggiorno", "STR02"],
    ["CNT-04-07", "Ricongiungimento Familiare", "STR03"],
    ["CNT-04-08", "Ritiro Casellario Carichi Pendenti", "STR07"],
    ["CNT-04-09", "Traduzioni", "STR04"],
    ["CNT-04-10", "Visti Turistici", "—"],
  ],
  "cnt-05": [
    ["CNT-05-01", "Assistenza linea internet", "UTE-T04"],
    ["CNT-05-02", "Attivazione contatore gas", "UTE-G01"],
    ["CNT-05-03", "Attivazione contatore luce", "UTE-L01"],
    ["CNT-05-04", "Attivazione linea fissa", "UTE-T01"],
    ["CNT-05-05", "Cambio fornitore gas", "UTE-G02"],
    ["CNT-05-06", "Cambio fornitore luce", "UTE-L02"],
    ["CNT-05-07", "Cambio operatore mobile", "UTE-T02"],
    ["CNT-05-08", "Contestazione bolletta gas", "UTE-G03"],
    ["CNT-05-09", "Contestazione bolletta luce", "UTE-L03"],
    ["CNT-05-10", "Contestazione bolletta telefono", "UTE-T03"],
    ["CNT-05-11", "Rimborso doppia fatturazione gas", "UTE-G04"],
    ["CNT-05-12", "Rimborso doppia fatturazione luce", "—"],
  ],
};

const local: Raw[] = [
  ["LOC-ISEE", "ISEE · DSU", "voce locale"],
  ["LOC-730", "Modello 730", "voce locale"],
  ["LOC-PENS", "Ricalcolo pensione", "voce locale"],
  ["LOC-TARI", "Pagamenti comunali · TARI", "voce locale"],
  ["LOC-BONUS", "Bonus fiscali", "voce locale"],
];

export const SERVICES: Service[] = [
  ...Object.entries(raw).flatMap(([containerId, list]) =>
    list.map(([code, name, originalCode]) => ({
      id: code.toLowerCase(),
      code,
      originalCode,
      name,
      containerId,
    })),
  ),
  ...local.map(([code, name, originalCode]) => ({
    id: code.toLowerCase(),
    code,
    originalCode,
    name,
    containerId: "cnt-03",
    local: true,
  })),
];

export const ACTIVE_DEFAULT = SERVICES.filter(
  (service) => service.containerId === "cnt-03" || service.containerId === "cnt-04",
).map((service) => service.id);

export const serviceById = (db: Database, id: string) => db.services.find((s) => s.id === id);
export const containerById = (db: Database, id: string) => db.containers.find((c) => c.id === id);
