export const pad = (n: number) => String(n).padStart(2, "0");

export const isoDay = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export const today = () => isoDay(new Date());

export function addDays(base: Date | string, days: number): string {
  const d = typeof base === "string" ? new Date(base + "T12:00:00") : new Date(base);
  d.setDate(d.getDate() + days);
  return isoDay(d);
}

export function addMonths(base: Date | string, months: number): string {
  const d = typeof base === "string" ? new Date(base + "T12:00:00") : new Date(base);
  const day = d.getDate();
  d.setMonth(d.getMonth() + months);
  if (d.getDate() < day) d.setDate(0);
  return isoDay(d);
}

export function formatDate(value: string | null | undefined): string {
  if (!value) return "—";
  const d = new Date(value.length > 10 ? value : value + "T12:00:00");
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("it-IT", { day: "2-digit", month: "2-digit", year: "numeric" });
}

export function formatLongDate(value: string | Date): string {
  const d = typeof value === "string" ? new Date(value.length > 10 ? value : value + "T12:00:00") : value;
  return d.toLocaleDateString("it-IT", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
}

export function formatDateTime(value: string): string {
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("it-IT", { day: "2-digit", month: "short" }) + " · " +
    d.toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" });
}

export function daysUntil(value: string | null | undefined): number {
  if (!value) return 0;
  const target = new Date((value.length > 10 ? value : value + "T12:00:00")).getTime();
  const now = new Date();
  now.setHours(12, 0, 0, 0);
  return Math.round((target - now.getTime()) / 86_400_000);
}

export function ageOf(birthDate: string): number {
  const b = new Date(birthDate + "T12:00:00");
  const now = new Date();
  let age = now.getFullYear() - b.getFullYear();
  const m = now.getMonth() - b.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < b.getDate())) age -= 1;
  return age;
}

export function initials(first: string, last: string): string {
  return `${first.charAt(0)}${last.charAt(0)}`.toUpperCase();
}

export function fullName(p: { firstName: string; lastName: string }): string {
  return `${p.firstName} ${p.lastName}`;
}

export function euro(value: number): string {
  return value.toLocaleString("it-IT", { style: "currency", currency: "EUR" });
}

export function dateInputValue(value: string | null | undefined): string {
  if (!value) return "";
  return value.slice(0, 10);
}
