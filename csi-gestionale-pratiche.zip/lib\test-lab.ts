import { getCoverage } from "@/lib/store";
import { addDays, addMonths, today } from "@/lib/format";
import type { Database } from "@/lib/types";

interface FixtureClient {
  id: string;
  firstName: string;
  lastName: string;
  sex: "M" | "F";
  birthDate: string;
  birthPlace: string;
  citizenship: string;
  fiscalCode: string;
  address: string;
  cap: string;
  city: string;
  province: string;
  phone: string;
  email: string;
  notes: string;
  createdDaysAgo: number;
  privacyScan: null;
}

interface FixtureMandate {
  id: string;
  clientId: string;
  type: "omnibus" | "servizio";
  areaId: string;
  serviceIds: string[];
  signedDaysAgo: number;
  revoked: boolean;
}

interface FixtureDocument {
  id: string;
  clientId: string;
  number: string;
  expiryDaysFromNow: number;
  issuer: string;
  type: string;
  transcribedBy: string;
  transcribedDaysAgo: number;
}

interface FixturePractice {
  id: string;
  number: string;
  clientId: string;
  serviceId: string;
  areaId: string;
  description: string;
  status: "aperta" | "in_lavorazione" | "in_attesa" | "conclusa";
  openedDaysAgo: number;
  operatorId: string;
  nextActionDays: number | null;
  nextActionLabel: string;
  nextActionKind: "appuntamento" | "chiamata" | "adempimento";
}

interface FixtureAppointment {
  id: string;
  clientId: string;
  clientName: string;
  daysFromNow: number;
  time: string;
  reason: string;
  operatorId: string;
  status: "programmato" | "confermato" | "annullato";
}

export interface TestFixture {
  name: string;
  version: number;
  clients: FixtureClient[];
  mandates: FixtureMandate[];
  documents: FixtureDocument[];
  practices: FixturePractice[];
  appointments: FixtureAppointment[];
}

export interface TestCase {
  id: string;
  area: string;
  title: string;
  check:
    | "coverage_state"
    | "practice_blocked"
    | "mandate_expiry_months"
    | "unique_numbers"
    | "has_document"
    | "missing_document"
    | "missing_privacy"
    | "overdue_actions"
    | "next_action_missing";
  clientId?: string;
  serviceId?: string;
  practiceId?: string;
  mandateId?: string;
  expect: unknown;
}

interface TestCaseFile {
  version: number;
  fixture: string;
  cases: TestCase[];
}

export interface TestResult {
  id: string;
  area: string;
  title: string;
  pass: boolean;
  expected: string;
  actual: string;
  durationMs: number;
  error?: string;
}

export interface TestLabRun {
  runAt: string;
  fixturePath: string;
  fixtureName: string;
  casesPath: string;
  results: TestResult[];
  passed: number;
  failed: number;
  durationMs: number;
  persistedTestRecords: number;
  sandbox: {
    clients: number;
    mandates: number;
    practices: number;
    documents: number;
    appointments: number;
  };
}

async function loadJson<T>(path: string): Promise<T> {
  const response = await fetch(path, { cache: "no-store" });
  if (!response.ok) throw new Error(`Fixture non disponibile: ${path} (${response.status})`);
  return (await response.json()) as T;
}

export function buildSandbox(base: Database, fixture: TestFixture): Database {
  const sandbox: Database = structuredClone(base);
  const now = today();

  sandbox.clients = fixture.clients.map((client) => ({
    id: client.id,
    firstName: client.firstName,
    lastName: client.lastName,
    sex: client.sex,
    birthDate: client.birthDate,
    birthPlace: client.birthPlace,
    citizenship: client.citizenship,
    fiscalCode: client.fiscalCode,
    address: client.address,
    cap: client.cap,
    city: client.city,
    province: client.province,
    phone: client.phone,
    email: client.email,
    notes: client.notes,
    createdAt: addDays(now, -client.createdDaysAgo),
    privacyScan: null,
  }));

  sandbox.documents = fixture.documents.map((document) => ({
    id: document.id,
    clientId: document.clientId,
    number: document.number,
    expiry: addDays(now, document.expiryDaysFromNow),
    issuer: document.issuer,
    type: document.type,
    transcribedBy: document.transcribedBy,
    transcribedAt: addDays(now, -document.transcribedDaysAgo),
    front: null,
    back: null,
    fiscalCode: null,
  }));

  sandbox.mandates = fixture.mandates.map((mandate) => {
    const signedAt = addDays(now, -mandate.signedDaysAgo);
    return {
      id: mandate.id,
      clientId: mandate.clientId,
      type: mandate.type,
      areaId: mandate.areaId,
      serviceIds: mandate.serviceIds,
      signedAt,
      expiresAt: addMonths(signedAt, 12),
      revokedAt: mandate.revoked ? now : null,
      createdBy: "Sandbox test",
      signedScan: null,
    };
  });

  const fallbackOperator = base.staff[0]?.id ?? "test-staff";
  sandbox.practices = fixture.practices.map((practice) => ({
    id: practice.id,
    number: practice.number,
    clientId: practice.clientId,
    serviceId: practice.serviceId,
    areaId: practice.areaId,
    description: practice.description,
    status: practice.status,
    openedAt: addDays(now, -practice.openedDaysAgo),
    operatorId: base.staff.some((member) => member.id === practice.operatorId)
      ? practice.operatorId
      : fallbackOperator,
    nextActionAt: practice.nextActionDays === null ? null : addDays(now, practice.nextActionDays),
    nextActionLabel: practice.nextActionLabel,
    nextActionKind: practice.nextActionKind,
    timeline: [
      {
        id: `${practice.id}-tl`,
        at: new Date().toISOString(),
        label: "Sandbox test",
        detail: "Record creato nella copia in memoria, mai scritto nell'archivio.",
        author: "Test lab",
      },
    ],
    attachments: [],
    closedAt: null,
  }));

  sandbox.appointments = fixture.appointments.map((appointment) => ({
    id: appointment.id,
    clientId: appointment.clientId,
    clientName: appointment.clientName,
    date: addDays(now, appointment.daysFromNow),
    time: appointment.time,
    reason: appointment.reason,
    operatorId: base.staff.some((member) => member.id === appointment.operatorId)
      ? appointment.operatorId
      : fallbackOperator,
    status: appointment.status,
  }));

  sandbox.sequence = 9000;
  return sandbox;
}

function monthsBetween(from: string, to: string): number {
  const start = new Date(`${from}T12:00:00`);
  const end = new Date(`${to}T12:00:00`);
  return (end.getFullYear() - start.getFullYear()) * 12 + (end.getMonth() - start.getMonth());
}

function runCase(sandbox: Database, testCase: TestCase): unknown {
  switch (testCase.check) {
    case "coverage_state": {
      if (!testCase.clientId || !testCase.serviceId) throw new Error("clientId/serviceId mancanti");
      return getCoverage(sandbox, testCase.clientId, testCase.serviceId).state;
    }
    case "practice_blocked": {
      const practice = sandbox.practices.find((item) => item.id === testCase.practiceId);
      if (!practice) throw new Error("Pratica di test non trovata");
      const state = getCoverage(sandbox, practice.clientId, practice.serviceId).state;
      return state === "scoperto" || state === "scaduto";
    }
    case "mandate_expiry_months": {
      const mandate = sandbox.mandates.find((item) => item.id === testCase.mandateId);
      if (!mandate) throw new Error("Mandato di test non trovato");
      return monthsBetween(mandate.signedAt, mandate.expiresAt);
    }
    case "unique_numbers": {
      const numbers = sandbox.practices.map((practice) => practice.number);
      return new Set(numbers).size === numbers.length;
    }
    case "has_document":
      return sandbox.documents.some((document) => document.clientId === testCase.clientId);
    case "missing_document":
      return !sandbox.documents.some((document) => document.clientId === testCase.clientId);
    case "missing_privacy":
      return !sandbox.clients.find((client) => client.id === testCase.clientId)?.privacyScan;
    case "overdue_actions": {
      const now = today();
      return sandbox.practices.filter(
        (practice) => practice.status !== "conclusa" && practice.nextActionAt && practice.nextActionAt < now,
      ).length;
    }
    case "next_action_missing":
      return sandbox.practices.filter((practice) => practice.status !== "conclusa" && !practice.nextActionAt).length;
    default:
      throw new Error(`Check non riconosciuto: ${testCase.check}`);
  }
}

export async function runTestLab(base: Database): Promise<TestLabRun> {
  const started = performance.now();
  const casesFile = await loadJson<TestCaseFile>("/test-data/cases.json");
  const fixture = await loadJson<TestFixture>(casesFile.fixture);
  const sandbox = buildSandbox(base, fixture);

  const results: TestResult[] = casesFile.cases.map((testCase) => {
    const caseStart = performance.now();
    try {
      const actual = runCase(sandbox, testCase);
      const pass = JSON.stringify(actual) === JSON.stringify(testCase.expect);
      return {
        id: testCase.id,
        area: testCase.area,
        title: testCase.title,
        pass,
        expected: JSON.stringify(testCase.expect),
        actual: JSON.stringify(actual),
        durationMs: Math.round((performance.now() - caseStart) * 100) / 100,
      };
    } catch (error) {
      return {
        id: testCase.id,
        area: testCase.area,
        title: testCase.title,
        pass: false,
        expected: JSON.stringify(testCase.expect),
        actual: "errore",
        durationMs: Math.round((performance.now() - caseStart) * 100) / 100,
        error: error instanceof Error ? error.message : "Errore sconosciuto",
      };
    }
  });

  const persistedTestRecords =
    base.clients.filter((item) => item.id.startsWith("test-")).length +
    base.mandates.filter((item) => item.id.startsWith("test-")).length +
    base.practices.filter((item) => item.id.startsWith("test-")).length +
    base.documents.filter((item) => item.id.startsWith("test-")).length;

  return {
    runAt: new Date().toISOString(),
    fixturePath: casesFile.fixture,
    fixtureName: fixture.name,
    casesPath: "/test-data/cases.json",
    results,
    passed: results.filter((result) => result.pass).length,
    failed: results.filter((result) => !result.pass).length,
    durationMs: Math.round((performance.now() - started) * 100) / 100,
    persistedTestRecords,
    sandbox: {
      clients: sandbox.clients.length,
      mandates: sandbox.mandates.length,
      practices: sandbox.practices.length,
      documents: sandbox.documents.length,
      appointments: sandbox.appointments.length,
    },
  };
}
