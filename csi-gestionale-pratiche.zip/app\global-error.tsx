"use client";

import { useEffect } from "react";
import { logGuardError } from "@/lib/guards";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    logGuardError({ section: "global", error, severity: "critical", context: { digest: error.digest } });
  }, [error]);

  return (
    <html lang="it">
      <body
        style={{
          margin: 0,
          minHeight: "100vh",
          display: "grid",
          placeItems: "center",
          background: "#001C3A",
          color: "#F7F4ED",
          fontFamily: "Inter, system-ui, sans-serif",
          padding: 24,
        }}
      >
        <div style={{ maxWidth: 560, textAlign: "center" }}>
          <div style={{ fontSize: 10, letterSpacing: "0.18em", textTransform: "uppercase", opacity: 0.6 }}>
            C.S.I. · Guardiano globale
          </div>
          <h1 style={{ fontSize: 30, letterSpacing: "-0.02em", margin: "12px 0" }}>
            Il gestionale si è fermato in sicurezza
          </h1>
          <p style={{ color: "rgba(247,244,237,0.65)", lineHeight: 1.7, fontSize: 14 }}>
            L&apos;errore è stato registrato nel browser. Ricarica la pagina o contatta il webmaster con il
            registro errori.
          </p>
          <p style={{ fontFamily: "monospace", fontSize: 11, opacity: 0.5, marginTop: 16 }}>{error.message}</p>
          <button
            type="button"
            onClick={reset}
            style={{
              marginTop: 22,
              height: 40,
              padding: "0 18px",
              background: "#F7F4ED",
              color: "#001C3A",
              border: 0,
              textTransform: "uppercase",
              letterSpacing: "0.08em",
              fontSize: 11,
              cursor: "pointer",
            }}
          >
            Riprova
          </button>
        </div>
      </body>
    </html>
  );
}
