import type { ReactNode } from "react";
import Link from "next/link";
import { Icon, type IconName } from "./Icon";
import type { Coverage, PracticeStatus } from "@/lib/types";

export const STATUS_LABEL: Record<PracticeStatus, string> = {
  aperta: "Aperta",
  in_lavorazione: "In lavorazione",
  in_attesa: "In attesa",
  conclusa: "Conclusa",
};

export function StatusPill({ status }: { status: PracticeStatus }) {
  return <span className={`pill pill--${status}`}>{STATUS_LABEL[status]}</span>;
}

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
  crumbs,
}: {
  eyebrow: string;
  title: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  crumbs?: ReactNode;
}) {
  return (
    <header className="page-head">
      <div>
        {crumbs ? <div className="crumbs mb-16">{crumbs}</div> : null}
        <span className="eyebrow">{eyebrow}</span>
        <h1>{title}</h1>
        {description ? <p>{description}</p> : null}
      </div>
      {actions ? <div className="page-head-actions">{actions}</div> : null}
    </header>
  );
}

export function CoverageBanner({
  coverage,
  action,
  compact = false,
}: {
  coverage: Coverage;
  action?: ReactNode;
  compact?: boolean;
}) {
  const icon: IconName =
    coverage.state === "omnibus" || coverage.state === "servizio"
      ? "shield"
      : coverage.state === "scaduto"
        ? "clock"
        : "alert";
  return (
    <div className={`coverage coverage--${coverage.state}`}>
      <span className="coverage-icon">
        <Icon name={icon} />
      </span>
      <div style={{ minWidth: 0, flex: 1 }}>
        <div className="coverage-title">
          {coverage.label}
          {coverage.expiresAt && coverage.state !== "scoperto" ? (
            <span className="mono" style={{ marginLeft: 8, fontSize: 10, fontWeight: 400, color: "var(--mist)" }}>
              {coverage.expiresAt}
            </span>
          ) : null}
        </div>
        {!compact ? <div className="coverage-detail">{coverage.detail}</div> : null}
      </div>
      {action ? <div style={{ flex: "none" }}>{action}</div> : null}
    </div>
  );
}

export function EmptyState({
  icon = "folder",
  title,
  text,
  action,
}: {
  icon?: IconName;
  title: string;
  text?: string;
  action?: ReactNode;
}) {
  return (
    <div className="empty">
      <span className="empty-icon">
        <Icon name={icon} size={20} />
      </span>
      <h3>{title}</h3>
      {text ? <p>{text}</p> : null}
      {action ? <div className="mt-16">{action}</div> : null}
    </div>
  );
}

export function Stepper({ steps, current }: { steps: string[]; current: number }) {
  return (
    <div className="stepper">
      {steps.map((step, index) => (
        <div
          key={step}
          className={`step${index < current ? " done" : ""}${index === current ? " current" : ""}`}
        >
          <div className="step-num">{String(index + 1).padStart(2, "0")}</div>
          <div className="step-label">{step}</div>
        </div>
      ))}
    </div>
  );
}

export function Definition({
  items,
  columns = 2,
}: {
  items: Array<{ label: string; value: ReactNode; mono?: boolean }>;
  columns?: number;
}) {
  return (
    <div className="definition" style={columns === 3 ? { gridTemplateColumns: "repeat(3, minmax(0, 1fr))" } : undefined}>
      {items.map((item) => (
        <div className="definition-item" key={item.label}>
          <div className="definition-label">{item.label}</div>
          <div className={`definition-value${item.mono ? " mono" : ""}`}>{item.value || "—"}</div>
        </div>
      ))}
    </div>
  );
}

export function Crumbs({ items }: { items: Array<{ label: string; href?: string }> }) {
  return (
    <>
      {items.map((item, index) => (
        <span key={`${item.label}-${index}`} style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
          {item.href ? <Link href={item.href}>{item.label}</Link> : <span>{item.label}</span>}
          {index < items.length - 1 ? <Icon name="chevron-right" /> : null}
        </span>
      ))}
    </>
  );
}
