import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { DataProvider } from "@/lib/store";
import { ToastProvider } from "@/components/Toast";
import { Observability } from "@/components/Observability";

const inter = localFont({
  src: "./fonts/inter-400.woff2",
  variable: "--font-inter",
  weight: "100 900",
  display: "swap",
});

const interTight = localFont({
  src: "./fonts/inter-tight-500.woff2",
  variable: "--font-inter-tight",
  weight: "100 900",
  display: "swap",
});

const jetbrains = localFont({
  src: "./fonts/jetbrains-mono-400.woff2",
  variable: "--font-jetbrains",
  weight: "100 800",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "C.S.I. · Gestionale pratiche ufficio",
    template: "%s · C.S.I.",
  },
  description:
    "Gestionale interno C.S.I. Centro Servizi Integrati: anagrafiche, documenti, mandati e avanzamento delle pratiche dell'ufficio.",
  applicationName: "C.S.I. Gestionale",
  authors: [{ name: "C.S.I. Centro Servizi Integrati" }],
  openGraph: {
    title: "C.S.I. · Gestionale pratiche ufficio",
    description: "Un solo sportello, una sola voce. Il gestionale interno delle pratiche C.S.I.",
    type: "website",
    locale: "it_IT",
  },
  robots: {
    index: false,
    follow: false,
  },
};

export const viewport: Viewport = {
  themeColor: "#001C3A",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="it" className={`${inter.variable} ${interTight.variable} ${jetbrains.variable}`}>
      <body>
        <Observability />
        <DataProvider>
          <ToastProvider>{children}</ToastProvider>
        </DataProvider>
      </body>
    </html>
  );
}
