"use client";

import { useEffect, useState } from "react";
import { Icon } from "./Icon";
import { Modal } from "./Modal";
import { SocialLinks } from "./SocialLinks";
import { ECOSYSTEM, ALTRI_PROGETTI, domainOf, type EcosystemSite } from "@/lib/ecosystem";

export function EcosystemBar() {
  const [active, setActive] = useState<EcosystemSite | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!active) return;
    setLoading(true);
    const timer = window.setTimeout(() => setLoading(false), 2600);
    return () => window.clearTimeout(timer);
  }, [active]);

  return (
    <>
      <div className="ecobar no-print">
        <span className="ecobar-label">Ecosistema C.S.I.</span>
        <div className="ecobar-items">
          {ECOSYSTEM.map((site) => (
            <button
              key={site.id}
              type="button"
              className={`eco-item${site.official ? " eco-item--official" : ""}`}
              onClick={() => setActive(site)}
              title={site.description}
            >
              {site.logo ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={site.logo} alt="" className="eco-logo" aria-hidden="true" />
              ) : (
                <Icon name={site.icon} />
              )}
              <span>{site.label}</span>
            </button>
          ))}
        </div>
        <div className="ecobar-right">
          <details className="eco-more">
            <summary>
              Altri progetti <Icon name="chevron-right" size={11} />
            </summary>
            <div className="eco-more-menu">
              {ALTRI_PROGETTI.map((site) => (
                <button
                  key={site.id}
                  type="button"
                  className="eco-more-item"
                  onClick={(event) => {
                    setActive(site);
                    event.currentTarget.closest("details")?.removeAttribute("open");
                  }}
                >
                  <Icon name={site.icon} size={13} />
                  <span>{site.label}</span>
                </button>
              ))}
            </div>
          </details>
          <span className="ecobar-note">gestionale interno</span>
          <SocialLinks label={null} />
        </div>
      </div>

      {active ? (
        <Modal
          eyebrow="Ecosistema C.S.I."
          title={active.name}
          onClose={() => setActive(null)}
          width="wide"
          footer={
            <>
              <span className="hint" style={{ marginRight: "auto" }}>
                {active.embed === "iframe"
                  ? "Se la pagina resta bianca, il sito non consente l'incorporamento: aprilo in una nuova scheda."
                  : active.note ?? "Questo sito si apre in una nuova scheda."}
              </span>
              <a className="btn btn--ghost btn--sm" href={active.url} target="_blank" rel="noopener noreferrer">
                Apri nel browser <Icon name="external" />
              </a>
            </>
          }
        >
          {active.embed === "iframe" ? (
            <>
              <div className="site-frame">
                <iframe
                  key={active.id}
                  src={active.url}
                  title={active.name}
                  loading="eager"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
              <div className="site-meta">
                <span>{active.description}</span>
                <span className="mono">{domainOf(active.url)}</span>
              </div>
              {loading ? <p className="hint mt-8">Caricamento del sito in corso…</p> : null}
            </>
          ) : (
            <div className="site-blocked">
              <span className="site-blocked-icon">
                <Icon name={active.icon} size={26} />
              </span>
              <span className="eyebrow">Apertura protetta</span>
              <h3>{active.name}</h3>
              <p>{active.note}</p>
              <a className="btn btn--sm mt-16" href={active.url} target="_blank" rel="noopener noreferrer">
                Apri il sito <Icon name="external" />
              </a>
              <span className="mono site-blocked-domain">{domainOf(active.url)}</span>
            </div>
          )}
        </Modal>
      ) : null}
    </>
  );
}
