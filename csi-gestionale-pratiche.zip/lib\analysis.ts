import { daysUntil, formatDate, fullName, today } from "./format";
import type { Database } from "./types";
import type { GuardError } from "./guards";
import type { TestLabRun } from "./test-lab";

export type FindingSeverity = "critical" | "high" | "medium" | "low" | "info";

export interface Finding {
  id: string;
  area: "workflow" | "dipendenze" | "test" | "errori" | "dati";
  severity: FindingSeverity;
  title: string;
  detail: string;
  evidence: string[];
  files: string[];
  fix: string;
}

export interface WorkflowStage {
  key: string;
  label: string;
  count: number;
  detail: string;
}

export interface WorkflowMetrics {
  openPractices: number;
  blockedPractices: number;
  uncoveredClients: number;
  expiringMandates: number;
  overdueActions: number;
  missingNextAction: number;
  missingDocuments: number;
  mandatesWithoutScan: number;
  clientsWithoutPrivacy: number;
  stalePractices: number;
  duplicateNumbers: number;
  orphanRecords: number;
}

export interface WorkflowAnalysis {
  findings: Finding[];
  metrics: WorkflowMetrics;
  stages: WorkflowStage[];
}

export interface DependencyNode {
  id: string;
  label: string;
  lines: number;
  imports: string[];
  externals: string[];
}

export interface DependencyReport {
  generatedAt: string;
  summary: {
    files: number;
    edges: number;
    cycles: number;
    orphans: number;
    packages: number;
    routes: number;
  };
  nodes: DependencyNode[];
  edges: Array<{ from: string; to: string }>;
  cycles: string[][];
  orphans: string[];
  packages: Array<{ name: string; count: number }>;
  routes: Array<{ path: string; file: string; type: "page" | "api" }>;
}

export async function loadDependencyReport(): Promise<DependencyReport | null> {
  try {
    const response = await fetch("/reports/dependencies.json", { cache: "no-store" });
    if (!response.ok) return null;
    return (await response.json()) as DependencyReport;
  } catch {
    return null;
  }
}

function evidenceNames(items: string[], max = 5): string[] {
  return items.slice(0, max);
}

export function analyzeWorkflow(db: Database): WorkflowAnalysis {
  const now = today();
  const open = db.practices.filter((practice) => practice.status !== "conclusa");
  const coverage = new Map(
    open.map((practice) => {
      const mandates = db.mandates.filter(
        (mandate) => mandate.clientId === practice.clientId && !mandate.revokedAt,
      );
      const valid = mandates.filter((mandate) => mandate.expiresAt >= now);
      const state = valid.some((mandate) => mandate.type === "omnibus")
        ? "omnibus"
        : valid.some((mandate) => mandate.type === "servizio" && mandate.serviceIds.includes(practice.serviceId))
          ? "servizio"
          : mandates.some(
                (mandate) =>
                  mandate.expiresAt < now &&
                  (mandate.type === "omnibus" || mandate.serviceIds.includes(practice.serviceId)),
              )
            ? "scaduto"
            : "scoperto";
      return [practice.id, state] as const;
    }),
  );

  const blocked = open.filter((practice) => {
    const state = coverage.get(practice.id);
    return state === "scoperto" || state === "scaduto";
  });
  const expiring = db.mandates.filter((mandate) => {
    if (mandate.revokedAt) return false;
    const days = daysUntil(mandate.expiresAt);
    return days >= 0 && days <= 30;
  });
  const overdue = open.filter(
    (practice) => practice.nextActionAt && practice.nextActionAt < now,
  );
  const missingNext = open.filter((practice) => !practice.nextActionAt);
  const missingDocs = open.filter(
    (practice) => !db.documents.some((document) => document.clientId === practice.clientId),
  );
  const missingScans = db.mandates.filter((mandate) => !mandate.revokedAt && !mandate.signedScan);
  const missingPrivacy = db.clients.filter((client) => !client.privacyScan);
  const stale = open.filter(
    (practice) => practice.status === "in_attesa" && daysUntil(practice.openedAt) < -30,
  );
  const numbers = db.practices.map((practice) => practice.number);
  const duplicateNumbers = numbers.length - new Set(numbers).size;
  const orphanRecords =
    db.practices.filter(
      (practice) =>
        !db.clients.some((client) => client.id === practice.clientId) ||
        !db.services.some((service) => service.id === practice.serviceId),
    ).length +
    db.mandates.filter((mandate) => !db.clients.some((client) => client.id === mandate.clientId)).length +
    db.documents.filter((document) => !db.clients.some((client) => client.id === document.clientId)).length;

  const findings: Finding[] = [];

  if (blocked.length) {
    findings.push({
      id: "WF-COVERAGE",
      area: "workflow",
      severity: "high",
      title: "Pratiche aperte senza copertura di mandato",
      detail: `${blocked.length} pratiche su ${open.length} non hanno un omnibus valido né un mandato per il servizio richiesto. L'avanzamento è bloccato dal controllo.`,
      evidence: evidenceNames(
        blocked.map((practice) => {
          const client = db.clients.find((item) => item.id === practice.clientId);
          return `${practice.number} · ${client ? fullName(client) : practice.clientId} · ${coverage.get(practice.id)}`;
        }),
      ),
      files: ["lib/store.tsx", "app/(app)/pratiche/nuova/page.tsx", "components/NewMandateModal.tsx"],
      fix: "Verificare il calcolo di getCoverage e il gate di apertura pratica. Il pulsante Nuovo mandato deve restare disponibile nella stessa pagina e la pratica non deve poter avanzare senza copertura.",
    });
  }

  if (overdue.length) {
    findings.push({
      id: "WF-OVERDUE",
      area: "workflow",
      severity: "high",
      title: "Azioni con data arretrata",
      detail: `${overdue.length} pratiche hanno una prossima azione precedente a oggi e non sono state chiuse.`,
      evidence: evidenceNames(
        overdue.map((practice) => `${practice.number} · ${formatDate(practice.nextActionAt)} · ${practice.nextActionLabel || "senza nota"}`),
      ),
      files: ["app/(app)/dashboard/page.tsx", "app/(app)/pratiche/[id]/page.tsx"],
      fix: "Allineare la dashboard ai fusi orari locali, mostrare le azioni arretrate in cima e impedire che una pratica resti senza follow-up.",
    });
  }

  if (missingNext.length) {
    findings.push({
      id: "WF-NEXT-ACTION",
      area: "workflow",
      severity: "medium",
      title: "Pratiche senza prossima azione",
      detail: `${missingNext.length} pratiche aperte non hanno un appuntamento, una chiamata o un adempimento programmato: la progressione non è tracciabile.`,
      evidence: evidenceNames(missingNext.map((practice) => practice.number)),
      files: ["app/(app)/pratiche/[id]/page.tsx", "app/(app)/pratiche/nuova/page.tsx"],
      fix: "Rendere obbligatoria la prossima azione alla creazione e proporre un default a 7 giorni quando l'operatore non la indica.",
    });
  }

  if (expiring.length) {
    findings.push({
      id: "WF-EXPIRING",
      area: "workflow",
      severity: "medium",
      title: "Mandati in scadenza entro 30 giorni",
      detail: `${expiring.length} mandati stanno per scadere. Un rinnovo mancato blocca le pratiche future.`,
      evidence: evidenceNames(
        expiring.map((mandate) => {
          const client = db.clients.find((item) => item.id === mandate.clientId);
          return `${client ? fullName(client) : mandate.clientId} · ${formatDate(mandate.expiresAt)}`;
        }),
      ),
      files: ["app/(app)/dashboard/page.tsx", "components/NewMandateModal.tsx"],
      fix: "Mostrare la scadenza nella scheda cliente e generare un avviso con azione di rinnovo direttamente dalla pratica.",
    });
  }

  if (missingDocs.length) {
    findings.push({
      id: "WF-DOCUMENTS",
      area: "workflow",
      severity: "medium",
      title: "Pratiche con documenti d'identità mancanti",
      detail: `${missingDocs.length} pratiche appartengono a clienti senza documento trascritto nell'anagrafica.`,
      evidence: evidenceNames(
        missingDocs.map((practice) => {
          const client = db.clients.find((item) => item.id === practice.clientId);
          return `${practice.number} · ${client ? fullName(client) : practice.clientId}`;
        }),
      ),
      files: ["app/(app)/clienti/[id]/page.tsx", "lib/upload.ts"],
      fix: "Bloccare la stampa del mandato se manca il documento, oppure mostrare un avviso esplicito con caricamento inline.",
    });
  }

  if (missingScans.length) {
    findings.push({
      id: "WF-SCANS",
      area: "workflow",
      severity: "medium",
      title: "Mandati registrati senza scansione firmata",
      detail: `${missingScans.length} mandati risultano validi ma non hanno il modulo firmato allegato.`,
      evidence: evidenceNames(
        missingScans.map((mandate) => {
          const client = db.clients.find((item) => item.id === mandate.clientId);
          return `${client ? fullName(client) : mandate.clientId} · ${formatDate(mandate.signedAt)}`;
        }),
      ),
      files: ["app/(app)/moduli/[clientId]/[tipo]/page.tsx", "components/NewMandateModal.tsx"],
      fix: "Trattare la scansione come requisito per lo stato validato e mostrare un promemoria nella dashboard.",
    });
  }

  if (missingPrivacy.length) {
    findings.push({
      id: "WF-PRIVACY",
      area: "workflow",
      severity: "low",
      title: "Consensi privacy non acquisiti",
      detail: `${missingPrivacy.length} clienti non hanno la scansione privacy firmata.`,
      evidence: evidenceNames(missingPrivacy.map((client) => fullName(client))),
      files: ["app/(app)/clienti/[id]/page.tsx", "app/(app)/moduli/[clientId]/[tipo]/page.tsx"],
      fix: "Aggiungere un controllo privacy nella scheda cliente e un promemoria alla prima pratica.",
    });
  }

  if (stale.length) {
    findings.push({
      id: "WF-STALE",
      area: "workflow",
      severity: "medium",
      title: "Pratiche in attesa da oltre 30 giorni",
      detail: `${stale.length} pratiche sono ferme in stato «in attesa» da più di un mese.`,
      evidence: evidenceNames(stale.map((practice) => `${practice.number} · ${formatDate(practice.openedAt)}`)),
      files: ["app/(app)/dashboard/page.tsx", "app/(app)/pratiche/page.tsx"],
      fix: "Aggiungere un filtro «ferme da» e un avviso con azione di sollecito.",
    });
  }

  if (duplicateNumbers) {
    findings.push({
      id: "WF-DUPLICATE-NUMBERS",
      area: "dati",
      severity: "critical",
      title: "Numeri pratica duplicati",
      detail: `Trovati ${duplicateNumbers} duplicati. Il progressivo non è più affidabile.`,
      evidence: evidenceNames(numbers.filter((number, index) => numbers.indexOf(number) !== index)),
      files: ["lib/store.tsx", "app/(app)/pratiche/nuova/page.tsx"],
      fix: "Centralizzare il progressivo in un contatore atomico lato server e aggiungere un vincolo univoco.",
    });
  }

  if (orphanRecords) {
    findings.push({
      id: "WF-ORPHANS",
      area: "dati",
      severity: "critical",
      title: "Record orfani nell'archivio",
      detail: `${orphanRecords} record puntano a clienti, servizi o documenti inesistenti.`,
      evidence: ["Pratiche, mandati o documenti con chiavi esterne non risolte."],
      files: ["lib/store.tsx", "lib/backup.ts"],
      fix: "Validare le chiavi esterne in import/ripristino e mostrare un report di integrità prima di salvare.",
    });
  }

  const stages: WorkflowStage[] = [
    {
      key: "appointments",
      label: "Appuntamenti",
      count: db.appointments.filter((appointment) => appointment.date === now).length,
      detail: "Oggi",
    },
    { key: "clients", label: "Anagrafiche", count: db.clients.length, detail: "Clienti in archivio" },
    {
      key: "documents",
      label: "Documenti",
      count: db.clients.filter((client) => db.documents.some((document) => document.clientId === client.id)).length,
      detail: "Clienti con documento",
    },
    {
      key: "mandates",
      label: "Mandati",
      count: db.mandates.filter((mandate) => !mandate.revokedAt && mandate.expiresAt >= now).length,
      detail: "Coperture valide",
    },
    { key: "practices", label: "Pratiche", count: open.length, detail: "Fascicoli aperti" },
  ];

  return {
    findings,
    metrics: {
      openPractices: open.length,
      blockedPractices: blocked.length,
      uncoveredClients: new Set(blocked.map((practice) => practice.clientId)).size,
      expiringMandates: expiring.length,
      overdueActions: overdue.length,
      missingNextAction: missingNext.length,
      missingDocuments: missingDocs.length,
      mandatesWithoutScan: missingScans.length,
      clientsWithoutPrivacy: missingPrivacy.length,
      stalePractices: stale.length,
      duplicateNumbers,
      orphanRecords,
    },
    stages,
  };
}

export function findingsFromDependencies(report: DependencyReport | null): Finding[] {
  if (!report) {
    return [
      {
        id: "DEP-NO-REPORT",
        area: "dipendenze",
        severity: "medium",
        title: "Report dipendenze non generato",
        detail: "La pagina non trova /reports/dependencies.json. L'analisi statica va eseguita con `npm run analyze`.",
        evidence: ["File atteso: public/reports/dependencies.json"],
        files: ["scripts/analyze.mjs", "package.json"],
        fix: "Eseguire l'analizzatore prima della build e includere il report negli asset pubblici.",
      },
    ];
  }

  const findings: Finding[] = [];
  if (report.cycles.length) {
    findings.push({
      id: "DEP-CYCLES",
      area: "dipendenze",
      severity: "high",
      title: "Dipendenze circolari",
      detail: `Rilevati ${report.cycles.length} cicli di importazione. Possono causare inizializzazioni parziali e bug difficili da riprodurre.`,
      evidence: report.cycles.slice(0, 5).map((cycle) => cycle.join(" → ")),
      files: report.cycles.flat().slice(0, 8),
      fix: "Estrarre i tipi e le funzioni pure in moduli foglia, poi invertire le dipendenze con import type.",
    });
  }
  if (report.orphans.length) {
    findings.push({
      id: "DEP-ORPHANS",
      area: "dipendenze",
      severity: "low",
      title: "Moduli non referenziati",
      detail: `${report.orphans.length} file non hanno import entranti. Verificare se sono codice morto o entry point.`,
      evidence: report.orphans.slice(0, 6),
      files: report.orphans.slice(0, 8),
      fix: "Rimuovere il codice morto o collegarlo esplicitamente; non eliminare entry point di Next.",
    });
  }
  const heavy = report.nodes.filter((node) => node.lines > 500).sort((a, b) => b.lines - a.lines);
  if (heavy.length) {
    findings.push({
      id: "DEP-HEAVY",
      area: "dipendenze",
      severity: "low",
      title: "Moduli molto estesi",
      detail: `${heavy.length} file superano 500 righe. Sono candidati a estrazione di hook, tabelle e componenti.`,
      evidence: heavy.slice(0, 6).map((node) => `${node.id} · ${node.lines} righe`),
      files: heavy.slice(0, 6).map((node) => node.id),
      fix: "Estrarre parti coerenti in componenti o hook, mantenendo invariati i contratti pubblici.",
    });
  }
  return findings;
}

export function findingsFromTests(run: TestLabRun | null): Finding[] {
  if (!run) return [];
  const findings: Finding[] = [];
  const failed = run.results.filter((result) => !result.pass);
  if (failed.length) {
    findings.push({
      id: "TEST-FAILURES",
      area: "test",
      severity: "high",
      title: "Test del laboratorio falliti",
      detail: `${failed.length} casi su ${run.results.length} non rispettano l'atteso del fixture esterno.`,
      evidence: failed.map((result) => `${result.id} · ${result.title} · atteso ${result.expected} / ottenuto ${result.actual}`),
      files: ["lib/test-lab.ts", "public/test-data/office.json", "public/test-data/cases.json"],
      fix: "Correggere la regola di dominio o il fixture, mai il test per farlo passare. Rieseguire poi il laboratorio.",
    });
  }
  if (run.persistedTestRecords > 0) {
    findings.push({
      id: "TEST-RESIDUE",
      area: "test",
      severity: "critical",
      title: "Record di test rimasti nell'archivio",
      detail: `${run.persistedTestRecords} record con prefisso test- sono presenti nell'archivio operativo.`,
      evidence: ["La sandbox deve restare in memoria e i record test-* vanno eliminati."],
      files: ["lib/store.tsx", "lib/test-lab.ts"],
      fix: "Chiamare cleanupTestRecords dopo ogni run e impedire scritture con id test-*.",
    });
  }
  return findings;
}

export function findingsFromErrors(errors: GuardError[]): Finding[] {
  const recent = errors.filter((error) => Date.now() - new Date(error.at).getTime() < 7 * 86_400_000);
  const critical = recent.filter((error) => error.severity === "critical" || error.severity === "error");
  if (!critical.length) return [];
  return [
    {
      id: "ERR-RECENT",
      area: "errori",
      severity: critical.length > 3 ? "critical" : "high",
      title: "Errori runtime recenti",
      detail: `${critical.length} errori negli ultimi 7 giorni. Il più recente proviene da ${critical[0].section}.`,
      evidence: critical.slice(0, 5).map((error) => `${error.section} · ${error.message}`),
      files: ["lib/guards.ts", "components/Guard.tsx"],
      fix: "Riprodurre l'errore con il contesto del registro, aggiungere un test di regressione e correggere la causa alla radice.",
    },
  ];
}

export function allFindings(input: {
  workflow: WorkflowAnalysis;
  dependencies: DependencyReport | null;
  tests: TestLabRun | null;
  errors: GuardError[];
}): Finding[] {
  return [
    ...input.workflow.findings,
    ...findingsFromDependencies(input.dependencies),
    ...findingsFromTests(input.tests),
    ...findingsFromErrors(input.errors),
  ];
}
