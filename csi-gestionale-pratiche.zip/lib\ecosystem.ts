import type { IconName } from "@/components/Icon";

export interface EcosystemSite {
  id: string;
  label: string;
  name: string;
  description: string;
  url: string;
  icon: IconName;
  logo?: string;
  official?: boolean;
  embed: "iframe" | "link";
  note?: string;
}

export const ECOSYSTEM: EcosystemSite[] = [
  {
    id: "sito",
    label: "Sito ufficiale",
    name: "C.S.I. — Sito ufficiale",
    description: "Il punto di accesso pubblico ai servizi del Centro Servizi Integrati.",
    url: "https://csi-bari.surge.sh/index.html",
    icon: "building",
    logo: "/brand/ecosystem/sito.png",
    official: true,
    embed: "iframe",
  },
  {
    id: "finanziamenti",
    label: "Finanziamenti",
    name: "C.S.I. — Sezione Finanze",
    description: "Consulenza e accompagnamento alle misure di credito e finanza agevolata.",
    url: "https://csi-finanziamenti.vercel.app/",
    icon: "coins",
    logo: "/brand/ecosystem/finanziamenti.png",
    embed: "iframe",
  },
  {
    id: "utenze",
    label: "Utenze",
    name: "C.S.I. — Sezione Utenze",
    description: "Sportello gas, luce e telefonia: attivazioni, cambi fornitore e contestazioni.",
    url: "https://csi-luce-gas.surge.sh/",
    icon: "spark",
    logo: "/brand/ecosystem/utenze.png",
    embed: "iframe",
  },
  {
    id: "legalaid",
    label: "Legal Aid",
    name: "Legal Aid — Sportello d'Aiuto Legale Internazionale",
    description: "Assistenza legale internazionale e servizi per la Sezione Stranieri.",
    url: "https://csi-bari.surge.sh/assets/progetti/legal-aid/index.html",
    icon: "shield",
    logo: "/brand/ecosystem/legalaid.png",
    embed: "iframe",
  },
  {
    id: "pensioni",
    label: "Pensioni",
    name: "Ricalcolo pensione",
    description: "Simulazione e ricalcolo della posizione pensionistica.",
    url: "https://csi-pensioni-rho.vercel.app/index.html",
    icon: "calculator",
    logo: "/brand/ecosystem/pensioni.png",
    embed: "link",
    note: "Il sito invia X-Frame-Options: SAMEORIGIN e non consente l'incorporamento in un'altra pagina. Si apre in una nuova scheda.",
  },
];

/** Progetti digitali senza un logo di sezione dedicato: restano raggiungibili dal menu. */
export const ALTRI_PROGETTI: EcosystemSite[] = [
  {
    id: "spacez",
    label: "Space Z",
    name: "Space Z",
    description: "Progetto digitale dell'ecosistema C.S.I. Deploy temporaneamente non disponibile.",
    url: "https://j1bg49v2dud0-d.space-z.ai/",
    icon: "spark",
    embed: "link",
    note: "Il deploy risponde 500: il sito non è al momento raggiungibile. Riprova più tardi o apri il link nel browser.",
  },
  {
    id: "cselp",
    label: "Conf.SELP",
    name: "Conf.SELP Bari",
    description: "Prenotazione appuntamenti per Conf.SELP Bari.",
    url: "https://landing-cselp-20261109-1850.vercel.app/",
    icon: "layers",
    embed: "iframe",
  },
];

export function domainOf(url: string): string {
  try {
    return new URL(url).host.replace(/^www\./, "");
  } catch {
    return url;
  }
}
